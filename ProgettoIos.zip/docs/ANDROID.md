# MyGymHelper per Android – guida passo per passo

Porting dell'app iOS con le stesse funzioni, gli stessi piani (Free, Mid, Full), gli stessi testi (it/en)
e lo stesso backend Supabase. Android 9 (API 28) e successivi.

**Stato onesto**
- Il modulo `:core` (logica pura in Kotlin) è stato **compilato ed eseguito con 53 test JUnit, tutti superati**:
  stessi casi dei test Swift (conteggio, consigli, parser delle schede, nutrizione, catalogo, archivio).
- L'app (`:app`, Jetpack Compose) **non è mai stata compilata**: in questo ambiente i repository Google/Maven
  sono bloccati. È stata controllata la sintassi e riletta da un revisore indipendente; i problemi trovati sono
  stati corretti. Al primo build in Android Studio potrebbero servire piccole correzioni
  (nomi di API cambiati in una libreria, import).
- Backend Google Play: funzione `google-play-notifications` con 6 test Deno superati e `deno check` superato;
  nuova migrazione SQL eseguita su PostgreSQL di prova. Mai provata con Google Play vero.

## 1. Aprire il progetto
1. Installa Android Studio (versione recente, con JDK 17 incluso).
2. File > Open > cartella `android/`. Al primo avvio Android Studio scarica Gradle 8.14.3 e le librerie
   (serve internet). Se propone aggiornamenti delle versioni in `gradle/libs.versions.toml`, accettali.
3. Copia `android/local.properties.example` in `android/local.properties` e compila (vedi sezione 3).
   Senza Supabase l'app funziona lo stesso: catalogo incluso, nessun account.
4. Build > Make Project. Poi esegui su un **telefono vero** (l'emulatore non ha sensori di movimento realistici).
5. Test della logica: `./gradlew :core:test`.

## 2. Struttura
```
android/
├── settings.gradle.kts, build.gradle.kts, gradle/libs.versions.toml, gradlew
├── core/   logica pura Kotlin (port 1:1 del pacchetto Swift Core) + test JUnit
├── app/    Compose, Material 3 (tema scuro "vetro" come iOS)
│   ├── data/        Prefs (impostazioni e consenso), AppStore (dati sanitari, file JSON escluso dai backup),
│   │                CatalogRepository (catalogo incluso + funzione catalog), LegalDocs
│   ├── services/    MotionService (accelerometro lineare 50 Hz), CueService (voce, suono, vibrazione),
│   │                SessionController, BillingManager (Google Play), HealthConnectService, AccountService
│   │                (Supabase + Google), TextExtractor (ML Kit + PdfRenderer)
│   └── ui/          Navigation (5 schede con pile di schermate), Theme, schermate in ui/screens/
├── tools/xcstrings_to_android.py   genera res/values*/strings.xml da App/Localizable.xcstrings
│                                   + tools/android_strings.json (testi solo Android)
└── store/play-icon-512.png         icona per la scheda del Play Store
```
I testi si modificano **solo** nel catalogo iOS (`App/Localizable.xcstrings`) o in `tools/android_strings.json`,
poi: `python3 tools/xcstrings_to_android.py` (dalla cartella `android`). I file `strings.xml` sono generati.

## 3. local.properties
```
supabase.url=https://<ref>.supabase.co
supabase.anonKey=eyJ...                       # chiave "anon" (pubblica). MAI la service role key
google.webClientId=1234-abc.apps.googleusercontent.com
privacy.url=https://tuosito.it/privacy        # obbligatoria per Play Console e per Health Connect
terms.url=                                    # facoltativa: senza, si usano le condizioni di Google Play
contact.email=supporto@tuosito.it             # User-Agent di Open Food Facts
```

## 4. Accesso con Google (Credential Manager)
1. Google Cloud Console, stesso progetto usato per Supabase: crea due client OAuth:
   - tipo **Web application** (è quello già usato in Supabase > Authentication > Providers > Google):
     il suo Client ID va in `google.webClientId`;
   - tipo **Android**: pacchetto `app.mygymhelper` e impronta SHA-1 del certificato di firma
     (quella di debug per le prove, e quella di "Firma dell'app" di Play Console per la versione pubblicata).
2. In Supabase > Authentication > Providers > Google il client ID Web deve comparire tra i "Client IDs"
   (accesso con token Google dall'app). Il nonce lo gestisce l'app: lascia attivo il controllo del nonce.
3. L'accesso con e-mail e codice funziona come su iOS. Accedi con Apple non c'è su Android: chi ha creato
   l'account su iPhone con Apple può usare l'e-mail se è la stessa, altrimenti resta solo su iPhone.

## 5. Google Play Console
1. Crea l'app (nome MyGymHelper, pacchetto `app.mygymhelper`, gratuita con acquisti in-app).
2. **Abbonamenti** (Monetizza > Prodotti > Abbonamenti), due prodotti:
   - `mygymhelper_mid` con piani base `monthly` (rinnovo mensile, es. 4,99 €) e `yearly` (annuale, es. 49,99 €);
   - `mygymhelper_full` con piani base `monthly` (9,99 €) e `yearly` (99,99 €).
   - Su ogni piano base un'offerta con id **`free-trial`**: fase gratuita di 7 giorni, idoneità
     "Nuovo cliente che non ha mai avuto questo abbonamento" (o "nessun abbonamento", per concederla una volta sola).
   Prezzi e durata nell'app arrivano sempre da Google Play: non sono scritti nel codice.
3. **Notifiche in tempo reale** (Monetizza > Configurazione della monetizzazione): argomento Pub/Sub, vedi
   `docs/BACKEND.md` sezione 8.
4. **Account di servizio** per leggere gli abbonamenti dal server: Google Cloud > IAM > Account di servizio > crea,
   genera una chiave JSON; in Play Console > Utenti e autorizzazioni invita la sua e-mail con il permesso
   "Visualizzare dati finanziari, ordini e risposte ai sondaggi sull'annullamento" e "Gestire ordini e abbonamenti".
5. **Test**: aggiungi i tester delle licenze (Impostazioni > Test delle licenze) e carica una build in un
   canale di test interno: gli acquisti dei tester non vengono addebitati e i rinnovi sono accelerati.
6. **Norme**:
   - Scheda "Sicurezza dei dati" (Data safety): dati raccolti = indirizzo e-mail e ID utente (solo con account,
     per gestione account), cronologia acquisti (abbonamento). Dati sanitari e di fitness: **trattati solo sul
     dispositivo, non raccolti** (non lasciano il telefono). Crittografia in transito: sì. Eliminazione: sì (Info > Account).
   - Dichiarazione **Health Connect** (Contenuti dell'app > Autorizzazioni di Health Connect): motivi d'uso
     di peso, altezza (lettura su richiesta per il profilo) e allenamenti (scrittura). Serve l'informativa pubblicata.
   - Dichiarazione salute (Health apps declaration): app di fitness/benessere, non dispositivo medico.
   - Classificazione dei contenuti, pubblico di destinazione (adulti: 18+), pagina web con l'informativa.
   - L'eliminazione dell'account è possibile in app; Play chiede anche un **link web** per chiederla:
     una pagina con le istruzioni o un modulo.

## 6. Health Connect
- Android 14 e successivi: è nel sistema. Android 9-13: serve l'app "Health Connect" dal Play Store
  (l'interruttore in Info porta al Play Store se manca).
- Permessi chiesti: lettura peso e altezza, scrittura allenamenti. Health Connect fa leggere i dati degli ultimi
  30 giorni prima della prima autorizzazione: un peso più vecchio non viene importato (limite noto, accettato per
  chiedere meno permessi).
- "Elimina tutti i dati" cancella anche gli allenamenti scritti dall'app in Health Connect; la revoca del consenso
  o lo spegnimento dell'interruttore restituiscono i permessi.

## 7. Differenze rispetto a iOS
- Abbonamenti: schermata propria con prezzi da Google Play, testo di rinnovo e disdetta accanto ai pulsanti
  (norme Play), "Ripristina" rilegge gli acquisti, "Gestisci" apre il Play Store. Il cambio Mid ↔ Full è proporzionale
  al tempo residuo. Lo stato si verifica sul telefono (come StoreKit 2 su iOS) e sul server tramite le notifiche.
- Conteggio: accelerometro lineare di Android (senza gravità) a 50 Hz, stesso rilevatore del Core.
  Le soglie restano da tarare su telefoni veri.
- Schede da PDF: ogni pagina è letta con l'OCR (Android legge il testo incorporato dei PDF solo dalla versione 15).
- Durante l'allenamento la barra delle schede si nasconde; "Indietro" termina la sessione e mostra il riepilogo.
- Backup: disattivato (i dati sanitari restano solo sul telefono, come su iOS).
- Mappa del corpo, consigli, nutrizione, testi legali: uguali. L'informativa Android parla di Google Play e
  Health Connect al posto di Apple (bozze da far verificare a un legale).

## 8. Prima della pubblicazione
- Compilare, provare su almeno 2-3 telefoni (conteggio in tasca/fascia, Health Connect, acquisti di prova).
- Firma: Play App Signing (Play Console genera la chiave di firma; tu carichi un .aab firmato con la chiave di caricamento):
  Build > Generate Signed App Bundle.
- Screenshot del telefono, grafica in evidenza 1024×500, icona 512×512 (`android/store/play-icon-512.png`).
- Testi della scheda: si possono riusare quelli di `docs/STORE_TEXTS.md` (stesse regole: niente promesse mediche).
