# MyGymHelper (ex PalestrApp) – documento di passaggio (handoff)

Scopo: permettere a un altro assistente (o sviluppatore) di capire tutto quello che è stato deciso e fatto, di ricreare
l'app da zero se serve e di completarla. Il codice sorgente della fase 1 era nello zip `PalestrApp-fase1.zip`; quello attuale è la cartella `MyGymHelper`; questo documento spiega
cosa c'è, perché, a che punto è e cosa manca. Data dello stato descritto: 18 ottobre 2026.

> **Aggiornamento 19 ottobre 2026 (fase 2)**: l'app si chiama **MyGymHelper** (pacchetto `MyGymHelperCore`, ID prodotto
> `app.mygymhelper.*`, chiave Info.plist `MyGymHelperBackendURL`). Il blocco 9.A è stato completato e c'è un progetto Xcode
> pronto: vedi la sezione 12. Le sezioni 1–11 descrivono lo stato del 18 ottobre (con i nomi aggiornati).

> Stato in una riga (18 ottobre): la logica (Core) è scritta e coperta da test **mai eseguiti**; l'app SwiftUI è scritta ma **mai
> compilata**; la parte "esercizi/coaching/schede/alimentazione" è **a metà** (vedi sezione 9).

---

## 1. Obiettivo del prodotto

App iOS (Swift) per allenamento personale, con rewrite futuro per Android. Specifiche originali (italiano):

- Il telefono si lega al braccio o alla gamba; in base a velocità e blocchi l'app conta ripetizioni e serie e consiglia
  se cambiare serie, pesi e tempi di riposo. Può contare da sola o farsi dire i dati dall'utente. Avvisa quando
  ricominciare e quando finire; se l'utente si ferma prima, segna quante ripetizioni ha fatto.
- Spiega gli esercizi (API gratuite) e consiglia quelli migliori in base agli esercizi fatti e ai muscoli scelti.
- Prende altezza, sesso, peso per BMI e consiglio di piano alimentare (calcolato + API gratuite).
- Tre livelli di pagamento: Free (solo conteggio impostato dall'utente), Mid (conteggio + consigli sugli esercizi in
  base alle serie fatte), Full (tutta l'app). Gestione di licenze e pagamenti.
- Salvataggio dei piani di allenamento e del tipo di dieta (onnivora, vegetariana, gluten free, vegana, senza lattosio).
- Selezione dei muscoli su modello fronte/retro oppure con blocchi (braccia, gambe, torace...).

## 2. Decisioni prese dall'utente (registro)

Piattaforma e strumenti
- iOS 26 minimo (da iPhone 11 in su), Swift, SwiftUI, SwiftData, StoreKit 2. Ha un Mac con Xcode; sviluppa abitualmente su Windows.
- Repo GitHub privata `andrealmeno/Palestrapp`, attualmente vuota: i commit li fa l'utente. **Non fare commit.**
- Nome provvisorio "MyGymHelper" (sviluppo riservato, verrà cambiato). Nessuna scadenza.
- Lingua dell'app = lingua del telefono; mercato internazionale. UI e commenti del progetto in italiano (con inglese nel catalogo stringhe).

Piani e prezzi
- Free: conteggio con serie/ripetizioni/pausa impostati dall'utente + BMI + catalogo con un esercizio per tipologia.
- Mid: catalogo completo, elenchi salvati, consigli a regole fisse, indicazioni alimentari generali, Apple Watch.
- Full: consigli adattivi, caricamento scheda di allenamento e scheda del nutrizionista, piano alimentare per dieta e
  allenamento, uso offline completo, sincronizzazione cloud (in futuro).
- Prezzi: Mid 4,99 €/mese e 49,99 €/anno; Full 9,99 €/mese e 99,99 €/anno. Prova gratuita di 7 giorni alla prima
  iscrizione (offerta introduttiva sul gruppo di abbonamento in App Store Connect).

Dati e privacy
- Dati sanitari **solo sul telefono** per impostazione predefinita (sincronizzazione cloud da decidere in futuro).
  Condivisione con Apple Salute solo con consenso. Backup e cambio telefono: punto aperto.
- Login con email, Google e Apple ID (Apple solo iOS) su Supabase (piano free all'inizio). Licenze in un database/schema separato.
- Lettura schede con Vision e PDFKit; modello AI **locale** (ipotesi Gemma 3 270M) solo dopo consenso, leggero.
- Disclaimer (non sostituisce nutrizionista, personal trainer, medici) in tre punti: prima installazione, sezione Info,
  descrizione dell'app. Nessuna ricetta (copyright). Testi legali forniti dall'utente (da un'altra AI), da far
  verificare a un legale.

Fonti dati
- Alimenti: Open Food Facts. Esercizi: l'utente voleva l'API MuscleWiki al posto del dataset di opengym.
- opengym (AGPL-3.0): solo come spunto, nessun codice copiato. Immagini/GIF degli esercizi: **proprie** (niente licenza Gym visual).
- Altri smartwatch (altri SDK): in futuro. Apple Watch: previsto già nel Mid.

## 3. Vincoli e scoperte su licenze e servizi (da rispettare)

- **opengym** (alexpcosta/opengym, fork di DuarteSantos8/openGym): AGPL-3.0, React/Node/Capacitor. Copiare o tradurre
  il suo codice renderebbe l'app AGPL con sorgente pubblico: vietato. Non usa API esterne (legge un dataset in locale).
- **Dataset hasaneyldrm/exercises-dataset**: testi e metadati MIT; GIF/immagini © Gym visual (serve licenza a parte).
  Non usato nel codice; possibile riserva solo per i testi.
- **MuscleWiki API** (api.musclewiki.com/api-terms): piano gratuito solo "Playground" (nessuna chiave per l'app); uso
  commerciale solo a pagamento; lingue oltre l'inglese dal piano GROWTH; chiave mai nell'app (serve un backend);
  cache dei metadati max 30 giorni (quindi catalogo offline max 30 giorni); vietato salvare video/immagini e usare i
  contenuti per addestrare modelli AI; attribuzione richiesta ("Exercise data and videos provided by MuscleWiki.com");
  termini revocabili, prezzi modificabili con preavviso. Il nome dei muscoli restituiti va verificato con dati reali
  (`MuscleGroup(apiName:)` è tollerante ma non testato su risposte vere).
- **MuscleMap** (melihcolpan, MIT, Swift): citata dal NOTICE di opengym come origine della geometria del corpo; **non
  verificata né usata**. La mappa del corpo nell'app è disegnata da noi (forme schematiche).
- **Open Food Facts**: dati ODbL (attribuzione/condivisione); richiede User-Agent identificativo. Da verificare prima del rilascio.
- **Gemma 3 270M**: termini d'uso propri (non è una licenza open source standard): da verificare. Su iPhone 11 il
  modello Apple "Foundation Models" di iOS 26 non è disponibile (richiede Apple Intelligence): serve un runtime
  esterno (Core ML, MLX o llama.cpp) da misurare su un iPhone 11 vero.
- **GDPR**: peso/altezza/schede/piani sono dati sanitari; consenso esplicito separato, cancellazione in-app, backup
  esclusi. AI Act e dispositivi medici: vedere `docs/ADEMPIMENTI_LEGALI.md`. Non è consulenza legale.

## 4. Ambiente di lavoro e metodo

- L'assistente lavora in un ambiente Linux **senza Swift/Xcode**: nessun file è stato compilato né i test Swift sono stati
  eseguiti. Per la logica più delicata (rilevatore ripetizioni, macchina a stati della sessione, parser delle schede)
  è stato verificato un equivalente in **Python** sugli stessi casi dei test; è una verifica del ragionamento, non del Swift.
- Primo passo sul Mac: aprire Xcode 26, importare i file, compilare, eseguire `swift test` nel pacchetto Core e correggere gli errori.
- Impostazioni attese: Swift tools 6.2, `swiftLanguageModes: [.v5]` nel pacchetto; nel target app **Default Actor
  Isolation = nonisolated** e Swift Language Mode 5 (il codice dei sensori gira su una coda in background).
- Info.plist: `NSMotionUsageDescription` (obbligatoria); `MyGymHelperBackendURL` (facoltativa: attiva il catalogo da backend).

## 5. Architettura

```
MyGymHelper/
├── Core/                         Pacchetto Swift "MyGymHelperCore" (nessuna dipendenza da UI; da riscrivere identico in Kotlin)
│   ├── Package.swift             iOS 26, macOS 14 (per i test), swiftLanguageModes [.v5]
│   ├── Sources/MyGymHelperCore/   (vedi 5.1)
│   └── Tests/MyGymHelperCoreTests/ CoreTests, SessionEngineTests, FeatureTests
├── App/                          File SwiftUI da mettere nel target iOS (vedi 5.2) + Localizable.xcstrings + exercises_seed.json + Legal/*.md
├── docs/                         ADEMPIMENTI_LEGALI.md, mygymhelper_schema.sql, HANDOFF.md
└── README.md                     passi per mettere tutto in Xcode
```

### 5.1 Core (file, ruolo, stato)

| File | Contenuto | Stato |
| --- | --- | --- |
| Tier.swift | `SubscriptionTier` (free<mid<full), `Feature`, `FeatureGate` | scritto, testato (test) |
| BMI.swift | `BMICalculator` (categorie OMS adulti) | scritto, testato |
| Nutrition.swift | Mifflin-St Jeor, `ActivityLevel`, `Goal`, `DietType`, `DailyTargets` | scritto, testato |
| RepDetector.swift | `Vector3`, `PrincipalAxis`, `RepDetector`, `RepDetectorConfig` | scritto; verificato in Python |
| SessionEngine.swift | macchina a stati: `SessionPhase`, `SessionCue`, `SetRecord`, `SessionEngine` | scritto; verificato in Python |
| Progression.swift | `SetOutcome`, `FixedCoaching` (regole Mid) | scritto, testato |
| Exercises.swift | `Exercise` (DTO API stile MuscleWiki), protocollo `ExerciseProvider` | scritto |
| CachedExerciseProvider.swift | cache su disco (max 30 giorni) + `BackendExerciseProvider` (endpoint `/catalog?lang=`) | scritto, non testato |
| Muscles.swift | `MuscleGroup` (14), `BodyRegion` (6), mappatura dai nomi API | scritto, testato |
| Catalog.swift | `CatalogExercise`, `SeedCatalog`, `Exercise.toCatalog()`, `CatalogAccess` (regola Free), `ExerciseMatcher` | scritto, testato |
| Recommender.swift | `ExerciseRecommender` (consigli esercizi Mid/Full) | scritto, testato |
| AdaptiveCoach.swift | `AdaptiveCoach` (consigli adattivi Full), `PlanTarget`, `SessionSample` | scritto, testato |
| PlanParser.swift | `TrainingPlanParser`, `NutritionPlanParser`, `PlanAIOutput` (validazione JSON dal modello AI) | scritto; regex verificate in Python |
| Diet.swift | `DietPlanner`, alimenti per dieta (solo chiavi, niente ricette), 5 pasti | scritto, testato |
| Disclaimer.swift | chiavi del disclaimer | scritto |

Costanti e regole principali (riprodurle uguali su Android):
- **RepDetector**: segnale 1D = accelerazione utente (gravità rimossa) proiettata sull'asse principale (PCA con 50
  iterazioni di potenza). Filtro passa-basso EMA a 3 Hz; picco = campione con vicini minori (un campione di ritardo);
  soglia = max(0,12 g; 0,5 × media mobile dei picchi); intervallo minimo 0,7 s; isteresi: riarmo sotto 0,3 × soglia;
  `signalConfidence` = 1 − max(CV ampiezze, CV intervalli) (bassa se il telefono è in tasca).
- **MotionService** (app): 50 Hz, calibrazione 3 s a finestra scorrevole; se non c'è movimento ≥ 0,15 g aspetta (evita
  un asse casuale); mantiene l'asse tra le serie; `beginSet()` / `pauseCounting()`.
- **SessionEngine**: fasi `notStarted → working(set) → resting(afterSet, remaining) → … → finished`; avvisi `setStarted,
  targetReached, restStarted, restCountdown(3,2,1), restEnded, sessionFinished`; conteggio ignorato durante la pausa;
  stop manuale con ripetizioni dichiarate; `endNow`; il tempo arriva da fuori (monotonic `systemUptime`).
- **FixedCoaching (Mid)**: tutte le serie completate → +1,25 kg (+2,5 gambe) e, con ≥3 serie, +1 serie (max 5);
  ≥ metà serie interrotte → −10% e −1 serie (min 2), pausa +30 s; altrimenti invariato. Pausa base 120 s (multiarticolare)
  o 75 s (isolamento). Chiavi motivo `coach.*`.
- **AdaptiveCoach (Full)**: usa ultima sessione dell'esercizio: completamento, interruzioni, calo di velocità prima→ultima
  serie. Due sessioni di fila sotto 80% → scarico −10%; completato senza fatica (<20%) → +reps se la scheda ha un
  intervallo, altrimenti +2,5% del carico (arrotondato a 1,25 kg); senza carico (corpo libero) → +1 ripetizione; fatica
  20–35% → +15 s; >35% → +30 s; completamento 70–85% → mantiene; <70% → −8% e −1 serie. Limiti: serie 1–8, rip. 1–50,
  pausa 30–300 s. Gli obiettivi della scheda (`PlanTarget`) prevalgono su serie/pausa.
- **ExerciseRecommender**: punteggio = bisogno (1/(1+serie settimanali/6) mediato sui muscoli primari) + 0,25 se
  multiarticolare + 0,15 se mai fatto − 0,5 se fatto nelle ultime 48 h. Chiavi motivo `rec.*`.
- **Nutrizione**: BMR Mifflin-St Jeor; TDEE = BMR × attività; obiettivo ×0,85/×1,00/×1,10; proteine 1,6 (mantenimento)
  o 1,8 g/kg; grassi 0,9 g/kg; carboidrati = resto. Giorno di allenamento +8% calorie (tutte in carboidrati). Pasti:
  25/10/30/10/25%. Coefficienti **indicativi, da far rivedere a un professionista**. Non gestisce allergie o patologie.
- **Parser schede**: righe tipo "Panca piana 4x8-10 60kg rec 90s", "4 serie da 10", intestazioni giorno/giorni della
  settimana; recupero con unità (min, ', s, ", '') e numero nudo ≤10 = minuti. È euristico: l'utente conferma sempre.

### 5.2 App (file, ruolo, stato)

| File | Ruolo | Stato |
| --- | --- | --- |
| MyGymHelperApp.swift | entrata, `.modelContainer`, onboarding, abbonamenti | scritto; **manca** `.environment(CatalogStore)` |
| ContentView.swift | tab (Allenamento, BMI, Piani, Info) e BMI con blocco senza consenso | scritto; **da aggiornare** (tab Esercizi/Nutrizione) |
| Theme.swift | colori, sfondo, `glassCard`, `ScreenHeader`, `CounterRow`, `RepRing` | scritto |
| DisclaimerView / Onboarding / ConsentStore / LegalDocument / InfoView | disclaimer, consenso separato, documenti legali, Info, cancellazione dati | scritti |
| WorkoutSetupView.swift | scelta braccio/gamba, serie/rip./pausa, avvisi, storico | scritto; **manca** init con esercizio, peso e consigli |
| SessionController / SessionEngine (Core) / MotionService / CueService | sessione: sensori, avvisi (voce, suono, vibrazione) | scritti (controller già con esercizio e peso) |
| WorkoutSessionView.swift | schermate lavoro, pausa, "mi sono fermato", salvataggio con consenso | scritto; **da aggiornare** (nuovi parametri) |
| SessionSummaryView.swift | riepilogo e consigli Mid | scritto; **da aggiornare** (adattivo Full, esercizio) |
| HistoryView.swift | storico (SwiftData) | scritto |
| Persistence.swift | modelli SwiftData: sessioni, serie, elenchi, schede, piano alimentare, profilo salute; archivio escluso dai backup | scritto |
| CatalogStore.swift | catalogo: elenco incluso + backend facoltativo | scritto |
| CoachingService.swift | ponte SwiftData → motori del Core | scritto |
| BodyMapView.swift | mappa corpo fronte/retro + blocchi per zona | scritto |
| ExercisesView.swift | catalogo, dettaglio, elenchi preimpostati e salvati | scritto; **riferisce `TrainingPlansView` non ancora scritta** |
| SubscriptionManager / PaywallView | StoreKit 2, livelli, cache offline 14 giorni | scritti |
| Localizable.xcstrings | italiano e inglese | **incompleto** (vedi 9) |
| exercises_seed.json | 25 esercizi, testi nostri in it/en | scritto |
| Legal/*.md | disclaimer, informativa privacy (con sezione 10 aggiunta da noi), consenso | scritti, solo italiano, con segnaposto |

Flusso all'avvio: disclaimer (accettazione registrata con data e versione) → consenso dati sanitari (casella non
preselezionata, "Non ora" possibile) → app. Senza consenso: BMI, storico, elenchi e import schede sono bloccati;
il conteggio funziona. Revoca consenso e "Elimina tutti i dati locali" in Info (`LocalData.deleteHealthData()` cancella
tutti i modelli SwiftData sanitari).

## 6. Dati

SwiftData (solo locale, escluso dai backup): `WorkoutSessionRecord` (con exerciseID, exerciseName, weightKg),
`SetLogRecord` (ripetizioni previste/fatte, interrotta, durata, `averagePeak` = proxy velocità, `lowConfidence`),
`ExerciseListRecord`, `TrainingPlanRecord` (JSON di `TrainingPlan`), `NutritionPlanRecord` (JSON di
`ParsedNutritionPlan`), `HealthProfileRecord` (sesso, età, altezza, peso, attività, obiettivo, diete).

Supabase: `docs/mygymhelper_schema.sql` (non eseguito, da provare). Schema `public`: `profiles`, `exercise_lists`,
`preset_lists`, `catalog_cache` (vincolo ≤ 30 giorni); schema `licensing` (non esposto): `entitlements`,
`store_events`; RLS su tutto; funzione `get_my_entitlement()`; trigger che alla registrazione crea profilo e licenza
Free. I dati sanitari non vanno nel cloud. Il database delle licenze può essere un secondo progetto (eseguire solo la parte `licensing`).

## 7. Backend ancora da scrivere

- Funzione `catalog` (Edge Function): legge MuscleWiki con la chiave in un segreto, assembla l'elenco `[Exercise]` (formato
  del DTO in `Exercises.swift`), lo salva in `catalog_cache` (≤ 30 giorni), risponde a `GET /catalog?lang=xx`.
- Funzione `apple-notifications`: riceve App Store Server Notifications V2, scrive `licensing.store_events` (idempotente)
  e aggiorna `licensing.entitlements`. Per collegare acquisto e utente, nell'app serve `appAccountToken` = id utente
  Supabase negli acquisti StoreKit (non ancora fatto). Google Play (RTDN) quando arriverà Android.
- Cancellazione account dentro l'app (richiesta da Apple): funzione che chiama la cancellazione utente Supabase.
- Consigliato RevenueCat solo se si vuole unificare iOS e Android (da valutare).

## 8. Cosa è stato verificato

- Python: rilevatore di ripetizioni (6 scenari), macchina a stati della sessione, parser delle schede (esempio realistico),
  parser della scheda alimentare.
- Controlli statici: bilanciamento di parentesi nei file Swift, struttura dello zip.
- **Non verificato**: compilazione, test Swift, SwiftUI/Liquid Glass (`glassEffect`, `.glassProminent`), SwiftData, StoreKit,
  CoreMotion su dispositivo, voce/suoni, soglie di conteggio con movimenti reali, parser su PDF/foto reali, MuscleWiki.

## 9. Lavoro rimasto (in ordine consigliato)

A. **Completare il blocco "esercizi + coaching + schede + alimentazione" (già a metà)**
1. `MyGymHelperApp`: creare e iniettare `CatalogStore` (`.environment(catalog)`).
2. `WorkoutSetupView`: aggiungere `init(exercise: CatalogExercise? = nil)`, riga del peso (passo 1,25 kg), carte di
   consiglio: Full → `CoachingService.adaptive` con pulsante "Applica"; Mid → `CoachingService.fixed`; passare
   esercizio e peso a `WorkoutSessionView`/`SessionController` (il controller li accetta già) e salvare nello storico.
3. `WorkoutSessionView` e `SessionSummaryView`: nuovi parametri; consigli adattivi (Full) calcolati con la sessione appena
   finita; consigli fissi (Mid) con `isCompound`/`isLowerBody` dell'esercizio; spostare la mappa `CoachingAdvice` → testo in un'estensione condivisa.
4. `TrainingPlansView` (elenco/dettaglio/eliminazione schede) e **importazione schede** (Full, con consenso): `UIDocumentPicker`/
   `fileImporter` + `PhotosPicker`; estrazione testo con PDFKit (`PDFDocument.string`) e, se vuoto, OCR Vision
   (`VNRecognizeTextRequest`, `.accurate`, rilevamento lingua); `TrainingPlanParser`; **schermata di revisione modificabile**
   prima di salvare; riga "AI locale" disattivata con nota (non implementata).
5. **Schermata Alimentazione** (tab): profilo (`HealthProfileRecord`), BMI (Free), obiettivi calorie/macro (Mid+), scelta
   diete multiple, pasti con `DietPlanner` e giorno di allenamento (Full), importazione scheda del nutrizionista con
   `NutritionPlanParser` e revisione, ricerca alimenti Open Food Facts (client `URLSession` con User-Agent, decodifica
   tollerante dei numeri) con attribuzione. Eliminare il vecchio `BMIView` o integrarlo.
6. `ContentView`: nuove tab (Allenamento, Esercizi, Nutrizione, Piani, Info); decidere dove sta il BMI.
7. `Localizable.xcstrings`: aggiungere le chiavi mancanti (it/en): `ex.*`, `lists.*`, `map.*`, `mech.*`, `rec.*`,
   chiavi dinamiche `muscle.<nome>` (14), `region.<nome>` (6), `food.*`, `meal.*`, chiavi nuove `coach.*` (progress, morereps,
   addset, keepfatigue, highfatigue, reduce, deload) e le stringhe delle nuove schermate. Uno script può confrontare le
   chiavi usate nel codice con quelle del catalogo (le chiavi dinamiche vanno aggiunte a mano).
8. Aggiornare README e rigenerare lo zip.

B. **Da provare su iPhone vero** (priorità alta): conteggio ripetizioni e soglie con movimenti reali (braccio e gamba),
   calibrazione, avvisi vocali, comportamento a schermo spento.

C. **Altre funzioni**: Apple Salute (peso in lettura, allenamenti in scrittura), app Apple Watch (CoreMotion sul watch,
   `WatchConnectivity`, Mid+), login Supabase (email/Google/Apple) e schermate account, `appAccountToken`, funzioni di backend
   (sezione 7), cancellazione account, AI locale (scelta del runtime, download del modello dopo consenso, uso di
   `PlanAIOutput` per validare l'uscita), illustrazioni proprie degli esercizi, icona e schermata di avvio, traduzioni
   (anche dei testi legali, rivedute da un legale), pagina web della privacy, testi dello store (con il disclaimer),
   prodotti in App Store Connect, test UI, Android (Kotlin + Jetpack Compose, riusando specifiche e test del Core).

D. **Punti aperti con l'utente**: cosa sincronizzare nel cloud e come gestire backup/cambio telefono; conferma della
   divisione Free/Mid/Full (in particolare: la selezione muscoli è nel Mid secondo `FeatureGate`, ma la vista oggi la
   mostra a tutti sul catalogo limitato); offerta di lancio; costo del piano MuscleWiki (serve GROWTH per le lingue) o
   alternativa; modello AI locale definitivo; chi crea le illustrazioni; nome definitivo e identità grafica.

## 10. Come ricreare da zero

1. Creare il pacchetto `Core` con i file della sezione 5.1 nell'ordine: Tier → BMI/Nutrition → Muscles/Catalog/Exercises →
   RepDetector → SessionEngine → Progression → Recommender → AdaptiveCoach → PlanParser → Diet → CachedExerciseProvider,
   scrivendo prima i test descritti (i casi sono nei file `Tests/`), poi l'implementazione. Rispettare le costanti della 5.1.
2. Creare il progetto iOS 26 (SwiftUI) e aggiungere il pacchetto in locale; impostare le opzioni della sezione 4.
3. Scrivere nell'ordine: Theme → Legal/Consent/Onboarding/Info → Persistence → Motion/Cue/SessionController → schermate
   allenamento → catalogo/mappa/elenchi → abbonamenti → import schede → alimentazione → localizzazione.
4. Eseguire lo schema SQL su Supabase e scrivere le funzioni della sezione 7.
5. Collaudare su iPhone, tarare le soglie, far rivedere i testi legali, poi App Store Connect.

## 11. Regole di lavoro per chi continua

- Rispondere e commentare in italiano; chiedere conferma sulle scelte di prodotto prima di cambiarle.
- Non copiare codice da opengym; non salvare immagini/video MuscleWiki; non mettere chiavi API nell'app.
- Non fare commit; consegnare file o zip. Dichiarare sempre cosa non è stato compilato o provato.
- Non presentare i testi legali come definitivi; non fare affermazioni mediche; mantenere i disclaimer.
- Ogni dato sanitario nuovo va in SwiftData (non in UserDefaults), richiede consenso e va incluso in `LocalData.deleteHealthData()`.

## 12. Fase 2 – 19 ottobre 2026

Stato in una riga: blocco 9.A completato; tutto il codice è scritto ma **ancora mai compilato** e i test Swift **mai eseguiti**.
Controlli fatti: sintassi di tutti i file Swift con un parser (tree-sitter), chiavi di localizzazione usate nel codice
confrontate con il catalogo, riferimenti interni del `project.pbxproj`, revisione del codice da un secondo assistente.

Fatto
- Rinomina completa PalestrApp → MyGymHelper (cartelle, modulo, entrata `MyGymHelperApp`, ID prodotto, cartella dati, schema SQL).
- `MyGymHelper.xcodeproj` (Xcode 26, cartella `App/` sincronizzata, pacchetto locale `Core`, impostazioni della sezione 4),
  `project.yml` per XcodeGen come riserva, `Support/Info.plist` (chiavi personalizzate), `Support/MyGymHelper.storekit`
  (4 abbonamenti in un gruppo, prova di 7 giorni), `App/Assets.xcassets` (icona vuota, colore d'accento).
- Core: `WorkoutParameters` (limiti, arrotondamento a 1,25 kg, applicazione dei consigli Mid e Full; corpo libero = +1 ripetizione
  invece di +carico), `FoodFacts` (client Open Food Facts con User-Agent e decodifica tollerante). Test in `Phase2Tests.swift`.
- App:
  - `MyGymHelperApp`: inietta `CatalogStore`. `ContentView`: schede Allenamento, Esercizi, Nutrizione, Piani, Info
    (il BMI è nella scheda Nutrizione; il vecchio `BMIView` è stato eliminato).
  - `WorkoutSetupView(exercise:)`: scelta esercizio, riga del peso, precompilazione da ultima sessione o scheda,
    consigli Full (adattivi) / Mid (regole fisse) con "Applica"; passa esercizio e peso alla sessione.
  - `WorkoutSessionView`/`SessionSummaryView`: nuovi parametri, consiglio adattivo calcolato con la sessione appena finita,
    regole fisse con `isCompound`/`isLowerBody` reali. Testi dei consigli in `CoachingText.swift`.
  - `TrainingPlansView` + `TextExtractor`: elenco/dettaglio/modifica/eliminazione schede, importazione da file
    (PDF, immagine, testo) e da Foto, OCR Vision se il PDF non ha testo, revisione modificabile, riga "AI locale" disattivata.
  - `NutritionView` + `FoodSearchView`: profilo, BMI, fabbisogno, diete multiple (onnivora esclusiva), pasti con giorno
    di allenamento, scheda del nutrizionista con revisione (se ne tiene una), ricerca Open Food Facts con attribuzione.
  - `HistoryView` mostra esercizio e peso; `InfoView` ha la sezione "Fonti dei dati".
  - `Localizable.xcstrings`: aggiunte circa 200 chiavi it/en (comprese le dinamiche `muscle.*`, `region.*`, `food.*`,
    `meal.*`, `diet.*`, `coach.*`, `rec.*`).

Punti da verificare al primo build
- API iOS 26 non provate: `glassEffect`, stili `.glass`/`.glassProminent`, `Tab`, `TextField(value:format:)` con opzionali.
- Apertura del `.xcodeproj` scritto a mano (in caso di problemi usare XcodeGen con `project.yml`).
- Le Legal/*.md devono finire tra le risorse del bundle (la cartella sincronizzata dovrebbe farlo da sola).

Ancora da fare: sezioni 9.B, 9.C e 9.D (prova su iPhone, Apple Watch, HealthKit, login Supabase, backend, AI locale,
illustrazioni, traduzioni dei testi legali, App Store Connect, Android). Punto 9.D ancora aperto: la mappa dei muscoli è
visibile anche nel Free, mentre `FeatureGate` mette `muscleSelection` nel Mid (non cambiato, decisione di prodotto).

## 13. Fase 3 – 20 ottobre 2026 (pronta per lo store, Apple Salute, backend)

Scelte dell'utente: preparare l'app per lo store, aggiungere Apple Salute e il backend Supabase (con login);
vendita in **tutto il mondo** (quindi lingua di sviluppo inglese e testi legali anche in inglese).
Stato: codice Swift **mai compilato**; SQL eseguito su PostgreSQL di prova; Edge Functions controllate con `deno check`.

Fatto
- Piani: `SubscriptionStoreView` di StoreKit (conformità 3.1.2 gestita da Apple), confronto Free/Mid/Full con le sole
  funzioni presenti, ripristino e "Gestisci"; acquisti con `appAccountToken` = id utente Supabase se c'è l'accesso;
  aggiornamento dello stato al ritorno nell'app. I blocchi "disponibile con Mid/Full" aprono i Piani.
- `PrivacyInfo.xcprivacy` (UserDefaults CA92.1, tempo di avvio 35F9.1, e-mail/ID utente/acquisti collegati,
  nessun tracciamento), `ITSAppUsesNonExemptEncryption = NO`, icona 1024 provvisoria, versione 1.0.
- Lingua di sviluppo `en`, `InfoPlist.xcstrings` (testi dei permessi in it/en), testi legali `*.en.md`
  (traduzione della bozza), nuova sezione 11 dell'informativa (Salute, Open Food Facts, cancellazione account).
- Apple Salute: `HealthKitService` (lettura peso/altezza su richiesta, scrittura allenamenti), interruttore in Info,
  pulsante "Importa da Salute" nel profilo, entitlement HealthKit. Disattivata alla revoca del consenso.
- Account: `AccountService` (supabase-swift 2.x: e-mail con codice OTP, Accedi con Apple con nonce, Google OAuth),
  `AccountView` con uscita ed eliminazione (funzione `delete-account`). Il catalogo usa le Edge Functions se
  `MyGymHelperSupabaseURL` è impostato, con il token dell'utente o la chiave anon.
- Backend: `supabase/` con migrazioni (schema + funzioni `licensing_record_event`, `licensing_apply_entitlement`
  riservate alla service role) e funzioni `catalog`, `apple-notifications` (libreria ufficiale Apple),
  `delete-account`. Guida: `docs/BACKEND.md`. Testi per lo store: `docs/STORE_TEXTS.md`.
- Bug corretti: controller della sessione creato una sola volta; sensori non riaccesi tornando su una sessione
  finita; cancellazione dei dati con il contesto principale (le liste si aggiornano subito); "Elimina tutti i dati"
  riporta subito a disclaimer e consenso; documenti legali letti una sola volta; ripristino acquisti aggiorna il piano.

Ancora da fare
- Compilare e provare su iPhone (soprattutto conteggio, Salute, accessi, acquisti sandbox).
- Pubblicare informativa privacy su una pagina web e compilare i segnaposto; revisione legale delle bozze (it/en).
- Icona definitiva, screenshot per lo store, eventuale catalogo MuscleWiki (piano a pagamento, GROWTH per le lingue).
- Apple Watch, AI locale: non iniziati. Android: vedi sezione 14.

### 13.1 Aggiornamento: revoca dei token Apple (20 ottobre 2026)
- Eliminando l'account, chi e' entrato con Apple conferma con Apple (`AccountView`); l'app invia il codice di
  autorizzazione a `delete-account`, che lo scambia e revoca i token (`supabase/functions/_shared/apple.ts`).
  Nessun token Apple viene salvato. Test Deno in `_shared/apple_test.ts` (passano). Segreti: `docs/BACKEND.md`.

## 14. Porting Android – 20 ottobre 2026

Scelte dell'utente: porting completo "come iOS" (logica, tutte le schermate, conteggio con i sensori,
abbonamenti Google Play, Health Connect, account Supabase con Google ed e-mail, funzione server per le notifiche
Google Play); Android 9 (API 28) e successivi. Guida operativa: `docs/ANDROID.md`.

Stato
- `android/core`: port Kotlin 1:1 del pacchetto Swift Core, **compilato con Kotlin 2.2 e 53 test JUnit superati**.
  Trovata e corretta in entrambe le versioni una differenza nel parser: `rec 3"` ora vale 180 secondi
  (un valore in secondi sotto 10 si interpreta come minuti).
- `android/app`: Compose + Material 3, **mai compilata** (repository Google/Maven non raggiungibili da qui);
  controllo sintattico e revisione indipendente fatti, correzioni applicate.
- Backend: `google-play-notifications` (Pub/Sub OIDC + Play Developer API v2), migrazione
  `20261021000000_google_play.sql` (provata su PostgreSQL), `delete-account` accetta `platform: android`.
  Test Deno: 9 superati (Apple e Google).

Scelte tecniche
- Navigazione manuale con una pila per scheda (niente navigation-compose), stato con StateFlow e Compose state.
- Dati sanitari in un file JSON in `noBackupFilesDir`, backup disattivato; si scrive solo con il consenso.
- Testi: generati dal catalogo iOS (`tools/xcstrings_to_android.py`), stesse chiavi; testi solo Android in
  `tools/android_strings.json`. Informativa privacy Android adattata (Google Play, Health Connect).
- Prodotti Play: `mygymhelper_mid`, `mygymhelper_full`, piani base `monthly`/`yearly`, offerta `free-trial`.

Ancora da fare (Android)
- Compilare in Android Studio, correggere eventuali errori, provare su telefoni veri (soglie del conteggio).
- Play Console: abbonamenti, notifiche, account di servizio, scheda Sicurezza dei dati, dichiarazione Health Connect.
- Revisione legale dell'informativa Android; pagina web per la richiesta di eliminazione dell'account.
