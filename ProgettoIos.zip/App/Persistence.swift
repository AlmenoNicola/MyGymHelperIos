import Foundation
import SwiftData

/// Storico degli allenamenti. Contiene dati sulla salute: si salva solo con il consenso
/// e l'archivio e' escluso dai backup (iCloud) per mantenere i dati solo sul telefono.
@Model
final class WorkoutSessionRecord {
    var id: UUID = UUID()
    var startedAt: Date = Date()
    var endedAt: Date?
    var limb: String = "arm"
    var plannedSets: Int = 0
    var plannedReps: Int = 0
    var restSeconds: Int = 0
    var exerciseID: String = ""
    var exerciseName: String = ""
    var weightKg: Double = 0
    @Relationship(deleteRule: .cascade, inverse: \SetLogRecord.session) var sets: [SetLogRecord] = []

    init(startedAt: Date, endedAt: Date?, limb: String, plannedSets: Int, plannedReps: Int, restSeconds: Int,
         exerciseID: String = "", exerciseName: String = "", weightKg: Double = 0) {
        self.exerciseID = exerciseID
        self.exerciseName = exerciseName
        self.weightKg = weightKg
        self.startedAt = startedAt
        self.endedAt = endedAt
        self.limb = limb
        self.plannedSets = plannedSets
        self.plannedReps = plannedReps
        self.restSeconds = restSeconds
    }
}

@Model
final class SetLogRecord {
    var number: Int = 0
    var plannedReps: Int = 0
    var doneReps: Int = 0
    var stoppedEarly: Bool = false
    var durationSeconds: Double = 0
    var averagePeak: Double = 0        // proxy della velocita' del movimento
    var lowConfidence: Bool = false    // segnale poco affidabile (per esempio telefono in tasca)
    var session: WorkoutSessionRecord?

    init(number: Int, plannedReps: Int, doneReps: Int, stoppedEarly: Bool,
         durationSeconds: Double, averagePeak: Double, lowConfidence: Bool) {
        self.number = number
        self.plannedReps = plannedReps
        self.doneReps = doneReps
        self.stoppedEarly = stoppedEarly
        self.durationSeconds = durationSeconds
        self.averagePeak = averagePeak
        self.lowConfidence = lowConfidence
    }
}

/// Elenco di esercizi salvato dall'utente (piani Mid e Full).
@Model
final class ExerciseListRecord {
    var id: UUID = UUID()
    var name: String = ""
    var exerciseIDs: [String] = []
    var createdAt: Date = Date()

    init(name: String, exerciseIDs: [String] = []) {
        self.name = name
        self.exerciseIDs = exerciseIDs
    }
}

/// Scheda di allenamento caricata dall'utente (piano Full). `data` e' un TrainingPlan in JSON.
@Model
final class TrainingPlanRecord {
    var id: UUID = UUID()
    var name: String = ""
    var createdAt: Date = Date()
    var data: Data = Data()

    init(name: String, data: Data) {
        self.name = name
        self.data = data
    }
}

/// Scheda del nutrizionista caricata dall'utente (piano Full). `data` e' un ParsedNutritionPlan in JSON.
@Model
final class NutritionPlanRecord {
    var id: UUID = UUID()
    var createdAt: Date = Date()
    var data: Data = Data()

    init(data: Data) { self.data = data }
}

/// Profilo con dati sulla salute (peso, altezza, eta', obiettivo, dieta). Solo sul telefono.
@Model
final class HealthProfileRecord {
    var sex: String = "male"
    var age: Int = 30
    var heightCm: Double = 170
    var weightKg: Double = 70
    var activity: Double = 1.375
    var goal: String = "maintain"
    var diets: [String] = ["omnivore"]

    init() {}
}

enum PersistenceController {
    static let container: ModelContainer = {
        let schema = Schema([WorkoutSessionRecord.self, SetLogRecord.self, ExerciseListRecord.self,
                             TrainingPlanRecord.self, NutritionPlanRecord.self, HealthProfileRecord.self])
        var dir = URL.applicationSupportDirectory.appending(path: "MyGymHelperData", directoryHint: .isDirectory)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? dir.setResourceValues(values)
        let config = ModelConfiguration(schema: schema, url: dir.appending(path: "store.sqlite"))
        do {
            return try ModelContainer(for: schema, configurations: [config])
        } catch {
            fatalError("Impossibile aprire l'archivio locale: \(error)")
        }
    }()
}
