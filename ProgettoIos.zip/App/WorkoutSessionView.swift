import SwiftUI
import SwiftData
import MyGymHelperCore

/// Sessione di allenamento: serie, conteggio live, pausa con conto alla rovescia, "mi sono fermato", riepilogo.
/// Il controller (sensori, voce) si crea UNA sola volta quando la schermata compare: SwiftUI puo' ricreare
/// la struttura della vista molte volte e un `State(initialValue:)` nell'init costruirebbe controller inutili.
struct WorkoutSessionView: View {
    let limb: BodyLimb
    let parameters: WorkoutParameters
    var exercise: CatalogExercise? = nil
    @State private var controller: SessionController?

    var body: some View {
        if let controller {
            SessionContent(controller: controller)
        } else {
            Color.clear
                .appScreen()
                .onAppear {
                    controller = SessionController(limb: limb, sets: parameters.sets, reps: parameters.reps,
                                                   restSeconds: parameters.restSeconds, exercise: exercise,
                                                   weightKg: parameters.weightKg, options: .fromDefaults())
                }
        }
    }
}

private struct SessionContent: View {
    let controller: SessionController
    @State private var showStop = false
    @State private var saved = false
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Environment(SubscriptionManager.self) private var subscriptions
    @AppStorage(ConsentStore.grantedAtKey) private var consentAt = 0.0
    private let timer = Timer.publish(every: 0.25, on: .main, in: .common).autoconnect()

    var body: some View {
        Group {
            switch controller.phase {
            case .notStarted, .working:
                workingView
            case .resting(let afterSet, let remaining):
                restView(afterSet: afterSet, remaining: remaining)
            case .finished:
                SessionSummaryView(controller: controller, tier: subscriptions.tier, saved: saved) { dismiss() }
            }
        }
        .padding(20)
        .appScreen()
        .navigationBarBackButtonHidden(controller.phase != .finished)
        .onAppear { controller.start() }
        .onDisappear { controller.end() }
        .onReceive(timer) { _ in controller.tick() }
        .onChange(of: controller.phase) { _, new in if new == .finished { save() } }
        .sheet(isPresented: $showStop) {
            StopSheet(target: controller.targetReps, initial: controller.currentReps) { done in
                controller.stop(doneReps: done)
            }
            .presentationDetents([.medium])
        }
    }

    private var progressBar: some View {
        HStack(spacing: 8) {
            ForEach(1...controller.totalSets, id: \.self) { n in
                Capsule()
                    .fill(n <= controller.records.count ? AnyShapeStyle(Theme.accentGradient)
                          : n == controller.currentSetNumber ? AnyShapeStyle(Theme.accent.opacity(0.55))
                          : AnyShapeStyle(.white.opacity(0.12)))
                    .frame(height: 8)
            }
        }
    }

    private var workingView: some View {
        VStack(spacing: 26) {
            progressBar
            VStack(spacing: 4) {
                if let exercise = controller.exercise {
                    Text(verbatim: exercise.name).font(.title3.bold())
                }
                Text("session.set \(controller.currentSetNumber) \(controller.totalSets)")
                    .font(.headline).foregroundStyle(.secondary)
                if controller.weightKg > 0 {
                    Text(verbatim: controller.weightKg.kgText).font(.subheadline).foregroundStyle(Theme.accentSoft)
                }
            }

            RepRing(count: controller.currentReps, target: controller.targetReps)

            if !controller.motion.isAvailable {
                Label("session.noSensor", systemImage: "exclamationmark.triangle.fill")
                    .font(.subheadline).foregroundStyle(.orange).glassCard(padding: 14)
            } else if controller.motion.isCalibrating {
                Label("session.calibrating", systemImage: "waveform.path")
                    .font(.subheadline).glassCard(padding: 14)
            } else if controller.motion.lowConfidence {
                Label("workout.pocketWarning", systemImage: "exclamationmark.triangle.fill")
                    .font(.subheadline).foregroundStyle(.orange).glassCard(padding: 14)
            }

            Spacer(minLength: 0)

            Button { showStop = true } label: {
                Label("session.stopped", systemImage: "hand.raised.fill")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
            }
            .buttonStyle(.glass).tint(.red)

            Button("session.end") { controller.endEarly() }
                .font(.subheadline).foregroundStyle(.secondary)
        }
    }

    private func restView(afterSet: Int, remaining: Int) -> some View {
        VStack(spacing: 26) {
            progressBar
            Text("session.rest").font(.headline).foregroundStyle(.secondary)
            CountdownRing(remaining: remaining, total: controller.restSeconds)
            Text("session.next \(afterSet + 1)").font(.title3.bold())
            Spacer(minLength: 0)
            Button { controller.skipRest() } label: {
                Label("session.skipRest", systemImage: "forward.fill")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
            }
            .buttonStyle(.glassProminent).tint(Theme.accent)
            Button("session.end") { controller.endEarly() }
                .font(.subheadline).foregroundStyle(.secondary)
        }
    }

    /// Lo storico contiene dati sulla salute: si salva solo se l'utente ha dato il consenso.
    private func save() {
        guard !saved, consentAt > 0, !controller.records.isEmpty else { return }
        saved = true
        context.insert(controller.makeRecord())
        try? context.save()
        // Apple Salute: solo se l'utente l'ha collegata (Info) e con il consenso ai dati sanitari.
        let start = controller.startedAt, name = controller.exercise?.name
        Task { await HealthKitService.shared.saveWorkoutIfEnabled(start: start, end: Date(), title: name) }
    }
}

/// Anello della pausa: si svuota man mano che il tempo passa.
struct CountdownRing: View {
    let remaining: Int
    let total: Int

    private var progress: Double { total > 0 ? Double(remaining) / Double(total) : 0 }

    var body: some View {
        ZStack {
            Circle().stroke(.white.opacity(0.10), lineWidth: 22)
            Circle()
                .trim(from: 0, to: progress)
                .stroke(Theme.accentGradient, style: StrokeStyle(lineWidth: 22, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .animation(.linear(duration: 0.3), value: progress)
            Text("\(remaining)")
                .font(.system(size: 92, weight: .heavy, design: .rounded).monospacedDigit())
                .contentTransition(.numericText())
        }
        .frame(width: 270, height: 270)
    }
}

/// Foglio per dire "mi sono fermato" e indicare quante ripetizioni sono state fatte.
struct StopSheet: View {
    let target: Int
    var onConfirm: (Int) -> Void
    @State private var reps: Int
    @Environment(\.dismiss) private var dismiss

    init(target: Int, initial: Int, onConfirm: @escaping (Int) -> Void) {
        self.target = target
        self.onConfirm = onConfirm
        _reps = State(initialValue: min(initial, target))
    }

    var body: some View {
        ZStack {
            AppBackground()
            VStack(spacing: 22) {
                Text("stop.title").font(.title3.bold())
                CounterRow(title: "counter.reps", value: $reps, range: 0...target).glassCard()
                Button {
                    onConfirm(reps); dismiss()
                } label: {
                    Text("stop.confirm").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
                }
                .buttonStyle(.glassProminent).tint(Theme.accent)
                Button("info.cancel") { dismiss() }.buttonStyle(.glass)
            }
            .padding(24)
        }
    }
}
