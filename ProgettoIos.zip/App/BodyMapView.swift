import SwiftUI
import MyGymHelperCore

extension MuscleGroup {
    var title: String { Bundle.main.localizedString(forKey: "muscle.\(rawValue)", value: rawValue, table: nil) }
}

extension BodyRegion {
    var title: String { Bundle.main.localizedString(forKey: "region.\(rawValue)", value: rawValue, table: nil) }
    var symbol: String {
        switch self {
        case .arms: return "figure.strengthtraining.traditional"
        case .legs: return "figure.walk"
        case .chest: return "heart.fill"
        case .back: return "figure.mind.and.body"
        case .shoulders: return "figure.arms.open"
        case .core: return "circle.hexagongrid.fill"
        }
    }
}

enum BodySide: String, CaseIterable, Identifiable {
    case front, back
    var id: String { rawValue }
    var titleKey: LocalizedStringKey { self == .front ? "map.front" : "map.back" }
}

private struct Zone: Identifiable {
    let id: String
    let muscle: MuscleGroup
    let cx: CGFloat, cy: CGFloat, w: CGFloat, h: CGFloat
    let mirrored: Bool
    init(_ muscle: MuscleGroup, _ cx: CGFloat, _ cy: CGFloat, _ w: CGFloat, _ h: CGFloat, mirrored: Bool = true) {
        self.id = "\(muscle.rawValue)-\(cx)-\(cy)"
        self.muscle = muscle; self.cx = cx; self.cy = cy; self.w = w; self.h = h; self.mirrored = mirrored
    }
}

/// Mappa del corpo schematica (disegnata da noi): tocca un muscolo per sceglierlo, fronte o retro.
struct BodyMapView: View {
    let side: BodySide
    @Binding var selected: Set<MuscleGroup>

    private var zones: [Zone] {
        switch side {
        case .front:
            return [Zone(.shoulders, 27, 47, 17, 17), Zone(.chest, 41, 58, 16, 17), Zone(.abs, 50, 86, 15, 30, mirrored: false),
                    Zone(.obliques, 37, 88, 7, 28), Zone(.biceps, 18, 70, 10, 24), Zone(.forearms, 14, 98, 9, 28),
                    Zone(.quads, 40, 142, 17, 50), Zone(.calves, 39, 196, 12, 36)]
        case .back:
            return [Zone(.traps, 50, 46, 22, 16, mirrored: false), Zone(.shoulders, 27, 50, 16, 16), Zone(.lats, 40, 76, 16, 30),
                    Zone(.lowerBack, 50, 104, 18, 16, mirrored: false), Zone(.triceps, 18, 70, 10, 24), Zone(.forearms, 14, 98, 9, 28),
                    Zone(.glutes, 42, 128, 17, 17), Zone(.hamstrings, 40, 158, 16, 32), Zone(.calves, 39, 200, 12, 32)]
        }
    }

    var body: some View {
        GeometryReader { geo in
            let scale = geo.size.width / 100
            ZStack {
                silhouette(scale)
                ForEach(zones) { zone in
                    zoneShape(zone, mirror: false, scale: scale)
                    if zone.mirrored { zoneShape(zone, mirror: true, scale: scale) }
                }
            }
        }
        .aspectRatio(100.0 / 225.0, contentMode: .fit)
        .sensoryFeedback(.selection, trigger: selected)
    }

    private func zoneShape(_ zone: Zone, mirror: Bool, scale: CGFloat) -> some View {
        let on = selected.contains(zone.muscle)
        let radius = min(zone.w, zone.h) * scale / 2.2
        return RoundedRectangle(cornerRadius: radius)
            .fill(on ? AnyShapeStyle(Theme.accentGradient) : AnyShapeStyle(.white.opacity(0.14)))
            .overlay(RoundedRectangle(cornerRadius: radius).stroke(.white.opacity(on ? 0.6 : 0.25), lineWidth: 1))
            .frame(width: zone.w * scale, height: zone.h * scale)
            .position(x: (mirror ? 100 - zone.cx : zone.cx) * scale, y: zone.cy * scale)
            .contentShape(Rectangle().size(width: zone.w * scale, height: zone.h * scale))
            .onTapGesture {
                if on { selected.remove(zone.muscle) } else { selected.insert(zone.muscle) }
            }
            .accessibilityLabel(Text(zone.muscle.title))
            .accessibilityAddTraits(on ? .isSelected : [])
    }

    private func silhouette(_ s: CGFloat) -> some View {
        ZStack {
            Circle().frame(width: 22 * s, height: 22 * s).position(x: 50 * s, y: 14 * s)
            RoundedRectangle(cornerRadius: 6 * s).frame(width: 8 * s, height: 8 * s).position(x: 50 * s, y: 30 * s)
            RoundedRectangle(cornerRadius: 10 * s).frame(width: 46 * s, height: 78 * s).position(x: 50 * s, y: 80 * s)
            RoundedRectangle(cornerRadius: 6 * s).frame(width: 12 * s, height: 78 * s).position(x: 17 * s, y: 86 * s)
            RoundedRectangle(cornerRadius: 6 * s).frame(width: 12 * s, height: 78 * s).position(x: 83 * s, y: 86 * s)
            RoundedRectangle(cornerRadius: 8 * s).frame(width: 20 * s, height: 112 * s).position(x: 40 * s, y: 168 * s)
            RoundedRectangle(cornerRadius: 8 * s).frame(width: 20 * s, height: 112 * s).position(x: 60 * s, y: 168 * s)
        }
        .foregroundStyle(.white.opacity(0.06))
    }
}

/// Blocchi predefiniti (braccia, gambe, torace...): un tocco seleziona tutti i muscoli della zona.
struct RegionChips: View {
    @Binding var selected: Set<MuscleGroup>

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(BodyRegion.allCases, id: \.self) { region in
                    let all = Set(region.muscles)
                    let on = all.isSubset(of: selected)
                    Button {
                        if on { selected.subtract(all) } else { selected.formUnion(all) }
                    } label: {
                        Label(region.title, systemImage: region.symbol)
                            .font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 14).padding(.vertical, 9)
                            .foregroundStyle(on ? Color.white : Color.primary)
                            .background(on ? AnyShapeStyle(Theme.accentGradient) : AnyShapeStyle(.white.opacity(0.10)), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
