import Foundation
import Observation
import UIKit
import MyGymHelperCore

/// Collega macchina a stati, sensori, avvisi e salvataggio di una sessione di allenamento.
@Observable
@MainActor
final class SessionController {
    let limb: BodyLimb
    let totalSets: Int
    let targetReps: Int
    let restSeconds: Int
    let exercise: CatalogExercise?
    let weightKg: Double
    let startedAt = Date()
    let motion = MotionService()

    private(set) var phase: SessionPhase = .notStarted
    private(set) var currentReps = 0
    private(set) var records: [SetRecord] = []

    @ObservationIgnored private var engine: SessionEngine
    @ObservationIgnored private let cues = CueService()
    @ObservationIgnored private var metrics: [(peak: Double, low: Bool)] = []
    @ObservationIgnored private var running = false

    init(limb: BodyLimb, sets: Int, reps: Int, restSeconds: Int, exercise: CatalogExercise?, weightKg: Double, options: CueOptions) {
        self.limb = limb
        self.exercise = exercise
        self.weightKg = weightKg
        self.totalSets = max(1, sets)
        self.targetReps = max(1, reps)
        self.restSeconds = restSeconds
        self.engine = SessionEngine(sets: sets, reps: reps, restSeconds: restSeconds)
        self.cues.options = options
    }

    /// Orologio monotono: non cambia se l'utente modifica l'ora del telefono.
    private var now: TimeInterval { ProcessInfo.processInfo.systemUptime }

    var currentSetNumber: Int {
        switch phase {
        case .working(let n): return n
        case .resting(let n, _): return n + 1
        case .notStarted: return 1
        default: return records.count
        }
    }

    func start() {
        // Solo la prima volta: tornando sulla schermata a sessione finita (per esempio dai Piani) non si riaccendono i sensori.
        guard !running, phase == .notStarted else { return }
        running = true
        UIApplication.shared.isIdleTimerDisabled = true   // schermo acceso: i sensori si fermano se l'app va in background
        motion.onRepCount = { [weak self] count in
            Task { @MainActor in self?.repsUpdated(count) }
        }
        motion.start()
        motion.beginSet()
        apply(engine.start(at: now))
    }

    /// Da chiamare circa 4 volte al secondo.
    func tick() { apply(engine.tick(at: now)) }

    func stop(doneReps: Int) { apply(engine.stop(doneReps: doneReps, at: now)) }
    func skipRest() { apply(engine.skipRest(at: now)) }
    func endEarly() { apply(engine.endNow(at: now)) }

    /// Rilascia sensori, schermo e audio.
    func end() {
        guard running else { return }
        running = false
        motion.stop()
        UIApplication.shared.isIdleTimerDisabled = false
        cues.shutdown()
    }

    private func repsUpdated(_ count: Int) {
        apply(engine.repsCounted(count, at: now))
    }

    private func apply(_ list: [SessionCue]) {
        for cue in list {
            cues.play(cue)
            switch cue {
            case .restStarted, .sessionFinished: motion.pauseCounting()
            case .restEnded: motion.beginSet()
            default: break
            }
        }
        phase = engine.phase
        currentReps = engine.currentReps
        records = engine.records
        while metrics.count < records.count {
            metrics.append((motion.averagePeak, motion.lowConfidence))
        }
    }

    /// La sessione appena svolta nel formato del motore adattivo (piano Full).
    func sample() -> SessionSample {
        SessionSample(date: startedAt, weightKg: weightKg, sets: records.enumerated().map { i, r in
            SessionSetSample(doneReps: r.doneReps, plannedReps: r.plannedReps, stoppedEarly: r.stoppedEarly,
                             averagePeak: i < metrics.count ? metrics[i].peak : 0)
        })
    }

    /// Record da salvare nello storico (solo con il consenso ai dati sulla salute).
    func makeRecord() -> WorkoutSessionRecord {
        let session = WorkoutSessionRecord(startedAt: startedAt, endedAt: Date(), limb: limb.rawValue,
                                           plannedSets: totalSets, plannedReps: targetReps, restSeconds: restSeconds,
                                           exerciseID: exercise?.id ?? "", exerciseName: exercise?.name ?? "", weightKg: weightKg)
        for (i, r) in records.enumerated() {
            let m = i < metrics.count ? metrics[i] : (peak: 0.0, low: false)
            session.sets.append(SetLogRecord(number: r.number, plannedReps: r.plannedReps, doneReps: r.doneReps,
                                             stoppedEarly: r.stoppedEarly, durationSeconds: r.durationSeconds,
                                             averagePeak: m.peak, lowConfidence: m.low))
        }
        return session
    }
}
