import SwiftUI
import SwiftData
import MyGymHelperCore

/// Riepilogo di fine allenamento. Mid: consigli a regole fisse. Full: consiglio adattivo per la prossima volta
/// (calcolato con lo storico dell'esercizio, la sessione appena finita e la scheda caricata).
struct SessionSummaryView: View {
    let controller: SessionController
    let tier: SubscriptionTier
    let saved: Bool
    var onDone: () -> Void

    @Query(sort: \WorkoutSessionRecord.startedAt) private var sessions: [WorkoutSessionRecord]
    @Query(sort: \TrainingPlanRecord.createdAt) private var plans: [TrainingPlanRecord]

    private var records: [SetRecord] { controller.records }

    private var current: WorkoutParameters {
        WorkoutParameters(sets: controller.totalSets, reps: controller.targetReps,
                          restSeconds: controller.restSeconds, weightKg: controller.weightKg)
    }

    /// Regole fisse: con l'esercizio si usano multiarticolare/gambe reali; senza, si deduce dall'arto scelto.
    private var fixed: CoachingResult? {
        guard FeatureGate.isAvailable(.fixedCoaching, for: tier), !records.isEmpty else { return nil }
        let compound = controller.exercise?.isCompound ?? false
        let lower = controller.exercise?.isLowerBody ?? (controller.limb == .leg)
        return FixedCoaching.advise(sets: records.map(\.outcome), isCompound: compound, isLowerBody: lower)
    }

    private var adaptive: AdaptiveAdvice? {
        guard FeatureGate.isAvailable(.adaptiveCoaching, for: tier), !records.isEmpty,
              let exercise = controller.exercise else { return nil }
        // La sessione appena salvata e' gia' nello storico: si esclude e si aggiunge quella in memoria.
        let past = sessions.filter { abs($0.startedAt.timeIntervalSince(controller.startedAt)) > 1 }
        let history = CoachingService.samples(for: exercise.id, from: past) + [controller.sample()]
        return AdaptiveCoach.advise(history: history, isCompound: exercise.isCompound,
                                    defaultSets: controller.totalSets, defaultReps: controller.targetReps,
                                    plan: CoachingService.planTarget(for: exercise, plans: plans))
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                ScreenHeader(symbol: "flag.checkered", title: "summary.title", subtitle: "summary.subtitle")

                VStack(spacing: 14) {
                    if let exercise = controller.exercise {
                        HStack {
                            Text(verbatim: exercise.name).font(.title3.bold())
                            Spacer()
                            if controller.weightKg > 0 { Text(verbatim: controller.weightKg.kgText).foregroundStyle(.secondary) }
                        }
                    }
                    ForEach(records, id: \.number) { r in
                        HStack {
                            Text("session.setResult \(r.number) \(r.doneReps) \(r.plannedReps)").font(.headline)
                            Spacer()
                            if r.stoppedEarly {
                                Text("session.stoppedTag").font(.caption.bold())
                                    .padding(.horizontal, 10).padding(.vertical, 4)
                                    .background(.red.opacity(0.35), in: Capsule())
                            } else {
                                Image(systemName: "checkmark.circle.fill").foregroundStyle(Theme.accent)
                            }
                        }
                    }
                    if records.isEmpty { Text("summary.empty").foregroundStyle(.secondary) }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .glassCard()

                if let adaptive {
                    AdviceCard(title: "advice.nextTime", reasons: adaptive.reasonKeys,
                               parameters: adaptive.parameters(keepingWeight: controller.weightKg))
                } else if let fixed {
                    AdviceCard(title: "advice.title", reasons: [fixed.reasonKey], parameters: fixed.applied(to: current),
                               details: fixed.advice.map { $0.textKey(bodyweight: controller.weightKg == 0) })
                } else if !records.isEmpty {
                    LockedNote(key: "advice.locked").glassCard(padding: 16)
                }

                if FeatureGate.isAvailable(.adaptiveCoaching, for: tier), controller.exercise == nil, !records.isEmpty {
                    Label("advice.chooseExercise", systemImage: "info.circle")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                if !saved {
                    Label("session.notSaved", systemImage: "info.circle")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Button(action: onDone) {
                    Text("session.done").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
                }
                .buttonStyle(.glassProminent).tint(Theme.accent)
            }
        }
    }
}
