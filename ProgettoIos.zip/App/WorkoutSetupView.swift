import SwiftUI
import SwiftData
import MyGymHelperCore

enum BodyLimb: String, CaseIterable, Identifiable {
    case arm, leg
    var id: String { rawValue }
    var titleKey: LocalizedStringKey { self == .arm ? "limb.arm" : "limb.leg" }
    var symbol: String { self == .arm ? "figure.strengthtraining.traditional" : "figure.walk" }
}

/// Impostazione dell'allenamento. Free: l'utente imposta serie, ripetizioni e pausa e il telefono conta.
/// Con un esercizio scelto: peso e consigli (Mid a regole fisse, Full adattivi con la scheda caricata).
struct WorkoutSetupView: View {
    @Environment(SubscriptionManager.self) private var subscriptions
    @Environment(CatalogStore.self) private var catalog
    @Query(sort: \WorkoutSessionRecord.startedAt) private var sessions: [WorkoutSessionRecord]
    @Query(sort: \TrainingPlanRecord.createdAt) private var plans: [TrainingPlanRecord]

    /// Vero se la schermata e' stata aperta da un esercizio (si mostra la barra di navigazione).
    private let openedWithExercise: Bool
    @State private var exercise: CatalogExercise?
    @State private var limb: BodyLimb
    @State private var sets = 3
    @State private var reps = 10
    @State private var restSeconds = 90
    @State private var weightKg = 0.0
    @State private var running = false
    @State private var showPicker = false
    @State private var prefilledFor: String?
    @AppStorage("cue.sound") private var soundOn = true
    @AppStorage("cue.voice") private var voiceOn = true
    @AppStorage("cue.haptics") private var hapticsOn = true

    init(exercise: CatalogExercise? = nil) {
        openedWithExercise = exercise != nil
        _exercise = State(initialValue: exercise)
        _limb = State(initialValue: (exercise?.isLowerBody ?? false) ? .leg : .arm)
    }

    private var tier: SubscriptionTier { subscriptions.tier }
    private var current: WorkoutParameters {
        WorkoutParameters(sets: sets, reps: reps, restSeconds: restSeconds, weightKg: weightKg)
    }

    private var adaptive: AdaptiveAdvice? {
        guard let exercise, FeatureGate.isAvailable(.adaptiveCoaching, for: tier) else { return nil }
        return CoachingService.adaptive(exercise: exercise, sessions: sessions, plans: plans,
                                        defaultSets: sets, defaultReps: reps)
    }

    private var fixed: CoachingResult? {
        guard let exercise, FeatureGate.isAvailable(.fixedCoaching, for: tier),
              !FeatureGate.isAvailable(.adaptiveCoaching, for: tier) else { return nil }
        return CoachingService.fixed(exercise: exercise, sessions: sessions)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                if !openedWithExercise {
                    ScreenHeader(symbol: "bolt.heart.fill", title: "setup.title", subtitle: "setup.subtitle")
                }
                exerciseCard
                limbPicker

                Label("workout.pocketWarning", systemImage: "iphone.gen3.radiowaves.left.and.right")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 6)

                adviceSection

                VStack(spacing: 18) {
                    CounterRow(title: "counter.sets", value: $sets, range: WorkoutParameters.setsRange)
                    Divider().overlay(.white.opacity(0.15))
                    CounterRow(title: "counter.reps", value: $reps, range: WorkoutParameters.repsRange)
                    Divider().overlay(.white.opacity(0.15))
                    CounterRow(title: "counter.rest", value: $restSeconds, range: WorkoutParameters.restRange, step: 15)
                    if exercise != nil {
                        Divider().overlay(.white.opacity(0.15))
                        WeightRow(title: "setup.weight", value: $weightKg)
                    }
                }
                .glassCard()

                VStack(alignment: .leading, spacing: 8) {
                    Text("cue.title").font(.headline)
                    Toggle("cue.voice", isOn: $voiceOn)
                    Toggle("cue.sound", isOn: $soundOn)
                    Toggle("cue.haptics", isOn: $hapticsOn)
                }
                .tint(Theme.accent)
                .glassCard()

                Button { running = true } label: {
                    Label("workout.start", systemImage: "play.fill")
                        .font(.title3.bold()).frame(maxWidth: .infinity).padding(.vertical, 8)
                }
                .buttonStyle(.glassProminent)
                .tint(Theme.accent)

                if !openedWithExercise {
                    NavigationLink { HistoryView() } label: {
                        Label("history.open", systemImage: "clock.arrow.circlepath").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.glass)
                }
            }
            .padding(20)
        }
        .appScreen()
        .toolbar(openedWithExercise ? .visible : .hidden, for: .navigationBar)
        .navigationTitle(Text(verbatim: openedWithExercise ? (exercise?.name ?? "") : ""))
        .navigationBarTitleDisplayMode(.inline)
        .navigationDestination(isPresented: $running) {
            WorkoutSessionView(limb: limb, parameters: current.clamped(), exercise: exercise)
        }
        .sheet(isPresented: $showPicker) {
            ExercisePickerSheet { picked in
                exercise = picked
                if let picked { limb = picked.isLowerBody ? .leg : .arm } else { weightKg = 0 }
                prefill()
            }
        }
        .onAppear(perform: prefill)
    }

    // MARK: - Sezioni

    private var exerciseCard: some View {
        HStack(spacing: 14) {
            Image(systemName: "dumbbell.fill").foregroundStyle(Theme.accent).frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text("setup.exercise").font(.caption).foregroundStyle(.secondary)
                if let exercise {
                    Text(verbatim: exercise.name).font(.headline)
                } else {
                    Text("setup.noExercise").font(.headline)
                }
            }
            Spacer()
            if !openedWithExercise {
                Button(exercise == nil ? "setup.choose" : "setup.change") { showPicker = true }
                    .buttonStyle(.glass)
            }
        }
        .glassCard(padding: 16)
    }

    private var limbPicker: some View {
        HStack(spacing: 14) {
            ForEach(BodyLimb.allCases) { item in
                Button { withAnimation(.snappy) { limb = item } } label: {
                    VStack(spacing: 10) {
                        Image(systemName: item.symbol).font(.system(size: 34, weight: .semibold))
                        Text(item.titleKey).font(.headline)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 22)
                    .foregroundStyle(limb == item ? Color.white : Color.secondary)
                    .background {
                        if limb == item {
                            RoundedRectangle(cornerRadius: 28).fill(Theme.accentGradient)
                                .shadow(color: Theme.accent.opacity(0.5), radius: 14, y: 6)
                        } else {
                            RoundedRectangle(cornerRadius: 28).fill(.white.opacity(0.07))
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .sensoryFeedback(.selection, trigger: limb)
    }

    @ViewBuilder
    private var adviceSection: some View {
        if exercise != nil {
            if let adaptive {
                let proposed = adaptive.parameters(keepingWeight: weightKg)
                AdviceCard(title: "advice.adaptiveTitle", reasons: adaptive.reasonKeys, parameters: proposed) {
                    apply(proposed)
                }
            } else if let fixed {
                AdviceCard(title: "advice.title", reasons: [fixed.reasonKey], parameters: fixed.applied(to: current),
                           details: fixed.advice.map { $0.textKey(bodyweight: weightKg == 0) }) {
                    apply(fixed.applied(to: current))
                }
            } else if FeatureGate.isAvailable(.fixedCoaching, for: tier) {
                Label("advice.noHistory", systemImage: "sparkles")
                    .font(.footnote).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
            } else {
                LockedNote(key: "advice.locked")
            }
        }
    }

    // MARK: - Azioni

    private func apply(_ p: WorkoutParameters) {
        withAnimation(.snappy) {
            sets = p.sets; reps = p.reps; restSeconds = p.restSeconds; weightKg = p.weightKg
        }
    }

    /// Precompila peso e obiettivi dall'ultima sessione dell'esercizio o dalla scheda (una sola volta per esercizio).
    private func prefill() {
        guard let exercise, prefilledFor != exercise.id else { return }
        prefilledFor = exercise.id
        if let target = CoachingService.planTarget(for: exercise, plans: plans) {
            if let s = target.sets { sets = s }
            if let r = target.repsMin { reps = r }
            if let rest = target.restSeconds { restSeconds = rest }
            if let w = target.weightKg { weightKg = w }
        }
        if let last = sessions.last(where: { $0.exerciseID == exercise.id }) {
            weightKg = last.weightKg
            if last.plannedSets > 0 { sets = last.plannedSets }
            if last.plannedReps > 0 { reps = last.plannedReps }
            if last.restSeconds > 0 { restSeconds = last.restSeconds }
        }
        let p = current.clamped()
        sets = p.sets; reps = p.reps; restSeconds = p.restSeconds; weightKg = p.weightKg
    }
}

/// Scelta rapida di un esercizio dal catalogo visibile per il proprio piano.
struct ExercisePickerSheet: View {
    var onPick: (CatalogExercise?) -> Void
    @Environment(CatalogStore.self) private var catalog
    @Environment(SubscriptionManager.self) private var subscriptions
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""

    private var items: [CatalogExercise] {
        catalog.visible(for: subscriptions.tier)
            .filter { query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) }
            .sorted { $0.name.localizedCompare($1.name) == .orderedAscending }
    }

    var body: some View {
        NavigationStack {
            List {
                Button("setup.noExercise") { onPick(nil); dismiss() }
                ForEach(items) { ex in
                    Button {
                        onPick(ex); dismiss()
                    } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(verbatim: ex.name).font(.headline)
                            Text(verbatim: ex.primary.map(\.title).joined(separator: ", "))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .foregroundStyle(.primary)
                }
            }
            .searchable(text: $query, prompt: Text("ex.search"))
            .navigationTitle(Text("setup.choose"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("info.cancel") { dismiss() } }
            }
        }
    }
}
