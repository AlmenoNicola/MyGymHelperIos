import SwiftUI
import MyGymHelperCore

/// Informazioni: account, Apple Salute, documenti legali, consenso, fonti dei dati e cancellazione dei dati locali.
struct InfoView: View {
    @Environment(AccountService.self) private var account
    @AppStorage(ConsentStore.grantedAtKey) private var consentAt = 0.0
    @AppStorage(HealthKitService.enabledKey) private var healthEnabled = false
    @AppStorage(Disclaimer.acceptedDefaultsKey) private var disclaimerAccepted = false
    @AppStorage(ConsentStore.decidedKey) private var consentDecided = false
    @State private var showConsent = false
    @State private var confirmDelete = false

    private var granted: Bool { consentAt > 0 }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                ScreenHeader(symbol: "info.circle.fill", title: "info.title", subtitle: "info.subtitle")

                if account.isConfigured {
                    NavigationLink { AccountView() } label: {
                        HStack(spacing: 14) {
                            Image(systemName: "person.crop.circle.fill").font(.title2).foregroundStyle(Theme.accent)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("account.title").font(.headline)
                                if let email = account.email {
                                    Text(verbatim: email).font(.caption).foregroundStyle(.secondary)
                                } else {
                                    Text(account.isSignedIn ? "account.signedIn" : "account.optional")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.secondary)
                        }
                        .glassCard(padding: 16)
                    }
                    .buttonStyle(.plain)
                }

                VStack(spacing: 0) {
                    NavigationLink { LegalScreen(name: "disclaimer", title: "info.disclaimer") } label: { row("info.disclaimer", "cross.case.fill") }
                    Divider().overlay(.white.opacity(0.15))
                    NavigationLink { LegalScreen(name: "privacy", title: "info.privacy") } label: { row("info.privacy", "lock.shield.fill") }
                    Divider().overlay(.white.opacity(0.15))
                    Link(destination: LegalLinks.terms) { row("info.terms", "doc.plaintext.fill") }
                }
                .buttonStyle(.plain)
                .glassCard(padding: 16)

                VStack(alignment: .leading, spacing: 12) {
                    Text("info.consentStatus").font(.headline)
                    if granted {
                        Text("info.granted \(Date(timeIntervalSince1970: consentAt).formatted(date: .abbreviated, time: .omitted))")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Button("info.revoke", role: .destructive) {
                            ConsentStore.revoke(); consentAt = 0; healthEnabled = false
                        }
                        .buttonStyle(.glass)
                    } else {
                        Text("info.notGranted").font(.subheadline).foregroundStyle(.secondary)
                        Button("info.grant") { showConsent = true }
                            .buttonStyle(.glassProminent).tint(Theme.accent)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .glassCard()

                healthCard

                VStack(alignment: .leading, spacing: 8) {
                    Text("info.sources").font(.headline)
                    Text("info.sourcesExercises").font(.footnote).foregroundStyle(.secondary)
                    Text("food.attribution").font(.footnote).foregroundStyle(.secondary)
                    Text("info.sourcesLocal").font(.footnote).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .glassCard()

                Button("info.delete", role: .destructive) { confirmDelete = true }
                    .buttonStyle(.glass)

                Text(verbatim: "MyGymHelper \(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "")")
                    .font(.caption2).foregroundStyle(.tertiary)
            }
            .padding(20)
        }
        .appScreen()
        .toolbar(.hidden, for: .navigationBar)
        .sheet(isPresented: $showConsent) { ConsentView { } }
        .confirmationDialog("info.deleteConfirm", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("info.delete", role: .destructive) {
                LocalData.deleteAll()
                // Aggiorna subito lo stato in memoria: ricompaiono disclaimer e consenso senza riavviare.
                consentAt = 0; healthEnabled = false
                consentDecided = false; disclaimerAccepted = false
            }
            Button("info.cancel", role: .cancel) { }
        }
    }

    /// Apple Salute: facoltativo, solo con il consenso ai dati sanitari.
    private var healthCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Toggle(isOn: Binding(
                get: { healthEnabled && granted },
                set: { on in
                    if on {
                        Task { @MainActor in
                            healthEnabled = await HealthKitService.shared.requestAuthorization()
                        }
                    } else {
                        healthEnabled = false
                    }
                })) {
                Label("health.title", systemImage: "heart.fill")
            }
            .tint(Theme.accent)
            .disabled(!granted || !HealthKitService.shared.isAvailable)
            Text(granted ? "health.note" : "health.needConsent").font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard()
    }

    private func row(_ title: LocalizedStringKey, _ symbol: String) -> some View {
        HStack(spacing: 14) {
            Image(systemName: symbol).foregroundStyle(Theme.accent).frame(width: 28)
            Text(title).font(.headline)
            Spacer()
            Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.secondary)
        }
        .padding(.vertical, 14)
        .contentShape(Rectangle())
    }
}
