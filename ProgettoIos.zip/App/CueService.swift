import AVFoundation
import AudioToolbox
import UIKit
import MyGymHelperCore

struct CueOptions {
    var sound = true
    var voice = true
    var haptics = true

    static func fromDefaults() -> CueOptions {
        let d = UserDefaults.standard
        func flag(_ key: String) -> Bool { d.object(forKey: key) as? Bool ?? true }
        return CueOptions(sound: flag("cue.sound"), voice: flag("cue.voice"), haptics: flag("cue.haptics"))
    }
}

/// Trasforma gli avvisi della sessione in vibrazione, suono e voce (nella lingua del telefono).
final class CueService: NSObject, AVSpeechSynthesizerDelegate {
    var options = CueOptions()
    private let synthesizer = AVSpeechSynthesizer()

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    func play(_ cue: SessionCue) {
        if options.haptics { haptic(for: cue) }
        if options.sound { AudioServicesPlaySystemSound(1057) }   // segnale breve di sistema, sostituibile con suoni propri
        if options.voice, let text = phrase(for: cue) { speak(text) }
    }

    func shutdown() {
        synthesizer.stopSpeaking(at: .immediate)
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func phrase(for cue: SessionCue) -> String? {
        switch cue {
        case .setStarted: return String(localized: "cue.start")
        case .targetReached: return String(localized: "cue.target")
        case .restStarted(let seconds): return String(localized: "cue.rest \(seconds)")
        case .restCountdown(let n): return "\(n)"
        case .restEnded: return String(localized: "cue.restEnd")
        case .sessionFinished: return String(localized: "cue.finished")
        }
    }

    private func haptic(for cue: SessionCue) {
        switch cue {
        case .setStarted: UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        case .targetReached, .restEnded, .sessionFinished: UINotificationFeedbackGenerator().notificationOccurred(.success)
        case .restStarted: UINotificationFeedbackGenerator().notificationOccurred(.warning)
        case .restCountdown: UIImpactFeedbackGenerator(style: .light).impactOccurred()
        }
    }

    private func speak(_ text: String) {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .voicePrompt, options: [.duckOthers, .interruptSpokenAudioAndMixWithOthers])
        try? session.setActive(true)
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: AVSpeechSynthesisVoice.currentLanguageCode())
        synthesizer.speak(utterance)   // le frasi si mettono in coda: "Serie completata" poi "Riposa 90 secondi"
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        if !synthesizer.isSpeaking {
            try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        }
    }
}
