import SwiftUI
import SwiftData
import PhotosUI
import UniformTypeIdentifiers
import MyGymHelperCore

/// Schede di allenamento (piano Full, con consenso): elenco, dettaglio, eliminazione e importazione da PDF o foto.
/// La scheda piu' recente e' quella usata dai consigli adattivi.
struct TrainingPlansView: View {
    @Environment(SubscriptionManager.self) private var subscriptions
    @Environment(\.modelContext) private var context
    @Query(sort: \TrainingPlanRecord.createdAt, order: .reverse) private var plans: [TrainingPlanRecord]
    @AppStorage(ConsentStore.grantedAtKey) private var consentAt = 0.0
    @State private var importer = PlanImportModel()
    @State private var showConsent = false

    private var allowed: Bool { FeatureGate.isAvailable(.uploadTrainingAndNutritionPlans, for: subscriptions.tier) }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                ScreenHeader(symbol: "doc.text.magnifyingglass", title: "plans.list.title", subtitle: "plans.list.subtitle")

                if !allowed {
                    LockedNote(key: "plans.list.locked").glassCard(padding: 16)
                } else if consentAt == 0 {
                    VStack(spacing: 12) {
                        Label("plans.list.needConsent", systemImage: "lock.fill").font(.callout)
                        Button("consent.open") { showConsent = true }.buttonStyle(.glassProminent).tint(Theme.accent)
                    }
                    .frame(maxWidth: .infinity)
                    .glassCard()
                } else {
                    ImportButtons(model: importer, kind: .training)

                    if plans.isEmpty {
                        Text("plans.list.empty").font(.callout).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading).glassCard(padding: 16)
                    } else {
                        Text("plans.list.activeNote").font(.footnote).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    ForEach(plans) { record in
                        NavigationLink { TrainingPlanDetailView(record: record) } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(verbatim: record.name).font(.headline)
                                    Text(record.createdAt.formatted(date: .abbreviated, time: .omitted))
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                if record.id == plans.first?.id {
                                    Text("plans.list.active").font(.caption.bold())
                                        .padding(.horizontal, 10).padding(.vertical, 4)
                                        .background(Theme.accent.opacity(0.35), in: Capsule())
                                }
                                Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.secondary)
                            }
                            .glassCard(padding: 16)
                        }
                        .buttonStyle(.plain)
                        .contextMenu {
                            Button("history.delete", role: .destructive) { context.delete(record); try? context.save() }
                        }
                    }
                }
            }
            .padding(20)
        }
        .appScreen()
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showConsent) { ConsentView { } }
        .sheet(item: $importer.trainingDraft) { draft in
            TrainingPlanReviewView(draft: draft, record: nil)
        }
        .importErrorAlert(importer)
    }
}

// MARK: - Importazione (condivisa con la scheda del nutrizionista)

enum PlanKind { case training, nutrition }

struct TrainingDraft: Identifiable {
    let id = UUID()
    var name: String
    var plan: TrainingPlan
    var sourceText: String
}

struct NutritionDraft: Identifiable {
    let id = UUID()
    var plan: ParsedNutritionPlan
    var sourceText: String
}

/// Stato dell'importazione: legge il file o la foto, estrae il testo e prepara una bozza da rivedere.
@Observable
@MainActor
final class PlanImportModel {
    var isWorking = false
    var failed = false
    var trainingDraft: TrainingDraft?
    var nutritionDraft: NutritionDraft?

    func handle(fileResult: Result<URL, Error>, kind: PlanKind) {
        guard case .success(let url) = fileResult else { failed = true; return }
        run(kind: kind, name: url.deletingPathExtension().lastPathComponent) {
            try await TextExtractor.text(fromFile: url)
        }
    }

    func handle(photo item: PhotosPickerItem?, kind: PlanKind) {
        guard let item else { return }
        run(kind: kind, name: Date().formatted(date: .abbreviated, time: .omitted)) {
            guard let data = try await item.loadTransferable(type: Data.self) else { throw TextExtractor.ExtractError.unreadable }
            return try await TextExtractor.text(fromImageData: data)
        }
    }

    /// Scheda vuota da compilare a mano.
    func blank(kind: PlanKind) {
        switch kind {
        case .training:
            trainingDraft = TrainingDraft(name: String(localized: "plans.review.newName"),
                                          plan: TrainingPlan(days: [PlanDay(title: "", entries: [PlanEntry(name: "")])]),
                                          sourceText: "")
        case .nutrition:
            nutritionDraft = NutritionDraft(plan: ParsedNutritionPlan(), sourceText: "")
        }
    }

    private func run(kind: PlanKind, name: String, extract: @escaping () async throws -> String) {
        isWorking = true
        Task {
            defer { isWorking = false }
            do {
                let text = try await extract()
                switch kind {
                case .training:
                    var plan = TrainingPlanParser.parse(text)
                    if plan.days.isEmpty { plan = TrainingPlan(days: [PlanDay(title: "", entries: [])]) }
                    trainingDraft = TrainingDraft(name: name, plan: plan, sourceText: text)
                case .nutrition:
                    nutritionDraft = NutritionDraft(plan: NutritionPlanParser.parse(text), sourceText: text)
                }
            } catch {
                failed = true
            }
        }
    }
}

/// Pulsanti per scegliere la fonte: file (PDF, immagine, testo), foto, inserimento manuale. Riga "AI locale" disattivata.
struct ImportButtons: View {
    @Bindable var model: PlanImportModel
    let kind: PlanKind
    @State private var showFiles = false
    @State private var photo: PhotosPickerItem?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("import.title").font(.headline)
            HStack(spacing: 10) {
                Button { showFiles = true } label: {
                    Label("import.file", systemImage: "doc.fill").frame(maxWidth: .infinity)
                }
                PhotosPicker(selection: $photo, matching: .images) {
                    Label("import.photo", systemImage: "photo.fill").frame(maxWidth: .infinity)
                }
            }
            .buttonStyle(.glass)
            Button { model.blank(kind: kind) } label: {
                Label("import.manual", systemImage: "square.and.pencil").frame(maxWidth: .infinity)
            }
            .buttonStyle(.glass)

            if model.isWorking {
                HStack(spacing: 10) { ProgressView(); Text("import.reading").font(.footnote) }
            }

            Toggle(isOn: .constant(false)) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("import.ai").font(.subheadline)
                    Text("import.aiNote").font(.caption).foregroundStyle(.secondary)
                }
            }
            .disabled(true)
            Text("import.privacy").font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard()
        .fileImporter(isPresented: $showFiles, allowedContentTypes: [.pdf, .image, .plainText, .text]) { result in
            model.handle(fileResult: result, kind: kind)
        }
        .onChange(of: photo) { _, item in
            model.handle(photo: item, kind: kind)
            photo = nil
        }
    }
}

extension View {
    func importErrorAlert(_ model: PlanImportModel) -> some View {
        alert("import.failed", isPresented: Binding(get: { model.failed }, set: { model.failed = $0 })) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("import.failedMessage")
        }
    }
}

// MARK: - Dettaglio

struct TrainingPlanDetailView: View {
    let record: TrainingPlanRecord
    @Environment(CatalogStore.self) private var catalog
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State private var editing = false
    @State private var confirmDelete = false
    @State private var deleteOnExit = false

    private var plan: TrainingPlan? { try? JSONDecoder().decode(TrainingPlan.self, from: record.data) }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                if let plan {
                    ForEach(plan.days) { day in
                        VStack(alignment: .leading, spacing: 12) {
                            Text(verbatim: day.title.isEmpty ? String(localized: "plans.review.day") : day.title).font(.headline)
                            ForEach(day.entries) { entry in
                                entryRow(entry)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .glassCard()
                    }
                } else {
                    Text("plans.detail.unreadable").foregroundStyle(.secondary).glassCard()
                }
                Button("history.delete", role: .destructive) { confirmDelete = true }.buttonStyle(.glass)
            }
            .padding(20)
        }
        .appScreen()
        .navigationTitle(Text(verbatim: record.name))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button("plans.detail.edit") { editing = true }.disabled(plan == nil)
            }
        }
        .sheet(isPresented: $editing) {
            if let plan {
                TrainingPlanReviewView(draft: TrainingDraft(name: record.name, plan: plan, sourceText: ""), record: record)
            }
        }
        .onDisappear {
            guard deleteOnExit else { return }
            context.delete(record)
            try? context.save()
        }
        .confirmationDialog("plans.detail.deleteConfirm", isPresented: $confirmDelete, titleVisibility: .visible) {
            // Si chiude prima la schermata e si elimina dopo: evita di leggere un record gia' eliminato.
            Button("history.delete", role: .destructive) { deleteOnExit = true; dismiss() }
            Button("info.cancel", role: .cancel) { }
        }
    }

    @ViewBuilder
    private func entryRow(_ entry: PlanEntry) -> some View {
        let match = ExerciseMatcher.bestMatch(for: entry.name, in: catalog.all)
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(verbatim: entry.name).font(.subheadline.bold())
                Spacer()
                if let match {
                    NavigationLink { WorkoutSetupView(exercise: match) } label: {
                        Image(systemName: "play.circle.fill").font(.title2).foregroundStyle(Theme.accent)
                    }
                    .accessibilityLabel(Text("ex.train"))
                }
            }
            Text(verbatim: entry.summary).font(.caption).foregroundStyle(.secondary)
            if let match, match.name != entry.name {
                Text("plans.detail.matched \(match.name)").font(.caption2).foregroundStyle(Theme.accentSoft)
            }
        }
    }
}

extension PlanEntry {
    /// "4 × 8–10 · 60 kg · 90 s"
    var summary: String {
        var parts: [String] = []
        if let sets {
            let reps = repsMin.map { lo in repsMax.flatMap { $0 != lo ? "\(lo)–\($0)" : nil } ?? "\(lo)" } ?? "?"
            parts.append("\(sets) × \(reps)")
        }
        if let weightKg, weightKg > 0 { parts.append(weightKg.kgText) }
        if let restSeconds { parts.append("\(restSeconds) s") }
        return parts.joined(separator: " · ")
    }
}

// MARK: - Revisione modificabile

/// L'estrazione e' euristica: prima di salvare l'utente controlla e corregge ogni riga.
struct TrainingPlanReviewView: View {
    @State var draft: TrainingDraft
    let record: TrainingPlanRecord?
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Environment(CatalogStore.self) private var catalog

    private var cleaned: TrainingPlan {
        TrainingPlan(days: draft.plan.days.compactMap { day in
            let entries = day.entries.filter { !$0.name.trimmingCharacters(in: .whitespaces).isEmpty }
            return entries.isEmpty ? nil : PlanDay(id: day.id, title: day.title, entries: entries)
        })
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    TextField("plans.review.name", text: $draft.name)
                    Label("plans.review.check", systemImage: "exclamationmark.triangle.fill")
                        .font(.footnote).foregroundStyle(.orange)
                }
                ForEach($draft.plan.days) { $day in
                    Section {
                        TextField("plans.review.dayTitle", text: $day.title).font(.headline)
                        ForEach($day.entries) { $entry in
                            EntryEditor(entry: $entry, match: ExerciseMatcher.bestMatch(for: entry.name, in: catalog.all))
                        }
                        .onDelete { day.entries.remove(atOffsets: $0) }
                        Button { day.entries.append(PlanEntry(name: "")) } label: {
                            Label("plans.review.addEntry", systemImage: "plus")
                        }
                        if draft.plan.days.count > 1 {
                            Button(role: .destructive) {
                                let id = day.id
                                // Rimozione differita: evita letture fuori indice dei binding della riga stessa.
                                DispatchQueue.main.async { draft.plan.days.removeAll { $0.id == id } }
                            } label: {
                                Label("plans.review.deleteDay", systemImage: "trash")
                            }
                        }
                    }
                }
                Section {
                    Button { draft.plan.days.append(PlanDay(title: "", entries: [PlanEntry(name: "")])) } label: {
                        Label("plans.review.addDay", systemImage: "calendar.badge.plus")
                    }
                }
                if !draft.sourceText.isEmpty {
                    Section {
                        DisclosureGroup("plans.review.source") {
                            Text(verbatim: draft.sourceText).font(.caption.monospaced()).textSelection(.enabled)
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background { AppBackground() }
            .navigationTitle(Text("plans.review.title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("info.cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("plans.review.save", action: save).disabled(cleaned.days.isEmpty)
                }
            }
        }
        .interactiveDismissDisabled()
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(cleaned) else { return }
        let name = draft.name.trimmingCharacters(in: .whitespaces)
        let finalName = name.isEmpty ? String(localized: "plans.review.newName") : name
        if let record {
            record.name = finalName
            record.data = data
        } else {
            context.insert(TrainingPlanRecord(name: finalName, data: data))
        }
        try? context.save()
        dismiss()
    }
}

private struct EntryEditor: View {
    @Binding var entry: PlanEntry
    let match: CatalogExercise?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            TextField("plans.review.exercise", text: $entry.name).font(.subheadline.bold())
            HStack(spacing: 8) {
                numberField("plans.review.sets", value: $entry.sets)
                numberField("plans.review.repsMin", value: $entry.repsMin)
                numberField("plans.review.repsMax", value: $entry.repsMax)
            }
            HStack(spacing: 8) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("plans.review.weight").font(.caption2).foregroundStyle(.secondary)
                    TextField("—", value: $entry.weightKg, format: .number).keyboardType(.decimalPad)
                }
                numberField("plans.review.rest", value: $entry.restSeconds)
            }
            if let match {
                Text("plans.detail.matched \(match.name)").font(.caption2).foregroundStyle(Theme.accentSoft)
            } else if !entry.name.isEmpty {
                Text("plans.review.noMatch").font(.caption2).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }

    private func numberField(_ title: LocalizedStringKey, value: Binding<Int?>) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.caption2).foregroundStyle(.secondary)
            TextField("—", value: value, format: .number).keyboardType(.numberPad)
        }
    }
}
