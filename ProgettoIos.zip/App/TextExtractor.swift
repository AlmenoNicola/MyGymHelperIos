import Foundation
import PDFKit
import Vision
import UIKit
import UniformTypeIdentifiers

/// Estrae il testo da schede in PDF, foto o file di testo, tutto sul telefono (PDFKit e Vision, nessun server).
/// Il risultato passa poi ai parser del Core e alla schermata di revisione: l'utente conferma sempre.
enum TextExtractor {
    enum ExtractError: Error { case unreadable, empty }

    /// Pagine massime da riconoscere con l'OCR in un PDF scansionato (per non bloccare il telefono).
    static let maxOCRPages = 10

    static func text(fromFile url: URL) async throws -> String {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let type = UTType(filenameExtension: url.pathExtension.lowercased())

        if type?.conforms(to: .pdf) == true {
            guard let pdf = PDFDocument(url: url) else { throw ExtractError.unreadable }
            let embedded = (pdf.string ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if embedded.count > 20 { return embedded }
            return try await ocr(pdf: pdf)          // PDF scansionato: nessun testo incorporato
        }
        if type?.conforms(to: .image) == true {
            let data = try Data(contentsOf: url)
            return try await text(fromImageData: data)
        }
        if let text = try? String(contentsOf: url, encoding: .utf8) { return text }
        if let text = try? String(contentsOf: url, encoding: .isoLatin1) { return text }
        throw ExtractError.unreadable
    }

    static func text(fromImageData data: Data) async throws -> String {
        guard let image = UIImage(data: data), let cg = image.cgImage else { throw ExtractError.unreadable }
        return try await recognize(cg, orientation: .from(image.imageOrientation))
    }

    private static func ocr(pdf: PDFDocument) async throws -> String {
        var pages: [String] = []
        for index in 0..<min(pdf.pageCount, maxOCRPages) {
            guard let page = pdf.page(at: index) else { continue }
            let bounds = page.bounds(for: .mediaBox)
            let scale = 2000 / max(bounds.width, bounds.height, 1)
            let size = CGSize(width: bounds.width * scale, height: bounds.height * scale)
            let image = page.thumbnail(of: size, for: .mediaBox)
            guard let cg = image.cgImage else { continue }
            pages.append(try await recognize(cg, orientation: .up))
        }
        let text = pages.joined(separator: "\n")
        if text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { throw ExtractError.empty }
        return text
    }

    /// OCR con Vision (modalita' accurata, lingua rilevata in automatico). Le righe tornano in ordine di lettura.
    static func recognize(_ image: CGImage, orientation: CGImagePropertyOrientation) async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let request = VNRecognizeTextRequest()
                request.recognitionLevel = .accurate
                request.usesLanguageCorrection = true
                request.automaticallyDetectsLanguage = true
                do {
                    // perform e' sincrono: i risultati sono pronti al ritorno (una sola ripresa della continuation).
                    try VNImageRequestHandler(cgImage: image, orientation: orientation).perform([request])
                    let lines = (request.results ?? [])
                        .sorted { lhs, rhs in
                            // dall'alto verso il basso, poi da sinistra a destra (coordinate Vision: origine in basso)
                            abs(lhs.boundingBox.midY - rhs.boundingBox.midY) > 0.01
                                ? lhs.boundingBox.midY > rhs.boundingBox.midY
                                : lhs.boundingBox.minX < rhs.boundingBox.minX
                        }
                        .compactMap { $0.topCandidates(1).first?.string }
                    continuation.resume(returning: lines.joined(separator: "\n"))
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }
}

extension CGImagePropertyOrientation {
    static func from(_ o: UIImage.Orientation) -> CGImagePropertyOrientation {
        switch o {
        case .up: return .up
        case .down: return .down
        case .left: return .left
        case .right: return .right
        case .upMirrored: return .upMirrored
        case .downMirrored: return .downMirrored
        case .leftMirrored: return .leftMirrored
        case .rightMirrored: return .rightMirrored
        @unknown default: return .up
        }
    }
}
