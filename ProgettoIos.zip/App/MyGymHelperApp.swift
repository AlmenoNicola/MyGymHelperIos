import SwiftUI
import MyGymHelperCore

@main
struct MyGymHelperApp: App {
    @State private var subscriptions = SubscriptionManager()
    @State private var catalog = CatalogStore()
    @State private var account = AccountService()
    @AppStorage(Disclaimer.acceptedDefaultsKey) private var disclaimerAccepted = false
    @AppStorage(ConsentStore.decidedKey) private var consentDecided = false
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(subscriptions)
                .environment(catalog)
                .environment(account)
                .task {
                    // Gli acquisti portano l'id dell'account, se l'utente ha fatto l'accesso (collegamento sul server).
                    let account = self.account
                    subscriptions.accountToken = { account.userID }
                    await subscriptions.start()
                }
                .task { await account.start() }
                .onChange(of: scenePhase) { _, phase in
                    // Rinnovi, scadenze o acquisti fatti altrove: si ricontrolla tornando nell'app.
                    if phase == .active { Task { await subscriptions.refresh() } }
                }
                .modelContainer(PersistenceController.container)
                .fullScreenCover(isPresented: .constant(!disclaimerAccepted || !consentDecided)) {
                    OnboardingFlow()
                }
        }
    }
}
