import SwiftUI
import MyGymHelperCore

/// Testi condivisi per i consigli (usati in impostazione allenamento e riepilogo).
extension CoachingAdvice {
    var textKey: LocalizedStringKey { textKey(bodyweight: false) }

    /// Con il corpo libero (peso 0) l'aumento di carico diventa una ripetizione in piu' (vedi `CoachingResult.applied`).
    func textKey(bodyweight: Bool) -> LocalizedStringKey {
        switch self {
        case .increaseWeight(let kg): return bodyweight ? "advice.moreReps" : "advice.increase \(kg.formatted())"
        case .keepAsIs: return "advice.keep"
        case .decreaseWeight(let percent): return "advice.decrease \(percent)"
        case .addSet: return "advice.addSet"
        case .removeSet: return "advice.removeSet"
        }
    }
}

extension Double {
    /// Peso leggibile: "62,5 kg" (separatore decimale della lingua del telefono).
    var kgText: String { "\(formatted(.number.precision(.fractionLength(0...2)))) kg" }
}

/// Riga riassuntiva di parametri proposti: serie x ripetizioni, peso, pausa.
struct ParametersLine: View {
    let parameters: WorkoutParameters

    var body: some View {
        HStack(spacing: 14) {
            Label { Text(verbatim: "\(parameters.sets) × \(parameters.reps)") } icon: { Image(systemName: "repeat") }
            Label { Text(verbatim: parameters.weightKg > 0 ? parameters.weightKg.kgText : "—") } icon: { Image(systemName: "scalemass") }
            Label { Text(verbatim: "\(parameters.restSeconds) s") } icon: { Image(systemName: "timer") }
        }
        .font(.subheadline.weight(.semibold))
        .labelStyle(.titleAndIcon)
    }
}

/// Scheda con un consiglio e il pulsante "Applica".
struct AdviceCard: View {
    let title: LocalizedStringKey
    let reasons: [String]
    let parameters: WorkoutParameters
    var details: [LocalizedStringKey] = []
    var onApply: (() -> Void)?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label { Text(title).font(.headline) } icon: { Image(systemName: "sparkles").foregroundStyle(Theme.accent) }
            ForEach(reasons, id: \.self) { key in
                Text(LocalizedStringKey(key)).font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(Array(details.enumerated()), id: \.offset) { _, item in
                Text(item).font(.subheadline)
            }
            ParametersLine(parameters: parameters)
            if let onApply {
                Button(action: onApply) {
                    Label("advice.apply", systemImage: "checkmark").frame(maxWidth: .infinity)
                }
                .buttonStyle(.glassProminent).tint(Theme.accent)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard()
    }
}

/// Avviso di funzione disponibile con un piano superiore.
struct LockedNote: View {
    let key: LocalizedStringKey
    var body: some View {
        // Tocco: apre i piani (la funzione e' disponibile con un abbonamento).
        NavigationLink { PaywallView() } label: {
            HStack {
                Label(key, systemImage: "lock.fill")
                    .font(.footnote).foregroundStyle(.secondary)
                Spacer(minLength: 8)
                Text("plans.see").font(.footnote.bold()).foregroundStyle(Theme.accentSoft)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .buttonStyle(.plain)
    }
}
