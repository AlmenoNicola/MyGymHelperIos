import Foundation
import CoreMotion
import Observation
import MyGymHelperCore

/// Legge il movimento dall'iPhone, trova l'asse dominante (calibrazione) e conta le ripetizioni.
/// Richiede NSMotionUsageDescription in Info.plist.
/// Tutto il lavoro sui sensori avviene su una coda seriale; lo stato per la UI viene pubblicato sul thread principale.
@Observable
final class MotionService {
    @ObservationIgnored private let manager = CMMotionManager()
    @ObservationIgnored private let queue: OperationQueue = {
        let q = OperationQueue(); q.maxConcurrentOperationCount = 1; q.qualityOfService = .userInitiated; return q
    }()
    @ObservationIgnored private var calibrationBuffer: [(t: TimeInterval, v: Vector3)] = []
    @ObservationIgnored private var axis: Vector3?
    @ObservationIgnored private var detector = RepDetector()
    @ObservationIgnored private var counting = false
    @ObservationIgnored private var lastCount = -1
    @ObservationIgnored private var lastLow = false
    @ObservationIgnored private let calibrationSeconds = 3.0
    @ObservationIgnored private let minMotion = 0.15       // g: sotto questa soglia la calibrazione aspetta
    /// Chiamato sul thread principale ogni volta che cambia il numero di ripetizioni della serie corrente.
    @ObservationIgnored var onRepCount: (@Sendable (Int) -> Void)?

    private(set) var repCount = 0
    private(set) var isCalibrating = true
    private(set) var lowConfidence = false
    private(set) var averagePeak = 0.0
    private(set) var isAvailable = true

    func start() {
        guard manager.isDeviceMotionAvailable else { isAvailable = false; return }
        manager.deviceMotionUpdateInterval = 1.0 / 50.0
        manager.startDeviceMotionUpdates(to: queue) { [weak self] motion, _ in
            guard let self, let m = motion else { return }
            let a = m.userAcceleration   // gravita' gia' rimossa
            self.handle(Vector3(a.x, a.y, a.z), at: m.timestamp)
        }
    }

    func stop() { manager.stopDeviceMotionUpdates() }

    /// Inizia a contare una nuova serie (azzera il conteggio, mantiene l'asse calibrato).
    func beginSet() {
        queue.addOperation { [weak self] in
            guard let self else { return }
            self.detector = RepDetector()
            self.counting = true
            self.lastCount = -1
            self.lastLow = false
            self.publish(count: 0, low: false, peak: 0)
        }
    }

    /// Smette di contare (durante la pausa).
    func pauseCounting() {
        queue.addOperation { [weak self] in self?.counting = false }
    }

    private func handle(_ v: Vector3, at t: TimeInterval) {
        guard counting else { return }
        if axis == nil {
            calibrationBuffer.append((t, v))
            while let first = calibrationBuffer.first, t - first.t > calibrationSeconds { calibrationBuffer.removeFirst() }
            guard let first = calibrationBuffer.first, t - first.t >= calibrationSeconds * 0.95 else { return }
            // Se l'utente non si e' ancora mosso, la finestra scorre e si riprova: evita un asse casuale.
            guard (calibrationBuffer.map { $0.v.length }.max() ?? 0) >= minMotion else { return }
            let found = PrincipalAxis.estimate(from: calibrationBuffer.map(\.v)) ?? Vector3(1, 0, 0)
            axis = found
            for s in calibrationBuffer { detector.process(s.v.dot(found), at: s.t) }   // riesame della finestra
            calibrationBuffer = []
            DispatchQueue.main.async { self.isCalibrating = false }
        } else if let axis {
            detector.process(v.dot(axis), at: t)
        }
        publishIfChanged()
    }

    private func publishIfChanged() {
        let count = detector.count
        let low = detector.signalConfidence < 0.4
        guard count != lastCount || low != lastLow else { return }
        lastCount = count
        lastLow = low
        let peaks = detector.events.map(\.peakAmplitude)
        let avg = peaks.isEmpty ? 0 : peaks.reduce(0, +) / Double(peaks.count)
        publish(count: count, low: low, peak: avg)
    }

    private func publish(count: Int, low: Bool, peak: Double) {
        let callback = onRepCount
        DispatchQueue.main.async {
            self.repCount = count
            self.lowConfidence = low
            self.averagePeak = peak
            callback?(count)
        }
    }
}
