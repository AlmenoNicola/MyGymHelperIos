import Foundation
import StoreKit
import Observation
import MyGymHelperCore

/// Identificatori prodotto: da creare in App Store Connect, in UN gruppo di abbonamento.
/// Prezzi: Mid 4,99 €/mese e 49,99 €/anno; Full 9,99 €/mese e 99,99 €/anno.
/// La prova gratuita di 7 giorni va configurata come offerta introduttiva (free trial)
/// sul gruppo: StoreKit la concede una sola volta per gruppo e per utente.
enum ProductID {
    static let midMonthly = "app.mygymhelper.mid.monthly"
    static let midYearly = "app.mygymhelper.mid.yearly"
    static let fullMonthly = "app.mygymhelper.full.monthly"
    static let fullYearly = "app.mygymhelper.full.yearly"
    static let all = [midMonthly, midYearly, fullMonthly, fullYearly]

    static func tier(for id: String) -> SubscriptionTier {
        id.contains(".full.") ? .full : (id.contains(".mid.") ? .mid : .free)
    }
}

extension SubscriptionTier {
    var titleKey: LocalizedStringResource {
        switch self {
        case .free: "tier.free"
        case .mid: "tier.mid"
        case .full: "tier.full"
        }
    }
}

/// Stato degli abbonamenti con StoreKit 2. Le transazioni sono firmate e verificate sul telefono;
/// se l'utente ha un account, gli acquisti portano il suo id (`appAccountToken`) per collegarli sul server.
@Observable
@MainActor
final class SubscriptionManager {
    private(set) var tier: SubscriptionTier = .free
    private(set) var activeProductID: String?
    private(set) var renewalDate: Date?

    private let cacheTierKey = "entitlement.tier"
    private let cacheDateKey = "entitlement.lastVerified"
    /// Giorni di tolleranza senza rete prima di tornare a Free (le transazioni StoreKit 2 sono comunque firmate).
    private let offlineGraceDays = 14.0
    @ObservationIgnored private var updatesTask: Task<Void, Never>?
    @ObservationIgnored private var started = false

    /// Id dell'account (Supabase) da allegare agli acquisti, se l'utente ha fatto l'accesso.
    @ObservationIgnored var accountToken: @MainActor () -> UUID? = { nil }

    func start() async {
        guard !started else { return }
        started = true
        restoreCachedTier()
        updatesTask = Task { [weak self] in
            for await result in Transaction.updates {
                if case .verified(let t) = result { await t.finish() }
                await self?.refresh()
            }
        }
        // Transazioni concluse mentre l'app era chiusa (per esempio acquisti in attesa di approvazione).
        for await result in Transaction.unfinished {
            if case .verified(let t) = result { await t.finish() }
        }
        await refresh()
    }

    /// Opzioni di acquisto: collega l'acquisto all'account, se presente.
    func purchaseOptions() -> Set<Product.PurchaseOption> {
        guard let token = accountToken() else { return [] }
        return [.appAccountToken(token)]
    }

    func restore() async { try? await AppStore.sync(); await refresh() }

    func refresh() async {
        var best: SubscriptionTier = .free
        var product: String?
        var expiry: Date?
        for await result in Transaction.currentEntitlements {
            guard case .verified(let t) = result, t.revocationDate == nil, !t.isUpgraded else { continue }
            if let exp = t.expirationDate, exp < Date() { continue }
            let level = ProductID.tier(for: t.productID)
            if level > best || (level == best && product == nil) {
                best = level; product = t.productID; expiry = t.expirationDate
            }
        }
        tier = best
        activeProductID = product
        renewalDate = expiry
        UserDefaults.standard.set(best.rawValue, forKey: cacheTierKey)
        UserDefaults.standard.set(Date(), forKey: cacheDateKey)
    }

    private func restoreCachedTier() {
        let d = UserDefaults.standard
        guard let date = d.object(forKey: cacheDateKey) as? Date,
              Date().timeIntervalSince(date) < offlineGraceDays * 86400,
              let tier = SubscriptionTier(rawValue: d.integer(forKey: cacheTierKey)) else { return }
        self.tier = tier
    }
}
