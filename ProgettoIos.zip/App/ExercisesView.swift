import SwiftUI
import SwiftData
import MyGymHelperCore

/// Catalogo: mappa del corpo (fronte/retro) e blocchi per scegliere i muscoli, consigli (Mid e Full) ed elenco esercizi.
/// Piano Free: un esercizio per tipologia.
struct ExercisesView: View {
    @Environment(CatalogStore.self) private var catalog
    @Environment(SubscriptionManager.self) private var subscriptions
    @Environment(AccountService.self) private var account
    @Query(sort: \WorkoutSessionRecord.startedAt) private var sessions: [WorkoutSessionRecord]
    @State private var side: BodySide = .front
    @State private var selected: Set<MuscleGroup> = []
    @State private var query = ""

    private var tier: SubscriptionTier { subscriptions.tier }
    private var pool: [CatalogExercise] { catalog.visible(for: tier) }

    private var filtered: [CatalogExercise] {
        pool.filter { ex in
            (selected.isEmpty || !Set(ex.primary).isDisjoint(with: selected))
                && (query.isEmpty || ex.name.localizedCaseInsensitiveContains(query))
        }
    }

    private var recommendations: [Recommendation] {
        guard FeatureGate.isAvailable(.fixedCoaching, for: tier) else { return [] }
        return ExerciseRecommender.recommend(from: pool, targets: selected,
                                             history: CoachingService.historyEntries(from: sessions, catalog: catalog.all),
                                             limit: 3)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                ScreenHeader(symbol: "figure.strengthtraining.traditional", title: "ex.title", subtitle: "ex.subtitle")

                HStack(spacing: 12) {
                    NavigationLink { ExerciseListsView() } label: {
                        Label("ex.lists", systemImage: "list.bullet.rectangle").frame(maxWidth: .infinity)
                    }
                    NavigationLink { TrainingPlansView() } label: {
                        Label("ex.plans", systemImage: "doc.text.magnifyingglass").frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.glass)

                VStack(spacing: 14) {
                    Picker("", selection: $side) {
                        ForEach(BodySide.allCases) { Text($0.titleKey).tag($0) }
                    }
                    .pickerStyle(.segmented)
                    BodyMapView(side: side, selected: $selected).frame(height: 300)
                    RegionChips(selected: $selected)
                    if !selected.isEmpty {
                        Button("ex.clear") { selected.removeAll() }.font(.footnote)
                    }
                }
                .glassCard()

                if !recommendations.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("ex.recommended").font(.headline)
                        ForEach(recommendations, id: \.exercise.id) { rec in
                            NavigationLink { ExerciseDetailView(exercise: rec.exercise) } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(verbatim: rec.exercise.name).font(.subheadline.bold())
                                    Text(LocalizedStringKey(rec.reasonKey)).font(.caption).foregroundStyle(Theme.accentSoft)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .glassCard()
                }

                TextField("ex.search", text: $query)
                    .textFieldStyle(.plain)
                    .padding(14)
                    .glassEffect(.regular, in: .capsule)

                if !FeatureGate.isAvailable(.catalogFull, for: tier) {
                    Label("ex.freeLimit", systemImage: "lock.fill")
                        .font(.footnote).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                }

                if filtered.isEmpty {
                    Text("ex.none").foregroundStyle(.secondary).glassCard(padding: 16)
                }
                ForEach(filtered) { ex in
                    NavigationLink { ExerciseDetailView(exercise: ex) } label: { ExerciseRow(exercise: ex) }
                        .buttonStyle(.plain)
                }
            }
            .padding(20)
        }
        .appScreen()
        .toolbar(.hidden, for: .navigationBar)
        .task {
            let account = self.account
            await catalog.refreshRemote(fallbackBase: account.functionsURL, authToken: { await account.bearerToken() })
        }
    }
}

struct ExerciseRow: View {
    let exercise: CatalogExercise

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(verbatim: exercise.name).font(.headline)
                Text(verbatim: exercise.primary.map(\.title).joined(separator: ", "))
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.secondary)
        }
        .glassCard(padding: 16)
    }
}

struct ExerciseDetailView: View {
    let exercise: CatalogExercise
    @Environment(SubscriptionManager.self) private var subscriptions
    @State private var showLists = false

    private var canSaveLists: Bool { FeatureGate.isAvailable(.savedExerciseLists, for: subscriptions.tier) }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                ScreenHeader(symbol: "dumbbell.fill", title: LocalizedStringKey(exercise.name),
                             subtitle: LocalizedStringKey(exercise.primary.map(\.title).joined(separator: ", ")))

                HStack(spacing: 8) {
                    chip(exercise.mechanic == .compound ? "mech.compound" : "mech.isolation")
                    if !exercise.equipment.isEmpty { Text(verbatim: exercise.equipment.capitalized).font(.caption.bold()).padding(.horizontal, 12).padding(.vertical, 6).background(.white.opacity(0.1), in: Capsule()) }
                    ForEach(exercise.secondary, id: \.self) { m in
                        Text(verbatim: m.title).font(.caption).padding(.horizontal, 10).padding(.vertical, 5)
                            .background(.white.opacity(0.06), in: Capsule())
                    }
                    Spacer(minLength: 0)
                }

                if !exercise.steps.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("ex.how").font(.headline)
                        ForEach(Array(exercise.steps.enumerated()), id: \.offset) { i, step in
                            HStack(alignment: .firstTextBaseline, spacing: 12) {
                                Text("\(i + 1)").font(.headline).foregroundStyle(Theme.accent).frame(width: 22)
                                Text(verbatim: step).font(.callout)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .glassCard()
                }

                NavigationLink { WorkoutSetupView(exercise: exercise) } label: {
                    Label("ex.train", systemImage: "play.fill").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
                }
                .buttonStyle(.glassProminent).tint(Theme.accent)

                if canSaveLists {
                    Button { showLists = true } label: {
                        Label("ex.addToList", systemImage: "text.badge.plus").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.glass)
                } else {
                    Label("ex.listsLocked", systemImage: "lock.fill").font(.footnote).foregroundStyle(.secondary)
                }
            }
            .padding(20)
        }
        .appScreen()
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showLists) { AddToListSheet(exercise: exercise) }
    }

    private func chip(_ key: LocalizedStringKey) -> some View {
        Text(key).font(.caption.bold()).padding(.horizontal, 12).padding(.vertical, 6)
            .background(Theme.accent.opacity(0.35), in: Capsule())
    }
}

struct AddToListSheet: View {
    let exercise: CatalogExercise
    @Query(sort: \ExerciseListRecord.createdAt) private var lists: [ExerciseListRecord]
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @AppStorage(ConsentStore.grantedAtKey) private var consentAt = 0.0
    @State private var newName = ""

    var body: some View {
        ZStack {
            AppBackground()
            ScrollView {
                VStack(spacing: 14) {
                    Text("ex.addToList").font(.title3.bold())
                    if consentAt == 0 {
                        Label("lists.needConsent", systemImage: "lock.fill").font(.callout).glassCard()
                    } else {
                        ForEach(lists) { list in
                            Button {
                                if !list.exerciseIDs.contains(exercise.id) { list.exerciseIDs.append(exercise.id); try? context.save() }
                                dismiss()
                            } label: {
                                HStack {
                                    Text(verbatim: list.name).font(.headline)
                                    Spacer()
                                    if list.exerciseIDs.contains(exercise.id) { Image(systemName: "checkmark.circle.fill").foregroundStyle(Theme.accent) }
                                }
                                .glassCard(padding: 16)
                            }
                            .buttonStyle(.plain)
                        }
                        HStack {
                            TextField("lists.newName", text: $newName).textFieldStyle(.plain)
                            Button("lists.create") {
                                let name = newName.trimmingCharacters(in: .whitespaces)
                                guard !name.isEmpty else { return }
                                context.insert(ExerciseListRecord(name: name, exerciseIDs: [exercise.id]))
                                try? context.save()
                                dismiss()
                            }
                            .buttonStyle(.glassProminent).tint(Theme.accent)
                        }
                        .glassCard(padding: 16)
                    }
                    Button("info.cancel") { dismiss() }.buttonStyle(.glass)
                }
                .padding(24)
            }
        }
        .presentationDetents([.medium, .large])
    }
}

/// Elenchi preimpostati (uguali per tutti) ed elenchi salvati dall'utente.
struct ExerciseListsView: View {
    @Environment(CatalogStore.self) private var catalog
    @Environment(SubscriptionManager.self) private var subscriptions
    @Query(sort: \ExerciseListRecord.createdAt) private var lists: [ExerciseListRecord]
    @Environment(\.modelContext) private var context
    @AppStorage(ConsentStore.grantedAtKey) private var consentAt = 0.0
    @State private var showNew = false
    @State private var newName = ""

    private var pool: [CatalogExercise] { catalog.visible(for: subscriptions.tier) }
    private var canSave: Bool { FeatureGate.isAvailable(.savedExerciseLists, for: subscriptions.tier) }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                ScreenHeader(symbol: "list.bullet.rectangle", title: "lists.title", subtitle: "lists.subtitle")

                Text("lists.presets").font(.headline).frame(maxWidth: .infinity, alignment: .leading)
                ForEach(BodyRegion.allCases, id: \.self) { region in
                    let items = pool.filter { ex in ex.primary.contains { $0.region == region } }
                    if !items.isEmpty {
                        NavigationLink { ExerciseCollectionView(title: region.title, exercises: items) } label: {
                            HStack {
                                Label(region.title, systemImage: region.symbol).font(.headline)
                                Spacer()
                                Text("\(items.count)").foregroundStyle(.secondary)
                            }
                            .glassCard(padding: 16)
                        }
                        .buttonStyle(.plain)
                    }
                }

                Text("lists.mine").font(.headline).frame(maxWidth: .infinity, alignment: .leading).padding(.top, 8)
                if !canSave {
                    Label("ex.listsLocked", systemImage: "lock.fill").font(.footnote).foregroundStyle(.secondary)
                } else if consentAt == 0 {
                    Label("lists.needConsent", systemImage: "lock.fill").font(.footnote).foregroundStyle(.secondary)
                } else {
                    ForEach(lists) { list in
                        NavigationLink {
                            ExerciseCollectionView(title: list.name, exercises: list.exerciseIDs.compactMap { catalog.exercise(id: $0) })
                        } label: {
                            HStack {
                                Text(verbatim: list.name).font(.headline)
                                Spacer()
                                Text("\(list.exerciseIDs.count)").foregroundStyle(.secondary)
                            }
                            .glassCard(padding: 16)
                        }
                        .buttonStyle(.plain)
                        .contextMenu { Button("history.delete", role: .destructive) { context.delete(list); try? context.save() } }
                    }
                    Button { showNew = true } label: { Label("lists.new", systemImage: "plus").frame(maxWidth: .infinity) }
                        .buttonStyle(.glass)
                }
            }
            .padding(20)
        }
        .appScreen()
        .navigationBarTitleDisplayMode(.inline)
        .alert("lists.new", isPresented: $showNew) {
            TextField("lists.newName", text: $newName)
            Button("lists.create") {
                let name = newName.trimmingCharacters(in: .whitespaces)
                if !name.isEmpty { context.insert(ExerciseListRecord(name: name)); try? context.save() }
                newName = ""
            }
            Button("info.cancel", role: .cancel) { newName = "" }
        }
    }
}

struct ExerciseCollectionView: View {
    let title: String
    let exercises: [CatalogExercise]

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                if exercises.isEmpty { Text("ex.none").foregroundStyle(.secondary).glassCard(padding: 16) }
                ForEach(exercises) { ex in
                    NavigationLink { ExerciseDetailView(exercise: ex) } label: { ExerciseRow(exercise: ex) }
                        .buttonStyle(.plain)
                }
            }
            .padding(20)
        }
        .appScreen()
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
