import SwiftUI

/// Stile grafico dell'app: scuro, gradiente profondo, accento arancio acceso e vetro (Liquid Glass, iOS 26).
enum Theme {
    static let accent = Color(red: 1.00, green: 0.42, blue: 0.16)
    static let accentSoft = Color(red: 1.00, green: 0.66, blue: 0.20)
    static let bgTop = Color(red: 0.06, green: 0.07, blue: 0.14)
    static let bgBottom = Color(red: 0.16, green: 0.08, blue: 0.24)
    static let accentGradient = LinearGradient(colors: [accentSoft, accent], startPoint: .topLeading, endPoint: .bottomTrailing)
}

/// Sfondo con gradiente e due aloni sfocati.
struct AppBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Theme.bgTop, Theme.bgBottom], startPoint: .top, endPoint: .bottom)
            Circle().fill(Theme.accent.opacity(0.28)).frame(width: 320).blur(radius: 90).offset(x: 140, y: -260)
            Circle().fill(Color.purple.opacity(0.30)).frame(width: 300).blur(radius: 100).offset(x: -150, y: 300)
        }
        .ignoresSafeArea()
    }
}

extension View {
    /// Scheda in vetro con angoli morbidi.
    func glassCard(padding: CGFloat = 20) -> some View {
        self.padding(padding)
            .glassEffect(.regular, in: .rect(cornerRadius: 28))
    }

    /// Sfondo comune di tutte le schermate.
    func appScreen() -> some View {
        self.scrollContentBackground(.hidden)
            .background { AppBackground() }
    }
}

/// Titolo grande di schermata, con icona su cerchio in gradiente.
struct ScreenHeader: View {
    let symbol: String
    let title: LocalizedStringKey
    let subtitle: LocalizedStringKey

    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: symbol)
                .font(.system(size: 28, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 60, height: 60)
                .background(Theme.accentGradient, in: Circle())
                .shadow(color: Theme.accent.opacity(0.5), radius: 14, y: 6)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.title.bold())
                Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
    }
}

/// Riga con titolo e contatore con tasti meno/più.
struct CounterRow: View {
    let title: LocalizedStringKey
    @Binding var value: Int
    let range: ClosedRange<Int>
    var step = 1

    var body: some View {
        HStack {
            Text(title).font(.headline)
            Spacer()
            HStack(spacing: 14) {
                Button { value = max(range.lowerBound, value - step) } label: { Image(systemName: "minus") }
                    .buttonStyle(.glass).buttonBorderShape(.circle)
                Text("\(value)")
                    .font(.title2.bold().monospacedDigit())
                    .frame(minWidth: 56)
                    .contentTransition(.numericText())
                Button { value = min(range.upperBound, value + step) } label: { Image(systemName: "plus") }
                    .buttonStyle(.glass).buttonBorderShape(.circle)
            }
        }
        .sensoryFeedback(.selection, trigger: value)
        .animation(.snappy, value: value)
    }
}

/// Anello di avanzamento per il conteggio delle ripetizioni.
struct RepRing: View {
    let count: Int
    let target: Int

    private var progress: Double { target > 0 ? min(Double(count) / Double(target), 1) : 0 }

    var body: some View {
        ZStack {
            Circle().stroke(.white.opacity(0.10), lineWidth: 22)
            Circle()
                .trim(from: 0, to: progress)
                .stroke(Theme.accentGradient, style: StrokeStyle(lineWidth: 22, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .shadow(color: Theme.accent.opacity(0.6), radius: 16)
                .animation(.spring(duration: 0.5), value: progress)
            VStack(spacing: 2) {
                Text("\(count)")
                    .font(.system(size: 88, weight: .heavy, design: .rounded).monospacedDigit())
                    .contentTransition(.numericText())
                    .animation(.snappy, value: count)
                Text("/ \(target)").font(.title3.weight(.semibold)).foregroundStyle(.secondary)
            }
        }
        .frame(width: 270, height: 270)
        .sensoryFeedback(.impact, trigger: count)
    }
}

/// Riga per il peso con passo di 1,25 kg (0 = corpo libero).
struct WeightRow: View {
    let title: LocalizedStringKey
    @Binding var value: Double
    var step = 1.25
    var range: ClosedRange<Double> = 0...500

    var body: some View {
        HStack {
            Text(title).font(.headline)
            Spacer()
            HStack(spacing: 14) {
                Button { value = max(range.lowerBound, value - step) } label: { Image(systemName: "minus") }
                    .buttonStyle(.glass).buttonBorderShape(.circle)
                    .buttonRepeatBehavior(.enabled)
                Group {
                    if value > 0 { Text(verbatim: value.kgText) } else { Text("setup.bodyweight") }
                }
                .font(.title3.bold().monospacedDigit())
                .frame(minWidth: 86)
                .contentTransition(.numericText())
                Button { value = min(range.upperBound, value + step) } label: { Image(systemName: "plus") }
                    .buttonStyle(.glass).buttonBorderShape(.circle)
                    .buttonRepeatBehavior(.enabled)
            }
        }
        .sensoryFeedback(.selection, trigger: value)
        .animation(.snappy, value: value)
    }
}
