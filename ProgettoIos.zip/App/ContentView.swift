import SwiftUI
import MyGymHelperCore

/// Schede principali. Il BMI e' nella scheda Nutrizione (disponibile anche nel piano Free).
struct ContentView: View {
    var body: some View {
        TabView {
            Tab("tab.workout", systemImage: "figure.strengthtraining.traditional") {
                NavigationStack { WorkoutSetupView() }
            }
            Tab("tab.exercises", systemImage: "dumbbell.fill") {
                NavigationStack { ExercisesView() }
            }
            Tab("tab.nutrition", systemImage: "fork.knife") {
                NavigationStack { NutritionView() }
            }
            Tab("tab.plans", systemImage: "star.fill") {
                NavigationStack { PaywallView() }
            }
            Tab("tab.info", systemImage: "info.circle.fill") {
                NavigationStack { InfoView() }
            }
        }
        .tint(Theme.accent)
        .preferredColorScheme(.dark)
    }
}
