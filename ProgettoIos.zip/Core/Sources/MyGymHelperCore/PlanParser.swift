import Foundation

public struct PlanEntry: Codable, Equatable, Identifiable, Sendable {
    public var id: UUID
    public var name: String
    public var sets: Int?
    public var repsMin: Int?
    public var repsMax: Int?
    public var restSeconds: Int?
    public var weightKg: Double?

    public init(id: UUID = UUID(), name: String, sets: Int? = nil, repsMin: Int? = nil, repsMax: Int? = nil,
                restSeconds: Int? = nil, weightKg: Double? = nil) {
        self.id = id; self.name = name; self.sets = sets; self.repsMin = repsMin; self.repsMax = repsMax
        self.restSeconds = restSeconds; self.weightKg = weightKg
    }

    public var target: PlanTarget {
        PlanTarget(sets: sets, repsMin: repsMin, repsMax: repsMax, restSeconds: restSeconds, weightKg: weightKg)
    }
}

public struct PlanDay: Codable, Equatable, Identifiable, Sendable {
    public var id: UUID
    public var title: String
    public var entries: [PlanEntry]
    public init(id: UUID = UUID(), title: String, entries: [PlanEntry]) {
        self.id = id; self.title = title; self.entries = entries
    }
}

public struct TrainingPlan: Codable, Equatable, Sendable {
    public var days: [PlanDay]
    public init(days: [PlanDay]) { self.days = days }
    public var allEntries: [PlanEntry] { days.flatMap(\.entries) }
}

private func firstMatch(_ pattern: String, in text: String) -> [String?]? {
    guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
    let ns = text as NSString
    guard let m = re.firstMatch(in: text, range: NSRange(location: 0, length: ns.length)) else { return nil }
    return (0..<m.numberOfRanges).map { i in
        let r = m.range(at: i)
        return r.location == NSNotFound ? nil : ns.substring(with: r)
    }
}

private func removing(_ pattern: String, from text: String) -> String {
    text.replacingOccurrences(of: "(?i)" + pattern, with: " ", options: .regularExpression)
}

/// Estrattore di schede di allenamento da testo (PDF o foto): riconosce giorni, esercizi, serie x ripetizioni,
/// carico e recupero in italiano e inglese. E' un'euristica: l'utente deve sempre controllare il risultato.
public enum TrainingPlanParser {
    static let setsRepsX = #"(\d{1,2})\s*[x×*]\s*(\d{1,3})(?:\s*[-–]\s*(\d{1,3}))?"#
    static let setsRepsWords = #"(\d{1,2})\s*(?:serie|series|sets?)\s*(?:da|di|x|of|per)?\s*(\d{1,3})(?:\s*[-–]\s*(\d{1,3}))?"#
    static let weight = #"(\d{1,3}(?:[.,]\d{1,2})?)\s*(?:kg|kili|chili)"#
    static let rest = #"(?:rec(?:upero)?|rest|pausa|riposo)\.?\s*:?\s*(\d{1,3})\s*(min|m|''|"|sec|s|')?"#
    static let dayHeading = #"^(?:giorno|day|allenamento|workout|sessione|seduta|scheda|settimana|week)\b.{0,30}$"#
    static let weekday = #"^(?:luned[iì]|marted[iì]|mercoled[iì]|gioved[iì]|venerd[iì]|sabato|domenica|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b.{0,20}$"#

    static func stripBullet(_ line: String) -> String {
        line.replacingOccurrences(of: #"^\s*(?:[-•*·]|\d{1,2}[.)])\s+"#, with: "", options: .regularExpression)
    }

    static func restSeconds(value: Int, unit: String?) -> Int {
        switch unit?.lowercased() {
        case "min", "m", "'": return value * 60
        // Un recupero di pochi secondi non e' realistico: "rec 3\"" si intende come 3 minuti.
        case "''", "\"", "sec", "s": return value < 10 ? value * 60 : value
        default: return value <= 10 ? value * 60 : value
        }
    }

    static func parseEntry(_ line: String) -> PlanEntry? {
        var usedPattern = setsRepsX
        var sr = firstMatch(setsRepsX, in: line)
        if sr == nil { usedPattern = setsRepsWords; sr = firstMatch(setsRepsWords, in: line) }
        guard let g = sr, let sets = g[1].flatMap({ Int($0) }), let repsA = g[2].flatMap({ Int($0) }) else { return nil }
        let repsB = g.count > 3 ? g[3].flatMap({ Int($0) }) : nil
        let lo = min(repsA, repsB ?? repsA), hi = max(repsA, repsB ?? repsA)
        guard (1...12).contains(sets), (1...100).contains(lo) else { return nil }

        var weightKg: Double?
        if let w = firstMatch(weight, in: line), let s = w[1] { weightKg = Double(s.replacingOccurrences(of: ",", with: ".")) }
        var restSec: Int?
        if let r = firstMatch(rest, in: line), let s = r[1], let v = Int(s) { restSec = restSeconds(value: v, unit: r.count > 2 ? r[2] : nil) }

        var name = line
        for p in [usedPattern, weight, rest] { name = removing(p, from: name) }
        name = name.trimmingCharacters(in: CharacterSet(charactersIn: " :-–—,.;()/\t"))
        name = name.components(separatedBy: .whitespaces).filter { !$0.isEmpty }.joined(separator: " ")
        guard name.filter(\.isLetter).count >= 3 else { return nil }
        return PlanEntry(name: name, sets: sets, repsMin: lo, repsMax: hi, restSeconds: restSec, weightKg: weightKg)
    }

    static func dayTitle(_ line: String) -> String? {
        let clean = line.trimmingCharacters(in: CharacterSet(charactersIn: " :-–—"))
        if firstMatch(dayHeading, in: clean) != nil || firstMatch(weekday, in: clean) != nil { return clean }
        return nil
    }

    public static func parse(_ text: String) -> TrainingPlan {
        var days: [PlanDay] = []
        var current = PlanDay(title: "", entries: [])
        func flush() { if !current.entries.isEmpty { days.append(current) } }
        for raw in text.components(separatedBy: .newlines) {
            let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { continue }
            let line = stripBullet(trimmed)
            if let entry = parseEntry(line) { current.entries.append(entry); continue }
            if let title = dayTitle(line) { flush(); current = PlanDay(title: title, entries: []) }
        }
        flush()
        return TrainingPlan(days: days)
    }
}

// MARK: - Scheda del nutrizionista

public struct ParsedMeal: Codable, Equatable, Identifiable, Sendable {
    public var id: UUID
    public var name: String
    public var items: [String]
    public init(id: UUID = UUID(), name: String, items: [String]) { self.id = id; self.name = name; self.items = items }
}

public struct ParsedNutritionPlan: Codable, Equatable, Sendable {
    public var calories: Int?
    public var proteinG: Int?
    public var carbsG: Int?
    public var fatG: Int?
    public var meals: [ParsedMeal]
    public init(calories: Int? = nil, proteinG: Int? = nil, carbsG: Int? = nil, fatG: Int? = nil, meals: [ParsedMeal] = []) {
        self.calories = calories; self.proteinG = proteinG; self.carbsG = carbsG; self.fatG = fatG; self.meals = meals
    }
}

public enum NutritionPlanParser {
    static let mealWords = "colazione|spuntino|pranzo|merenda|cena|breakfast|lunch|dinner|snack"

    static func number(_ patterns: [String], in text: String, range: ClosedRange<Int>) -> Int? {
        for p in patterns {
            if let m = firstMatch(p, in: text), let s = m[1], let v = Int(s), range.contains(v) { return v }
        }
        return nil
    }

    public static func parse(_ text: String) -> ParsedNutritionPlan {
        let calories = number([#"(\d{3,4})\s*(?:kcal|cal\b)"#, #"calorie\D{0,12}(\d{3,4})"#], in: text, range: 800...6000)
        let protein = number([#"(?:proteine|protein)\D{0,12}(\d{2,3})\s*g"#, #"(\d{2,3})\s*g\s*(?:di\s*)?(?:proteine|protein)"#], in: text, range: 20...400)
        let carbs = number([#"(?:carboidrati|carbs?|carbohydrates)\D{0,12}(\d{2,3})\s*g"#, #"(\d{2,3})\s*g\s*(?:di\s*)?(?:carboidrati|carbs?|carbohydrates)"#], in: text, range: 20...800)
        let fat = number([#"(?:grassi|lipidi|fats?)\D{0,12}(\d{2,3})\s*g"#, #"(\d{2,3})\s*g\s*(?:di\s*)?(?:grassi|lipidi|fats?)"#], in: text, range: 10...300)

        var meals: [ParsedMeal] = []
        var current: ParsedMeal?
        for raw in text.components(separatedBy: .newlines) {
            let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { continue }
            let line = TrainingPlanParser.stripBullet(trimmed)
            if let m = firstMatch("^(" + mealWords + ")\\b\\s*[:\\-–]?\\s*(.*)$", in: line), let name = m[1] {
                if let c = current { meals.append(c) }
                var items: [String] = []
                if let rest = m[2], !rest.trimmingCharacters(in: .whitespaces).isEmpty { items.append(rest.trimmingCharacters(in: .whitespaces)) }
                current = ParsedMeal(name: name.capitalized, items: items)
            } else if current != nil {
                current?.items.append(line)
            }
        }
        if let c = current { meals.append(c) }
        return ParsedNutritionPlan(calories: calories, proteinG: protein, carbsG: carbs, fatG: fat, meals: meals)
    }
}

// MARK: - Risposta di un eventuale modello AI locale

/// Formato JSON che un modello AI locale deve restituire; i numeri vengono sempre limitati a valori plausibili.
public enum PlanAIOutput {
    struct EntryJSON: Decodable { let name: String?; let sets: Int?; let repsMin: Int?; let repsMax: Int?; let restSeconds: Int?; let weightKg: Double? }
    struct DayJSON: Decodable { let title: String?; let entries: [EntryJSON]? }
    struct PlanJSON: Decodable { let days: [DayJSON]? }

    public static let trainingPrompt = """
    Estrai la scheda di allenamento dal testo. Rispondi SOLO con JSON valido nel formato \
    {"days":[{"title":"","entries":[{"name":"","sets":0,"repsMin":0,"repsMax":0,"restSeconds":0,"weightKg":0}]}]}. \
    Non inventare dati: se un valore manca, omettilo.
    """

    /// Estrae il primo oggetto JSON dall'output del modello e lo trasforma in una scheda validata.
    public static func decodeTrainingPlan(from output: String) -> TrainingPlan? {
        guard let start = output.firstIndex(of: "{"), let end = output.lastIndex(of: "}"), start < end,
              let data = String(output[start...end]).data(using: .utf8),
              let json = try? JSONDecoder().decode(PlanJSON.self, from: data) else { return nil }
        func ok(_ v: Int?, _ r: ClosedRange<Int>) -> Int? { v.flatMap { r.contains($0) ? $0 : nil } }
        let days: [PlanDay] = (json.days ?? []).compactMap { d in
            let entries: [PlanEntry] = (d.entries ?? []).compactMap { e in
                guard let name = e.name?.trimmingCharacters(in: .whitespaces), name.filter(\.isLetter).count >= 3 else { return nil }
                let w = e.weightKg.flatMap { (0...500).contains($0) ? $0 : nil }
                return PlanEntry(name: name, sets: ok(e.sets, 1...12), repsMin: ok(e.repsMin, 1...100),
                                 repsMax: ok(e.repsMax, 1...100), restSeconds: ok(e.restSeconds, 10...600), weightKg: w)
            }
            return entries.isEmpty ? nil : PlanDay(title: d.title ?? "", entries: entries)
        }
        return days.isEmpty ? nil : TrainingPlan(days: days)
    }
}
