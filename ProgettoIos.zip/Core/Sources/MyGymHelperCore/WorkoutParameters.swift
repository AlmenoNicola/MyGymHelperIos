import Foundation

/// Parametri di un allenamento su un esercizio: quelli impostati dall'utente o proposti da un consiglio.
public struct WorkoutParameters: Equatable, Sendable {
    public var sets: Int
    public var reps: Int
    public var restSeconds: Int
    public var weightKg: Double

    public init(sets: Int, reps: Int, restSeconds: Int, weightKg: Double) {
        self.sets = sets; self.reps = reps; self.restSeconds = restSeconds; self.weightKg = weightKg
    }

    /// Limiti usati dalla schermata di impostazione (uguali su Android).
    public static let setsRange = 1...10
    public static let repsRange = 1...50
    public static let restRange = 15...600
    public static let weightRange = 0.0...500.0
    public static let weightStep = 1.25

    /// Riporta i valori nei limiti e arrotonda il peso al passo di 1,25 kg.
    public func clamped() -> WorkoutParameters {
        func c(_ v: Int, _ r: ClosedRange<Int>) -> Int { min(max(v, r.lowerBound), r.upperBound) }
        let w = min(max(weightKg, Self.weightRange.lowerBound), Self.weightRange.upperBound)
        return WorkoutParameters(sets: c(sets, Self.setsRange), reps: c(reps, Self.repsRange),
                                 restSeconds: c(restSeconds, Self.restRange),
                                 weightKg: (w / Self.weightStep).rounded() * Self.weightStep)
    }
}

extension CoachingResult {
    /// Applica i consigli a regole fisse (piano Mid) ai parametri attuali.
    public func applied(to current: WorkoutParameters) -> WorkoutParameters {
        var p = current
        for item in advice {
            switch item {
            case .increaseWeight(let kg):
                // Corpo libero (peso 0): invece di aggiungere carico si aggiunge una ripetizione, come nel motore adattivo.
                if p.weightKg > 0 { p.weightKg += kg } else { p.reps += 1 }
            case .decreaseWeight(let percent):
                let step = WorkoutParameters.weightStep
                p.weightKg = ((p.weightKg * (1 - Double(percent) / 100)) / step).rounded(.down) * step
            case .addSet: p.sets += 1
            case .removeSet: p.sets -= 1
            case .keepAsIs: break
            }
        }
        p.restSeconds = restSeconds
        return p.clamped()
    }
}

extension AdaptiveAdvice {
    /// Parametri proposti dal motore adattivo (piano Full). Se il consiglio non ha un peso (nessun dato) si tiene quello attuale.
    public func parameters(keepingWeight current: Double) -> WorkoutParameters {
        WorkoutParameters(sets: sets, reps: reps, restSeconds: restSeconds,
                          weightKg: weightKg > 0 ? weightKg : current).clamped()
    }
}
