import Foundation

/// Livelli di abbonamento. Free è gratuito; Mid e Full sono a pagamento.
public enum SubscriptionTier: Int, Comparable, Codable, Sendable {
    case free = 0
    case mid = 1
    case full = 2

    public static func < (lhs: SubscriptionTier, rhs: SubscriptionTier) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
}

/// Funzioni dell'app soggette al livello di abbonamento.
public enum Feature: CaseIterable, Sendable {
    case repCounting            // conteggio con serie, ripetizioni e pausa impostati dall'utente
    case bmi
    case catalogOnePerType      // catalogo limitato: un esercizio per tipologia
    case catalogFull
    case savedExerciseLists
    case muscleSelection
    case fixedCoaching          // consigli a regole fisse in base alle serie fatte
    case generalNutritionAdvice
    case appleWatch
    case adaptiveCoaching
    case uploadTrainingAndNutritionPlans
    case dietPlans
    case offlineFull
    case cloudSync
}

public enum FeatureGate {
    /// Livello minimo richiesto per ogni funzione (da confermare: vedi documento specifiche).
    public static func minimumTier(for feature: Feature) -> SubscriptionTier {
        switch feature {
        case .repCounting, .bmi, .catalogOnePerType:
            return .free
        case .catalogFull, .savedExerciseLists, .muscleSelection,
             .fixedCoaching, .generalNutritionAdvice, .appleWatch:
            return .mid
        case .adaptiveCoaching, .uploadTrainingAndNutritionPlans,
             .dietPlans, .offlineFull, .cloudSync:
            return .full
        }
    }

    public static func isAvailable(_ feature: Feature, for tier: SubscriptionTier) -> Bool {
        tier >= minimumTier(for: feature)
    }
}
