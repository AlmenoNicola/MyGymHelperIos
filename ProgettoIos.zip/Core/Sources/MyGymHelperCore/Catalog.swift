import Foundation

public enum Mechanic: String, Codable, Sendable { case compound, isolation }

/// Esercizio del catalogo dell'app, indipendente dalla fonte (elenco incluso nell'app o API).
public struct CatalogExercise: Codable, Identifiable, Hashable, Sendable {
    public let id: String
    public let name: String
    public let primary: [MuscleGroup]
    public let secondary: [MuscleGroup]
    public let equipment: String
    public let mechanic: Mechanic
    public let steps: [String]

    public init(id: String, name: String, primary: [MuscleGroup], secondary: [MuscleGroup] = [],
                equipment: String = "", mechanic: Mechanic = .compound, steps: [String] = []) {
        self.id = id; self.name = name; self.primary = primary; self.secondary = secondary
        self.equipment = equipment; self.mechanic = mechanic; self.steps = steps
    }

    public var isLowerBody: Bool { primary.contains { $0.isLowerBody } }
    public var isCompound: Bool { mechanic == .compound }
}

/// Formato dell'elenco di esercizi incluso nell'app (testi scritti da noi, in piu' lingue).
struct SeedExercise: Decodable {
    let id: String
    let muscles: [String]
    let secondary: [String]?
    let equipment: String
    let mechanic: String
    let names: [String: String]
    let steps: [String: [String]]
}

public enum SeedCatalog {
    public static func decode(_ data: Data, language: String) throws -> [CatalogExercise] {
        let seeds = try JSONDecoder().decode([SeedExercise].self, from: data)
        return seeds.compactMap { s in
            let primary = s.muscles.compactMap(MuscleGroup.init(rawValue:))
            guard !primary.isEmpty else { return nil }
            return CatalogExercise(
                id: s.id,
                name: s.names[language] ?? s.names["en"] ?? s.id,
                primary: primary,
                secondary: (s.secondary ?? []).compactMap(MuscleGroup.init(rawValue:)),
                equipment: s.equipment,
                mechanic: s.mechanic == "isolation" ? .isolation : .compound,
                steps: s.steps[language] ?? s.steps["en"] ?? [])
        }
    }
}

extension Exercise {
    /// Converte un esercizio dell'API in esercizio del catalogo (scartato se i muscoli non sono riconosciuti).
    public func toCatalog() -> CatalogExercise? {
        let primary = primaryMuscles.compactMap(MuscleGroup.init(apiName:))
        guard !primary.isEmpty else { return nil }
        let secondary = (secondaryMuscles ?? []).compactMap(MuscleGroup.init(apiName:))
        let isIsolation = (mechanic ?? "").lowercased().contains("isolation")
        return CatalogExercise(id: "mw-\(id)", name: name, primary: primary, secondary: secondary,
                               equipment: category ?? "", mechanic: isIsolation ? .isolation : .compound, steps: steps)
    }
}

public enum CatalogAccess {
    /// Piano Free: un esercizio per tipologia (gruppo muscolare principale), il primo in ordine di id.
    /// Mid e Full: catalogo completo.
    public static func visible(_ all: [CatalogExercise], tier: SubscriptionTier) -> [CatalogExercise] {
        if FeatureGate.isAvailable(.catalogFull, for: tier) { return all }
        var seen = Set<MuscleGroup>()
        var result: [CatalogExercise] = []
        for exercise in all.sorted(by: { $0.id < $1.id }) {
            guard let muscle = exercise.primary.first, !seen.contains(muscle) else { continue }
            seen.insert(muscle)
            result.append(exercise)
        }
        return result
    }
}

/// Collega il nome di un esercizio di una scheda a un esercizio del catalogo (somiglianza tra parole).
public enum ExerciseMatcher {
    private static let stopwords: Set<String> = ["con", "da", "al", "di", "il", "la", "lo", "the", "with", "a", "e", "and", "on"]

    static func tokens(_ s: String) -> Set<String> {
        let folded = s.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: nil)
        let parts = folded.components(separatedBy: CharacterSet.alphanumerics.inverted)
        return Set(parts.filter { $0.count > 1 && !stopwords.contains($0) })
    }

    public static func similarity(_ a: String, _ b: String) -> Double {
        let ta = tokens(a), tb = tokens(b)
        guard !ta.isEmpty, !tb.isEmpty else { return 0 }
        return Double(ta.intersection(tb).count) / Double(ta.union(tb).count)
    }

    public static func bestMatch(for name: String, in catalog: [CatalogExercise], threshold: Double = 0.5) -> CatalogExercise? {
        let scored = catalog.map { ($0, similarity(name, $0.name)) }.filter { $0.1 >= threshold }
        return scored.max(by: { $0.1 < $1.1 })?.0
    }
}
