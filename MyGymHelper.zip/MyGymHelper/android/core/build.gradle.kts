// Logica pura in Kotlin (port del pacchetto Swift MyGymHelperCore): nessuna dipendenza da Android.
plugins {
    alias(libs.plugins.kotlin.jvm)
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    testImplementation(kotlin("test"))
    testImplementation(libs.junit)
}
