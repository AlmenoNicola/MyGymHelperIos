package app.mygymhelper.core

import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class MuscleAndCatalogTests {
    @Test fun muscleNameMapping() {
        assertEquals(MuscleGroup.BICEPS, MuscleGroup.fromApiName("Biceps"))
        assertEquals(MuscleGroup.LOWER_BACK, MuscleGroup.fromApiName("Lower Back"))
        assertEquals(MuscleGroup.SHOULDERS, MuscleGroup.fromApiName("Front-shoulders"))
        assertEquals(MuscleGroup.SHOULDERS, MuscleGroup.fromApiName("Lateral deltoid"))
        assertEquals(MuscleGroup.ABS, MuscleGroup.fromApiName("Abdominals"))
        assertEquals(MuscleGroup.LATS, MuscleGroup.fromApiName("Lats"))
        assertNull(MuscleGroup.fromApiName("xyz"))
    }

    @Test fun regions() {
        assertEquals(3, BodyRegion.ARMS.muscles.size)
        assertTrue(MuscleGroup.QUADS.isLowerBody)
        assertFalse(MuscleGroup.CHEST.isLowerBody)
    }

    private val catalog = listOf(
        CatalogExercise("b", "Chest press", listOf(MuscleGroup.CHEST)),
        CatalogExercise("a", "Bench press", listOf(MuscleGroup.CHEST)),
        CatalogExercise("c", "Row", listOf(MuscleGroup.LATS))
    )

    @Test fun freeSeesOnePerType() {
        assertEquals(listOf("a", "c"), CatalogAccess.visible(catalog, SubscriptionTier.FREE).map { it.id })
        assertEquals(3, CatalogAccess.visible(catalog, SubscriptionTier.MID).size)
    }

    @Test fun matcherFindsSimilarName() {
        val cat = listOf(CatalogExercise("x", "Panca piana con bilanciere", listOf(MuscleGroup.CHEST)),
            CatalogExercise("y", "Squat", listOf(MuscleGroup.QUADS)))
        assertEquals("x", ExerciseMatcher.bestMatch("Panca piana", cat)?.id)
        assertNull(ExerciseMatcher.bestMatch("Curl", cat))
    }

    @Test fun seedDecodeUsesLanguageAndFallback() {
        val json = """[{"id":"s1","muscles":["chest"],"secondary":["triceps"],"equipment":"barbell","mechanic":"compound",
          "names":{"it":"Panca","en":"Bench"},"steps":{"en":["Lie down"]}}]"""
        val it = SeedCatalog.decode(json, "it")
        assertEquals("Panca", it.first().name)
        assertEquals(listOf("Lie down"), it.first().steps)
        assertEquals("Bench", SeedCatalog.decode(json, "fr").first().name)
    }

    @Test fun backendExerciseConversion() {
        val list = Exercise.decodeList("""[{"id":7,"name":"Curl","primary_muscles":["Biceps"],"secondary_muscles":null,
            "category":"Dumbbells","mechanic":"Isolation","steps":["a","b"]},{"id":8,"name":"X","primary_muscles":["???"]}]""")
        assertEquals(2, list.size)
        val c = assertNotNull(list[0].toCatalog())
        assertEquals("mw-7", c.id)
        assertEquals(Mechanic.ISOLATION, c.mechanic)
        assertNull(list[1].toCatalog())
        assertEquals(list, Exercise.decodeList(Exercise.encodeList(list)))
    }
}

class RecommenderTests {
    @Test fun prefersUndertrainedMuscle() {
        val bench = CatalogExercise("bench", "Bench", listOf(MuscleGroup.CHEST), mechanic = Mechanic.COMPOUND)
        val row = CatalogExercise("row", "Row", listOf(MuscleGroup.LATS), mechanic = Mechanic.COMPOUND)
        val curl = CatalogExercise("curl", "Curl", listOf(MuscleGroup.BICEPS), mechanic = Mechanic.ISOLATION)
        val now = System.currentTimeMillis()
        val history = listOf(HistoryEntry(now, "bench", listOf(MuscleGroup.CHEST), 12))
        val recs = ExerciseRecommender.recommend(listOf(bench, row, curl), setOf(MuscleGroup.CHEST, MuscleGroup.LATS), history, now)
        assertEquals("row", recs.first().exercise.id)
        assertEquals(2, recs.size)
    }
}

class AdaptiveCoachTests {
    private fun session(weight: Double, planned: Int = 10, done: List<Int>, peaks: List<Double>? = null) =
        SessionSample(System.currentTimeMillis(), weight, done.mapIndexed { i, d ->
            SessionSetSample(d, planned, d < planned, peaks?.get(i) ?: 0.0)
        })

    @Test fun noHistoryUsesDefaultsAndPlan() {
        val a = AdaptiveCoach.advise(emptyList(), false, 3, 10)
        assertEquals(listOf("coach.nodata"), a.reasonKeys)
        assertEquals(3, a.sets); assertEquals(10, a.reps); assertEquals(75, a.restSeconds)
        val p = AdaptiveCoach.advise(emptyList(), true, 3, 10, PlanTarget(4, 8, 10, 90, 60.0))
        assertEquals(4, p.sets); assertEquals(8, p.reps); assertEquals(90, p.restSeconds); assertEquals(60.0, p.weightKg)
    }
    @Test fun progressIncreasesWeight() {
        val a = AdaptiveCoach.advise(listOf(session(100.0, done = listOf(10, 10, 10))), true, 3, 10)
        assertEquals(102.5, a.weightKg, 0.001)
        assertEquals(listOf("coach.progress"), a.reasonKeys)
        assertEquals(120, a.restSeconds)
    }
    @Test fun planRepRangeAddsRepsBeforeWeight() {
        val a = AdaptiveCoach.advise(listOf(session(100.0, done = listOf(10, 10, 10))), true, 3, 10, PlanTarget(repsMin = 8, repsMax = 12))
        assertEquals(11, a.reps); assertEquals(100.0, a.weightKg, 0.001)
        assertEquals(listOf("coach.morereps"), a.reasonKeys)
    }
    @Test fun twoPoorSessionsDeload() {
        val poor = session(100.0, done = listOf(5, 5, 5))
        val a = AdaptiveCoach.advise(listOf(poor, poor), true, 3, 10)
        assertEquals(90.0, a.weightKg, 0.001)
        assertTrue("coach.deload" in a.reasonKeys)
    }
    @Test fun poorSessionReducesLoadAndSet() {
        val a = AdaptiveCoach.advise(listOf(session(80.0, done = listOf(5, 5, 5))), false, 3, 10)
        assertEquals(72.5, a.weightKg, 0.001); assertEquals(2, a.sets)
        assertEquals(listOf("coach.reduce"), a.reasonKeys)
    }
    @Test fun highFatigueKeepsLoadAndRestsMore() {
        val a = AdaptiveCoach.advise(listOf(session(60.0, done = listOf(10, 10, 10), peaks = listOf(1.0, 0.9, 0.6))), false, 3, 10)
        assertEquals(60.0, a.weightKg, 0.001)
        assertEquals(listOf("coach.highfatigue"), a.reasonKeys)
        assertEquals(105, a.restSeconds)
    }
    @Test fun bodyweightProgressesByReps() {
        val a = AdaptiveCoach.advise(listOf(session(0.0, done = listOf(10, 10))), false, 2, 10)
        assertEquals(11, a.reps); assertEquals(0.0, a.weightKg)
    }
}

class PlanParserTests {
    private val sample = """
        Scheda forza - Mario
        Giorno A
        1. Panca piana 4x8-10 60kg rec 90s
        2) Croci con manubri 3 x 12 recupero 1'
        - Squat 5x5 80 kg pausa 2 min
        Giorno B
        Lat machine: 4 serie da 10 rec 75
        3x15 Curl bilanciere 20kg
        Note: bere acqua
        Venerdì
        Stacco 3x5 100kg rec 3"
    """.trimIndent()

    @Test fun parsesDaysAndEntries() {
        val plan = TrainingPlanParser.parse(sample)
        assertEquals(3, plan.days.size)
        val bench = plan.days[0].entries[0]
        assertEquals("Panca piana", bench.name)
        assertEquals(4, bench.sets); assertEquals(8, bench.repsMin); assertEquals(10, bench.repsMax)
        assertEquals(60.0, bench.weightKg); assertEquals(90, bench.restSeconds)
        assertEquals(60, plan.days[0].entries[1].restSeconds)
        assertEquals(120, plan.days[0].entries[2].restSeconds)
        assertEquals("Lat machine", plan.days[1].entries[0].name)
        assertEquals(75, plan.days[1].entries[0].restSeconds)
        assertEquals("Curl bilanciere", plan.days[1].entries[1].name)
        assertEquals("Venerdì", plan.days[2].title)
        assertEquals(180, plan.days[2].entries[0].restSeconds)
    }

    @Test fun ignoresLinesWithoutSets() = assertEquals(0, TrainingPlanParser.parse("Tempo totale 45 min\nBere acqua").days.size)

    @Test fun nutritionParser() {
        val text = """
            Piano alimentare - 2200 kcal
            Proteine 150 g, carboidrati 250 g, grassi 70 g
            Colazione: latte e cereali
            - 1 banana
            Spuntino
            yogurt greco
            Cena
            pesce, verdure
        """.trimIndent()
        val p = NutritionPlanParser.parse(text)
        assertEquals(2200, p.calories); assertEquals(150, p.proteinG); assertEquals(250, p.carbsG); assertEquals(70, p.fatG)
        assertEquals(listOf("Colazione", "Spuntino", "Cena"), p.meals.map { it.name })
        assertEquals(listOf("latte e cereali", "1 banana"), p.meals[0].items)
    }

    @Test fun aiOutputIsValidatedAndClamped() {
        val output = """Ecco: {"days":[{"title":"A","entries":[{"name":"Squat","sets":99,"repsMin":5,"repsMax":5,"weightKg":80},{"name":"","sets":3}]}]} fine"""
        val plan = assertNotNull(PlanAIOutput.decodeTrainingPlan(output))
        assertEquals(1, plan.days.first().entries.size)
        assertNull(plan.days.first().entries.first().sets)
        assertEquals(80.0, plan.days.first().entries.first().weightKg)
        assertNull(PlanAIOutput.decodeTrainingPlan("nessun json"))
    }
}

class DietPlannerTests {
    @Test fun veganExcludesAnimalFoods() {
        val proteins = DietPlanner.allowedFoods(setOf(DietType.VEGAN), FoodCategory.PROTEIN)
        assertFalse("food.chicken" in proteins); assertFalse("food.eggs" in proteins)
        assertFalse("food.greekYogurt" in proteins); assertTrue("food.tofu" in proteins)
    }
    @Test fun glutenFreeAndLactoseFree() {
        val carbs = DietPlanner.allowedFoods(setOf(DietType.GLUTEN_FREE), FoodCategory.CARBS)
        assertFalse("food.pasta" in carbs); assertFalse("food.bread" in carbs); assertTrue("food.rice" in carbs)
        val dairy = DietPlanner.allowedFoods(setOf(DietType.LACTOSE_FREE), FoodCategory.PROTEIN)
        assertFalse("food.greekYogurt" in dairy); assertTrue("food.lactoseFreeYogurt" in dairy)
    }
    @Test fun trainingDayHasMoreCaloriesAndMealsAddUp() {
        val t = NutritionCalculator.targets(BiologicalSex.MALE, 80.0, 180.0, 30, ActivityLevel.MODERATE, Goal.MAINTAIN)
        val rest = DietPlanner.plan(t, setOf(DietType.OMNIVORE), false)
        val train = DietPlanner.plan(t, setOf(DietType.OMNIVORE), true)
        assertTrue(train.calories > rest.calories)
        assertEquals(5, rest.meals.size)
        assertTrue(kotlin.math.abs(rest.meals.sumOf { it.calories } - rest.calories) <= 3)
    }
    @Test fun sameNumbersAsIosMockup() {
        // Profilo usato nella tavola delle schermate: 30 anni, 75 kg, 178 cm, moderata, mantenere, vegetariano.
        val t = NutritionCalculator.targets(BiologicalSex.MALE, 75.0, 178.0, 30, ActivityLevel.MODERATE, Goal.MAINTAIN)
        assertEquals(DailyTargets(2662, 120, 394, 68), t)
        val day = DietPlanner.plan(t, setOf(DietType.VEGETARIAN), true)
        assertEquals(2875, day.calories); assertEquals(447, day.carbsG)
        assertEquals(listOf("food.eggs", "food.rice", "food.oliveOil", "food.vegetables"), day.meals[0].suggestions)
    }
}

class Phase2Tests {
    @Test fun clampAndRoundWeight() {
        val p = WorkoutParameters(20, 0, 5, 41.0).clamped()
        assertEquals(10, p.sets); assertEquals(1, p.reps); assertEquals(15, p.restSeconds)
        assertEquals(41.25, p.weightKg, 0.001)
    }
    @Test fun fixedAdviceAllDoneLowerBody() {
        val r = FixedCoaching.advise(List(3) { SetOutcome(10, 10, false) }, true, true)
        val next = r.applied(WorkoutParameters(3, 10, 90, 60.0))
        assertEquals(62.5, next.weightKg, 0.001); assertEquals(4, next.sets); assertEquals(120, next.restSeconds)
    }
    @Test fun fixedAdviceManyStopped() {
        val r = FixedCoaching.advise(listOf(SetOutcome(10, 6, true), SetOutcome(10, 5, true), SetOutcome(10, 10, false)), false, false)
        val next = r.applied(WorkoutParameters(3, 10, 60, 20.0))
        assertEquals(17.5, next.weightKg, 0.001); assertEquals(2, next.sets); assertEquals(105, next.restSeconds)
    }
    @Test fun bodyweightAddsRepInsteadOfLoad() {
        val r = FixedCoaching.advise(List(2) { SetOutcome(12, 12, false) }, true, false)
        val next = r.applied(WorkoutParameters(2, 12, 90, 0.0))
        assertEquals(0.0, next.weightKg, 0.001); assertEquals(13, next.reps); assertEquals(2, next.sets)
    }
    @Test fun adaptiveKeepsCurrentWeightWithoutData() {
        val a = AdaptiveCoach.advise(emptyList(), true, 3, 10)
        assertEquals(40.0, a.parameters(40.0).weightKg, 0.001)
    }
}

class FoodFactsTests {
    @Test fun lenientDecoding() {
        val json = """{"products":[
          {"code":"8001","product_name":"Yogurt greco","brands":"Marca A, Marca B",
           "nutriments":{"energy-kcal_100g":"97","proteins_100g":9.5,"carbohydrates_100g":"3,8","fat_100g":5}},
          {"code":8002,"product_name":"","generic_name":"Riso","nutriments":{"energy_100g":1464}},
          {"code":"8003","product_name":"   "},
          {"product_name":"Senza codice"}
        ]}"""
        val items = FoodFacts.decodeSearch(json)
        assertEquals(2, items.size)
        assertEquals("Marca A", items[0].brand)
        assertEquals(97.0, items[0].kcal100g!!, 0.01)
        assertEquals(3.8, items[0].carbs100g!!, 0.01)
        assertEquals("8002", items[1].id); assertEquals("Riso", items[1].name)
        assertEquals(350.0, items[1].kcal100g!!, 1.0)
        assertNull(items[1].protein100g)
    }
    @Test fun implausibleValuesDropped() {
        val item = FoodFacts.decodeSearch("""{"products":[{"code":"1","product_name":"X","nutriments":{"proteins_100g":250,"fat_100g":-3}}]}""").first()
        assertNull(item.protein100g); assertNull(item.fat100g)
    }
    @Test fun searchUrl() {
        assertNull(FoodFacts.searchUrl(" a ", "it"))
        val url = assertNotNull(FoodFacts.searchUrl("yogurt greco", "it"))
        assertTrue("search_terms=yogurt%20greco" in url); assertTrue("json=1" in url)
    }
}

class StoreTests {
    @Test fun roundTrip() {
        val plan = TrainingPlanParser.parse("Giorno A\nPanca 4x8 60kg rec 90s")
        val data = AppData(
            sessions = listOf(WorkoutSessionRecord(startedAt = 1_700_000_000_000, endedAt = 1_700_000_600_000, limb = "arm",
                plannedSets = 3, plannedReps = 10, restSeconds = 90, exerciseId = "seed-bench-press",
                exerciseName = "Panca \"piana\"\n", weightKg = 62.5,
                sets = listOf(SetLog(1, 10, 10, false, 31.5, 0.42, false)))),
            lists = listOf(ExerciseListRecord(name = "Spinta", exerciseIds = listOf("a", "b"), createdAt = 5)),
            trainingPlans = listOf(TrainingPlanRecord(name = "Ottobre", createdAt = 6, plan = plan)),
            nutritionPlan = NutritionPlanRecord(createdAt = 7, plan = ParsedNutritionPlan(2200, meals = listOf(ParsedMeal(name = "Cena", items = listOf("pesce"))))),
            profile = HealthProfile(diets = listOf("vegan", "glutenFree"))
        )
        assertEquals(data, AppDataCodec.decode(AppDataCodec.encode(data)))
    }
    @Test fun emptyOrBrokenDataIsSafe() {
        assertEquals(AppData(), AppDataCodec.decode("{}"))
        assertEquals(emptyList(), AppDataCodec.decode("""{"sessions":[{"id":"x"}]}""").sessions)
    }
    @Test fun coachingSupportPicksNewestPlan() {
        val old = TrainingPlanRecord(name = "old", createdAt = 1, plan = TrainingPlanParser.parse("Panca piana 3x10 rec 60"))
        val new = TrainingPlanRecord(name = "new", createdAt = 2, plan = TrainingPlanParser.parse("Panca piana 5x5 rec 180"))
        val ex = CatalogExercise("seed-bench-press", "Panca piana", listOf(MuscleGroup.CHEST))
        assertEquals(5, CoachingSupport.planTarget(ex, listOf(old, new))?.sets)
    }
}
