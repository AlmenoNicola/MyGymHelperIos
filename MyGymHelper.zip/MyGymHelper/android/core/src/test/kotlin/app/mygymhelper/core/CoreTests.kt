package app.mygymhelper.core

import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

// Gli stessi casi dei test Swift (Core/Tests), per garantire che iOS e Android si comportino uguale.

class RepDetectorTests {
    private fun run(freq: Double, amp: Double, reps: Int, jitter: Double = 0.0, jitterHz: Double = 9.0): RepDetector {
        val d = RepDetector()
        val sr = 50.0; val lead = 1.0; val tail = 2.0
        val dur = reps / freq
        val n = ((lead + dur + tail) * sr).toInt()
        for (i in 0 until n) {
            val t = i / sr
            val tt = t - lead
            var v = if (tt >= 0 && tt <= dur) amp * sin(2 * PI * freq * tt) else 0.0
            v += jitter * sin(2 * PI * jitterHz * t)
            d.process(v, t)
        }
        return d
    }

    @Test fun slowTenReps() = assertEquals(10, run(0.5, 0.5, 10).count)
    @Test fun fastFiveReps() = assertEquals(5, run(1.0, 0.4, 5).count)
    @Test fun noiseOnlyCountsNothing() = assertEquals(0, run(0.5, 0.0, 10, jitter = 0.03, jitterHz = 7.0).count)
    @Test fun noisyEightReps() = assertEquals(8, run(0.4, 0.5, 8, jitter = 0.05).count)
    @Test fun tinyMotionCountsNothing() = assertEquals(0, run(0.5, 0.05, 6).count)

    @Test fun principalAxisFindsDominantDirection() {
        val samples = (0 until 200).map { i ->
            val a = sin(i * 0.2)
            Vector3(0.9 * a, 0.1 * a, 0.01 * cos(i.toDouble()))
        }
        val axis = assertNotNull(PrincipalAxis.estimate(samples))
        assertTrue(abs(axis.x) > 0.95)
    }
}

class BasicsTests {
    @Test fun normalBmi() {
        val r = assertNotNull(BmiCalculator.calculate(70.0, 175.0))
        assertEquals(22.86, r.value, 0.01)
        assertEquals(BmiCategory.NORMAL, r.category)
    }
    @Test fun invalidBmi() = assertNull(BmiCalculator.calculate(0.0, 170.0))
    @Test fun bmrMale() = assertEquals(1780.0, NutritionCalculator.bmr(BiologicalSex.MALE, 80.0, 180.0, 30), 0.01)
    @Test fun bmrFemale() = assertEquals(1345.25, NutritionCalculator.bmr(BiologicalSex.FEMALE, 60.0, 165.0, 25), 0.01)
    @Test fun loseIsBelowMaintain() {
        val lose = NutritionCalculator.targets(BiologicalSex.MALE, 80.0, 180.0, 30, ActivityLevel.MODERATE, Goal.LOSE)
        val keep = NutritionCalculator.targets(BiologicalSex.MALE, 80.0, 180.0, 30, ActivityLevel.MODERATE, Goal.MAINTAIN)
        assertTrue(lose.calories < keep.calories)
    }
    @Test fun featureGate() {
        assertTrue(FeatureGate.isAvailable(Feature.BMI, SubscriptionTier.FREE))
        assertTrue(FeatureGate.isAvailable(Feature.REP_COUNTING, SubscriptionTier.FREE))
        assertFalse(FeatureGate.isAvailable(Feature.CATALOG_FULL, SubscriptionTier.FREE))
        assertTrue(FeatureGate.isAvailable(Feature.WEARABLE, SubscriptionTier.MID))
        assertFalse(FeatureGate.isAvailable(Feature.ADAPTIVE_COACHING, SubscriptionTier.MID))
        assertTrue(FeatureGate.isAvailable(Feature.ADAPTIVE_COACHING, SubscriptionTier.FULL))
    }
}

class FixedCoachingTests {
    @Test fun allCompletedIncreasesWeightAndAddsSet() {
        val sets = List(3) { SetOutcome(10, 10, false) }
        val r = FixedCoaching.advise(sets, isCompound = true, isLowerBody = true)
        assertTrue(CoachingAdvice.IncreaseWeight(2.5) in r.advice)
        assertTrue(CoachingAdvice.AddSet in r.advice)
        assertEquals(120, r.restSeconds)
    }
    @Test fun manyStoppedDecreases() {
        val sets = listOf(SetOutcome(10, 6, true), SetOutcome(10, 5, true), SetOutcome(10, 10, false))
        val r = FixedCoaching.advise(sets, isCompound = false, isLowerBody = false)
        assertTrue(CoachingAdvice.DecreaseWeight(10) in r.advice)
        assertTrue(CoachingAdvice.RemoveSet in r.advice)
    }
}

class SessionEngineTests {
    @Test fun fullFlowWithCountdownAndStop() {
        val e = SessionEngine(2, 3, 20)
        assertEquals(listOf<SessionCue>(SessionCue.SetStarted(1)), e.start(100.0))
        assertEquals(SessionPhase.Working(1), e.phase)
        assertEquals(emptyList(), e.repsCounted(1, 102.0))
        assertEquals(emptyList(), e.repsCounted(2, 106.0))
        assertEquals(listOf(SessionCue.TargetReached, SessionCue.RestStarted(20)), e.repsCounted(3, 110.0))
        assertEquals(SessionPhase.Resting(1, 20), e.phase)
        assertEquals(1, e.records.size)
        assertFalse(e.records[0].stoppedEarly)
        assertEquals(10.0, e.records[0].durationSeconds, 0.001)
        assertEquals(emptyList(), e.tick(120.0))
        assertEquals(listOf<SessionCue>(SessionCue.RestCountdown(3)), e.tick(127.2))
        assertEquals(emptyList(), e.tick(127.3))
        assertEquals(listOf<SessionCue>(SessionCue.RestCountdown(1)), e.tick(129.0))
        assertEquals(listOf<SessionCue>(SessionCue.RestEnded), e.tick(130.1))
        assertEquals(SessionPhase.Working(2), e.phase)
        assertEquals(listOf<SessionCue>(SessionCue.SessionFinished), e.stop(2, 140.0))
        assertEquals(SessionPhase.Finished, e.phase)
        assertEquals(2, e.records.size)
        assertTrue(e.records[1].stoppedEarly)
        assertEquals(2, e.records[1].doneReps)
    }
    @Test fun repsIgnoredDuringRest() {
        val e = SessionEngine(2, 2, 30); e.start(0.0); e.repsCounted(2, 5.0)
        assertEquals(emptyList(), e.repsCounted(5, 6.0))
        assertEquals(1, e.records.size)
    }
    @Test fun skipRestStartsNextSet() {
        val e = SessionEngine(3, 2, 60); e.start(0.0); e.repsCounted(2, 5.0)
        assertEquals(listOf<SessionCue>(SessionCue.RestEnded), e.skipRest(8.0))
        assertEquals(SessionPhase.Working(2), e.phase)
        assertEquals(0, e.currentReps)
    }
    @Test fun stopWithAllRepsIsNotStoppedEarly() {
        val e = SessionEngine(1, 5, 30); e.start(0.0); e.stop(9, 10.0)
        assertFalse(e.records[0].stoppedEarly)
        assertEquals(5, e.records[0].doneReps)
    }
    @Test fun lastSetFinishesSession() {
        val e = SessionEngine(1, 2, 30); e.start(0.0)
        assertEquals(listOf(SessionCue.TargetReached, SessionCue.SessionFinished), e.repsCounted(2, 4.0))
        assertEquals(SessionPhase.Finished, e.phase)
    }
    @Test fun endNowSavesPartialSet() {
        val e = SessionEngine(3, 10, 30); e.start(0.0); e.repsCounted(4, 8.0)
        assertEquals(listOf<SessionCue>(SessionCue.SessionFinished), e.endNow(9.0))
        assertEquals(1, e.records.size)
        assertEquals(4, e.records[0].doneReps)
        assertTrue(e.records[0].stoppedEarly)
    }
}
