package app.mygymhelper.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// ---------- Rilevatore di ripetizioni ----------

data class Vector3(val x: Double, val y: Double, val z: Double) {
    fun dot(o: Vector3) = x * o.x + y * o.y + z * o.z
    val length: Double get() = sqrt(x * x + y * y + z * z)
}

/** Asse dominante del movimento da accelerazioni 3D (gravità già rimossa), con 50 iterazioni di potenza. */
object PrincipalAxis {
    fun estimate(samples: List<Vector3>): Vector3? {
        if (samples.size < 10) return null
        val n = samples.size.toDouble()
        val mx = samples.sumOf { it.x } / n; val my = samples.sumOf { it.y } / n; val mz = samples.sumOf { it.z } / n
        val c = Array(3) { DoubleArray(3) }
        for (s in samples) {
            val d = doubleArrayOf(s.x - mx, s.y - my, s.z - mz)
            for (i in 0..2) for (j in 0..2) c[i][j] += d[i] * d[j] / n
        }
        var v = doubleArrayOf(1.0, 1.0, 1.0)
        repeat(50) {
            val w = DoubleArray(3)
            for (i in 0..2) for (j in 0..2) w[i] += c[i][j] * v[j]
            val len = sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2])
            if (len < 1e-12) return null
            v = doubleArrayOf(w[0] / len, w[1] / len, w[2] / len)
        }
        return Vector3(v[0], v[1], v[2])
    }
}

data class RepEvent(val index: Int, val timestamp: Double, val peakAmplitude: Double)

data class RepDetectorConfig(
    val cutoffHz: Double = 3.0,          // filtro passa-basso
    val minPeak: Double = 0.12,          // ampiezza minima (g)
    val minInterval: Double = 0.7,       // secondi minimi tra due ripetizioni
    val thresholdFraction: Double = 0.5, // soglia adattiva rispetto al picco medio
    val rearmFraction: Double = 0.3      // isteresi
)

/** Rilevatore di ripetizioni in tempo reale su un segnale 1D. Valori di default da tarare su telefoni veri. */
class RepDetector(private val config: RepDetectorConfig = RepDetectorConfig()) {
    private var smoothed: Double? = null
    private var lastTime: Double? = null
    private var prev2: Pair<Double, Double>? = null   // (t, v)
    private var prev1: Pair<Double, Double>? = null
    private var averagePeak: Double? = null
    private var lastRepTime: Double? = null
    private var armed = true
    var count = 0; private set
    val events = ArrayList<RepEvent>()

    private val threshold: Double
        get() = averagePeak?.let { max(config.minPeak, config.thresholdFraction * it) } ?: config.minPeak

    /** Restituisce un evento quando riconosce una ripetizione (con un campione di ritardo). */
    fun process(value: Double, time: Double): RepEvent? {
        val s = smoothed; val lt = lastTime
        smoothed = if (s != null && lt != null) {
            val dt = max(time - lt, 1e-6)
            val rc = 1 / (2 * PI * config.cutoffHz)
            s + (dt / (rc + dt)) * (value - s)
        } else value
        lastTime = time
        val current = time to (smoothed ?: value)
        var event: RepEvent? = null
        val th = threshold
        val p1 = prev1; val p2 = prev2
        if (p1 != null && p2 != null) {
            if (!armed && current.second < config.rearmFraction * th) armed = true
            val isPeak = p1.second > p2.second && p1.second >= current.second
            val farEnough = lastRepTime?.let { p1.first - it >= config.minInterval } ?: true
            if (armed && isPeak && p1.second > th && farEnough) {
                count += 1
                lastRepTime = p1.first
                armed = false
                averagePeak = averagePeak?.let { 0.7 * it + 0.3 * p1.second } ?: p1.second
                event = RepEvent(count, p1.first, p1.second).also { events.add(it) }
            }
        }
        prev2 = prev1
        prev1 = current
        return event
    }

    /** 0..1: bassa se ampiezze e intervalli sono molto irregolari (telefono in tasca). */
    val signalConfidence: Double
        get() {
            if (events.size < 3) return 1.0
            fun cv(xs: List<Double>): Double {
                val m = xs.sum() / xs.size
                if (m <= 0) return 1.0
                val v = xs.sumOf { (it - m) * (it - m) } / xs.size
                return sqrt(v) / m
            }
            val amps = events.map { it.peakAmplitude }
            val gaps = events.zipWithNext { a, b -> b.timestamp - a.timestamp }
            return max(0.0, min(1.0, 1 - max(cv(amps), cv(gaps))))
        }
}

// ---------- Macchina a stati della sessione ----------

sealed interface SessionPhase {
    data object NotStarted : SessionPhase
    data class Working(val set: Int) : SessionPhase
    data class Resting(val afterSet: Int, val remaining: Int) : SessionPhase
    data object Finished : SessionPhase
}

/** Avvisi che l'app trasforma in suono, vibrazione e voce. */
sealed interface SessionCue {
    data class SetStarted(val set: Int) : SessionCue
    data object TargetReached : SessionCue
    data class RestStarted(val seconds: Int) : SessionCue
    data class RestCountdown(val n: Int) : SessionCue
    data object RestEnded : SessionCue
    data object SessionFinished : SessionCue
}

data class SetRecord(val number: Int, val plannedReps: Int, val doneReps: Int,
                     val stoppedEarly: Boolean, val durationSeconds: Double) {
    val outcome: SetOutcome get() = SetOutcome(plannedReps, doneReps, stoppedEarly)
}

/** Macchina a stati senza UI, sensori o orologio: il tempo arriva dall'esterno (`now`, in secondi). */
class SessionEngine(sets: Int, reps: Int, restSeconds: Int) {
    val totalSets = max(1, sets)
    val targetReps = max(1, reps)
    val restSeconds = max(0, restSeconds)
    var phase: SessionPhase = SessionPhase.NotStarted; private set
    val records = ArrayList<SetRecord>()
    var currentReps = 0; private set

    private var setStartedAt = 0.0
    private var restEndsAt = 0.0
    private var lastCountdown: Int? = null

    fun start(now: Double): List<SessionCue> {
        if (phase != SessionPhase.NotStarted) return emptyList()
        beginSet(1, now)
        return listOf(SessionCue.SetStarted(1))
    }

    /** Ripetizioni contate dal sensore nella serie corrente (cumulativo). Ignorato in pausa. */
    fun repsCounted(count: Int, now: Double): List<SessionCue> {
        if (phase !is SessionPhase.Working) return emptyList()
        currentReps = min(max(count, currentReps), targetReps)
        if (currentReps < targetReps) return emptyList()
        return finishSet(targetReps, false, now)
    }

    /** L'utente dice di essersi fermato e indica quante ripetizioni ha fatto. */
    fun stop(doneReps: Int, now: Double): List<SessionCue> {
        if (phase !is SessionPhase.Working) return emptyList()
        val done = min(max(doneReps, 0), targetReps)
        return finishSet(done, done < targetReps, now)
    }

    /** Termina subito (la serie in corso si salva come interrotta, se ha ripetizioni). */
    fun endNow(now: Double): List<SessionCue> = when (val p = phase) {
        is SessionPhase.Working -> {
            if (currentReps > 0) records.add(SetRecord(p.set, targetReps, currentReps, true, max(0.0, now - setStartedAt)))
            phase = SessionPhase.Finished
            listOf(SessionCue.SessionFinished)
        }
        is SessionPhase.Resting -> { phase = SessionPhase.Finished; listOf(SessionCue.SessionFinished) }
        else -> emptyList()
    }

    /** Da chiamare spesso (circa 4 volte al secondo): aggiorna la pausa e il conto alla rovescia. */
    fun tick(now: Double): List<SessionCue> {
        val p = phase as? SessionPhase.Resting ?: return emptyList()
        val remaining = kotlin.math.ceil(restEndsAt - now).toInt()
        if (remaining <= 0) { beginSet(p.afterSet + 1, now); return listOf(SessionCue.RestEnded) }
        phase = SessionPhase.Resting(p.afterSet, remaining)
        if (remaining <= 3 && lastCountdown != remaining) {
            lastCountdown = remaining
            return listOf(SessionCue.RestCountdown(remaining))
        }
        return emptyList()
    }

    fun skipRest(now: Double): List<SessionCue> {
        val p = phase as? SessionPhase.Resting ?: return emptyList()
        beginSet(p.afterSet + 1, now)
        return listOf(SessionCue.RestEnded)
    }

    private fun beginSet(number: Int, now: Double) {
        phase = SessionPhase.Working(number); currentReps = 0; setStartedAt = now
    }

    private fun finishSet(done: Int, stoppedEarly: Boolean, now: Double): List<SessionCue> {
        val n = (phase as? SessionPhase.Working)?.set ?: return emptyList()
        records.add(SetRecord(n, targetReps, done, stoppedEarly, max(0.0, now - setStartedAt)))
        val cues = ArrayList<SessionCue>()
        if (!stoppedEarly) cues.add(SessionCue.TargetReached)
        if (n >= totalSets) {
            phase = SessionPhase.Finished
            cues.add(SessionCue.SessionFinished)
            return cues
        }
        restEndsAt = now + restSeconds
        lastCountdown = null
        phase = SessionPhase.Resting(n, restSeconds)
        cues.add(SessionCue.RestStarted(restSeconds))
        return cues
    }
}

// ---------- Regole fisse (piano Mid) ----------

data class SetOutcome(val plannedReps: Int, val doneReps: Int, val stoppedEarly: Boolean) {
    val completed: Boolean get() = !stoppedEarly && doneReps >= plannedReps
}

sealed interface CoachingAdvice {
    data class IncreaseWeight(val byKg: Double) : CoachingAdvice
    data object KeepAsIs : CoachingAdvice
    data class DecreaseWeight(val percent: Int) : CoachingAdvice
    data object AddSet : CoachingAdvice
    data object RemoveSet : CoachingAdvice
}

data class CoachingResult(val advice: List<CoachingAdvice>, val restSeconds: Int, val reasonKey: String) {
    /** Applica i consigli ai parametri attuali. Corpo libero (peso 0): +1 ripetizione invece di +carico. */
    fun applied(current: WorkoutParameters): WorkoutParameters {
        var p = current
        for (item in advice) {
            p = when (item) {
                is CoachingAdvice.IncreaseWeight ->
                    if (p.weightKg > 0) p.copy(weightKg = p.weightKg + item.byKg) else p.copy(reps = p.reps + 1)
                is CoachingAdvice.DecreaseWeight -> {
                    val step = WorkoutParameters.WEIGHT_STEP
                    p.copy(weightKg = kotlin.math.floor((p.weightKg * (1 - item.percent / 100.0)) / step) * step)
                }
                CoachingAdvice.AddSet -> p.copy(sets = p.sets + 1)
                CoachingAdvice.RemoveSet -> p.copy(sets = p.sets - 1)
                CoachingAdvice.KeepAsIs -> p
            }
        }
        return p.copy(restSeconds = restSeconds).clamped()
    }
}

object FixedCoaching {
    fun advise(sets: List<SetOutcome>, isCompound: Boolean, isLowerBody: Boolean,
               maxSets: Int = 5, minSets: Int = 2): CoachingResult {
        val rest = if (isCompound) 120 else 75
        if (sets.isEmpty()) return CoachingResult(listOf(CoachingAdvice.KeepAsIs), rest, "coach.nodata")
        val allDone = sets.all { it.completed }
        val stopped = sets.count { it.stoppedEarly }
        if (allDone) {
            val advice = mutableListOf<CoachingAdvice>(CoachingAdvice.IncreaseWeight(if (isLowerBody) 2.5 else 1.25))
            if (sets.size < maxSets && sets.size >= 3) advice.add(CoachingAdvice.AddSet)
            return CoachingResult(advice, rest, "coach.alldone")
        }
        if (stopped * 2 >= sets.size) {
            val advice = mutableListOf<CoachingAdvice>(CoachingAdvice.DecreaseWeight(10))
            if (sets.size > minSets) advice.add(CoachingAdvice.RemoveSet)
            return CoachingResult(advice, rest + 30, "coach.manystopped")
        }
        return CoachingResult(listOf(CoachingAdvice.KeepAsIs), rest, "coach.keep")
    }
}

// ---------- Parametri di un allenamento ----------

data class WorkoutParameters(val sets: Int, val reps: Int, val restSeconds: Int, val weightKg: Double) {
    /** Riporta i valori nei limiti e arrotonda il peso al passo di 1,25 kg. */
    fun clamped(): WorkoutParameters {
        fun c(v: Int, r: IntRange) = min(max(v, r.first), r.last)
        val w = min(max(weightKg, 0.0), 500.0)
        return WorkoutParameters(c(sets, SETS_RANGE), c(reps, REPS_RANGE), c(restSeconds, REST_RANGE),
            (w / WEIGHT_STEP).swiftRound() * WEIGHT_STEP)
    }

    companion object {
        val SETS_RANGE = 1..10
        val REPS_RANGE = 1..50
        val REST_RANGE = 15..600
        const val WEIGHT_STEP = 1.25
    }
}

internal fun absD(v: Double) = abs(v)
