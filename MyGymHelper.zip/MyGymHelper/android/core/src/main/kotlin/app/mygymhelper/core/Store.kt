package app.mygymhelper.core

import java.util.UUID

// Dati salvati sul telefono (equivalente dei modelli SwiftData dell'app iOS). Contengono dati sanitari:
// l'app li scrive solo con il consenso, in una cartella esclusa dai backup (noBackupFilesDir).

data class SetLog(val number: Int, val plannedReps: Int, val doneReps: Int, val stoppedEarly: Boolean,
                  val durationSeconds: Double, val averagePeak: Double, val lowConfidence: Boolean)

data class WorkoutSessionRecord(
    val id: String = UUID.randomUUID().toString(),
    val startedAt: Long,
    val endedAt: Long?,
    val limb: String,
    val plannedSets: Int,
    val plannedReps: Int,
    val restSeconds: Int,
    val exerciseId: String = "",
    val exerciseName: String = "",
    val weightKg: Double = 0.0,
    val sets: List<SetLog> = emptyList()
)

data class ExerciseListRecord(val id: String = UUID.randomUUID().toString(), val name: String,
                              val exerciseIds: List<String> = emptyList(), val createdAt: Long = System.currentTimeMillis())

data class TrainingPlanRecord(val id: String = UUID.randomUUID().toString(), val name: String,
                              val createdAt: Long = System.currentTimeMillis(), val plan: TrainingPlan)

data class NutritionPlanRecord(val id: String = UUID.randomUUID().toString(),
                               val createdAt: Long = System.currentTimeMillis(), val plan: ParsedNutritionPlan)

data class HealthProfile(val sex: String = "male", val age: Int = 30, val heightCm: Double = 170.0,
                         val weightKg: Double = 70.0, val activity: Double = 1.375, val goal: String = "maintain",
                         val diets: List<String> = listOf("omnivore"))

data class AppData(
    val sessions: List<WorkoutSessionRecord> = emptyList(),
    val lists: List<ExerciseListRecord> = emptyList(),
    val trainingPlans: List<TrainingPlanRecord> = emptyList(),
    val nutritionPlan: NutritionPlanRecord? = null,
    val profile: HealthProfile? = null
) {
    companion object {
        const val VERSION = 1
    }
}

/** Conversione JSON dei dati locali (formato stabile e versionato). */
object AppDataCodec {
    fun encode(d: AppData): String = MiniJson.stringify(mapOf(
        "version" to AppData.VERSION,
        "sessions" to d.sessions.map { s ->
            mapOf("id" to s.id, "startedAt" to s.startedAt, "endedAt" to s.endedAt, "limb" to s.limb,
                "plannedSets" to s.plannedSets, "plannedReps" to s.plannedReps, "restSeconds" to s.restSeconds,
                "exerciseId" to s.exerciseId, "exerciseName" to s.exerciseName, "weightKg" to s.weightKg,
                "sets" to s.sets.map { l ->
                    mapOf("number" to l.number, "plannedReps" to l.plannedReps, "doneReps" to l.doneReps,
                        "stoppedEarly" to l.stoppedEarly, "durationSeconds" to l.durationSeconds,
                        "averagePeak" to l.averagePeak, "lowConfidence" to l.lowConfidence)
                })
        },
        "lists" to d.lists.map { mapOf("id" to it.id, "name" to it.name, "exerciseIds" to it.exerciseIds, "createdAt" to it.createdAt) },
        "trainingPlans" to d.trainingPlans.map { mapOf("id" to it.id, "name" to it.name, "createdAt" to it.createdAt, "plan" to planToJson(it.plan)) },
        "nutritionPlan" to d.nutritionPlan?.let { mapOf("id" to it.id, "createdAt" to it.createdAt, "plan" to nutritionToJson(it.plan)) },
        "profile" to d.profile?.let { p ->
            mapOf("sex" to p.sex, "age" to p.age, "heightCm" to p.heightCm, "weightKg" to p.weightKg,
                "activity" to p.activity, "goal" to p.goal, "diets" to p.diets)
        }
    ))

    fun decode(json: String): AppData {
        val o = MiniJson.parse(json).obj() ?: return AppData()
        return AppData(
            sessions = o["sessions"].arr().orEmpty().mapNotNull { v ->
                val s = v.obj() ?: return@mapNotNull null
                WorkoutSessionRecord(
                    id = s["id"].str() ?: UUID.randomUUID().toString(),
                    startedAt = s["startedAt"].num()?.toLong() ?: return@mapNotNull null,
                    endedAt = s["endedAt"].num()?.toLong(),
                    limb = s["limb"].str() ?: "arm",
                    plannedSets = s["plannedSets"].int() ?: 0, plannedReps = s["plannedReps"].int() ?: 0,
                    restSeconds = s["restSeconds"].int() ?: 0,
                    exerciseId = s["exerciseId"].str() ?: "", exerciseName = s["exerciseName"].str() ?: "",
                    weightKg = s["weightKg"].num() ?: 0.0,
                    sets = s["sets"].arr().orEmpty().mapNotNull { lv ->
                        val l = lv.obj() ?: return@mapNotNull null
                        SetLog(l["number"].int() ?: 0, l["plannedReps"].int() ?: 0, l["doneReps"].int() ?: 0,
                            l["stoppedEarly"].bool() ?: false, l["durationSeconds"].num() ?: 0.0,
                            l["averagePeak"].num() ?: 0.0, l["lowConfidence"].bool() ?: false)
                    })
            },
            lists = o["lists"].arr().orEmpty().mapNotNull { v ->
                val l = v.obj() ?: return@mapNotNull null
                ExerciseListRecord(l["id"].str() ?: UUID.randomUUID().toString(), l["name"].str() ?: return@mapNotNull null,
                    l["exerciseIds"].strings(), l["createdAt"].num()?.toLong() ?: 0L)
            },
            trainingPlans = o["trainingPlans"].arr().orEmpty().mapNotNull { v ->
                val t = v.obj() ?: return@mapNotNull null
                TrainingPlanRecord(t["id"].str() ?: UUID.randomUUID().toString(), t["name"].str() ?: "",
                    t["createdAt"].num()?.toLong() ?: 0L, planFromJson(t["plan"]) ?: return@mapNotNull null)
            },
            nutritionPlan = o["nutritionPlan"].obj()?.let { n ->
                nutritionFromJson(n["plan"])?.let { NutritionPlanRecord(n["id"].str() ?: UUID.randomUUID().toString(),
                    n["createdAt"].num()?.toLong() ?: 0L, it) }
            },
            profile = o["profile"].obj()?.let { p ->
                HealthProfile(p["sex"].str() ?: "male", p["age"].int() ?: 30, p["heightCm"].num() ?: 170.0,
                    p["weightKg"].num() ?: 70.0, p["activity"].num() ?: 1.375, p["goal"].str() ?: "maintain",
                    p["diets"].strings().ifEmpty { listOf("omnivore") })
            }
        )
    }

    fun planToJson(p: TrainingPlan): Map<String, Any?> = mapOf("days" to p.days.map { d ->
        mapOf("id" to d.id, "title" to d.title, "entries" to d.entries.map { e ->
            mapOf("id" to e.id, "name" to e.name, "sets" to e.sets, "repsMin" to e.repsMin, "repsMax" to e.repsMax,
                "restSeconds" to e.restSeconds, "weightKg" to e.weightKg)
        })
    })

    fun planFromJson(v: Any?): TrainingPlan? {
        val o = v.obj() ?: return null
        return TrainingPlan(o["days"].arr().orEmpty().mapNotNull { dv ->
            val d = dv.obj() ?: return@mapNotNull null
            PlanDay(d["id"].str() ?: UUID.randomUUID().toString(), d["title"].str() ?: "",
                d["entries"].arr().orEmpty().mapNotNull { ev ->
                    val e = ev.obj() ?: return@mapNotNull null
                    PlanEntry(e["id"].str() ?: UUID.randomUUID().toString(), e["name"].str() ?: return@mapNotNull null,
                        e["sets"].int(), e["repsMin"].int(), e["repsMax"].int(), e["restSeconds"].int(), e["weightKg"].num())
                })
        })
    }

    fun nutritionToJson(p: ParsedNutritionPlan): Map<String, Any?> = mapOf(
        "calories" to p.calories, "proteinG" to p.proteinG, "carbsG" to p.carbsG, "fatG" to p.fatG,
        "meals" to p.meals.map { mapOf("id" to it.id, "name" to it.name, "items" to it.items) })

    fun nutritionFromJson(v: Any?): ParsedNutritionPlan? {
        val o = v.obj() ?: return null
        return ParsedNutritionPlan(o["calories"].int(), o["proteinG"].int(), o["carbsG"].int(), o["fatG"].int(),
            o["meals"].arr().orEmpty().mapNotNull { mv ->
                val m = mv.obj() ?: return@mapNotNull null
                ParsedMeal(m["id"].str() ?: UUID.randomUUID().toString(), m["name"].str() ?: "", m["items"].strings())
            })
    }
}

/** Ponte tra i dati salvati e i motori di consiglio (come CoachingService.swift). */
object CoachingSupport {
    fun samples(exerciseId: String, sessions: List<WorkoutSessionRecord>): List<SessionSample> =
        sessions.filter { it.exerciseId == exerciseId && it.sets.isNotEmpty() }
            .sortedBy { it.startedAt }
            .map { s -> SessionSample(s.startedAt, s.weightKg, s.sets.sortedBy { it.number }.map {
                SessionSetSample(it.doneReps, it.plannedReps, it.stoppedEarly, it.averagePeak) }) }

    fun historyEntries(sessions: List<WorkoutSessionRecord>, catalog: List<CatalogExercise>): List<HistoryEntry> =
        sessions.mapNotNull { s ->
            val ex = catalog.firstOrNull { it.id == s.exerciseId } ?: return@mapNotNull null
            HistoryEntry(s.startedAt, ex.id, ex.primary, s.sets.size)
        }

    /** Obiettivi della scheda più recente per l'esercizio, se il nome corrisponde. */
    fun planTarget(exercise: CatalogExercise, plans: List<TrainingPlanRecord>): PlanTarget? {
        val plan = plans.maxByOrNull { it.createdAt }?.plan ?: return null
        return plan.allEntries.map { it to ExerciseMatcher.similarity(it.name, exercise.name) }
            .filter { it.second >= 0.5 }.maxByOrNull { it.second }?.first?.target
    }

    fun adaptive(exercise: CatalogExercise, sessions: List<WorkoutSessionRecord>, plans: List<TrainingPlanRecord>,
                 defaultSets: Int, defaultReps: Int): AdaptiveAdvice =
        AdaptiveCoach.advise(samples(exercise.id, sessions), exercise.isCompound, defaultSets, defaultReps,
            planTarget(exercise, plans))

    fun fixed(exercise: CatalogExercise, sessions: List<WorkoutSessionRecord>): CoachingResult? {
        val last = samples(exercise.id, sessions).lastOrNull() ?: return null
        return FixedCoaching.advise(last.sets.map { SetOutcome(it.plannedReps, it.doneReps, it.stoppedEarly) },
            exercise.isCompound, exercise.isLowerBody)
    }
}
