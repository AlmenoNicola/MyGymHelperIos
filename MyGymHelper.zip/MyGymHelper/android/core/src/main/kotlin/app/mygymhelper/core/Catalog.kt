package app.mygymhelper.core

enum class BodyRegion(val raw: String) {
    ARMS("arms"), LEGS("legs"), CHEST("chest"), BACK("back"), SHOULDERS("shoulders"), CORE("core");
    val muscles: List<MuscleGroup> get() = MuscleGroup.entries.filter { it.region == this }
}

/** Gruppi muscolari usati da catalogo, mappa del corpo e consigli. `raw` = stessi nomi dell'app iOS. */
enum class MuscleGroup(val raw: String) {
    CHEST("chest"), SHOULDERS("shoulders"), BICEPS("biceps"), TRICEPS("triceps"), FOREARMS("forearms"),
    ABS("abs"), OBLIQUES("obliques"), TRAPS("traps"), LATS("lats"), LOWER_BACK("lowerBack"),
    GLUTES("glutes"), QUADS("quads"), HAMSTRINGS("hamstrings"), CALVES("calves");

    val region: BodyRegion
        get() = when (this) {
            CHEST -> BodyRegion.CHEST
            SHOULDERS -> BodyRegion.SHOULDERS
            BICEPS, TRICEPS, FOREARMS -> BodyRegion.ARMS
            ABS, OBLIQUES -> BodyRegion.CORE
            TRAPS, LATS, LOWER_BACK -> BodyRegion.BACK
            GLUTES, QUADS, HAMSTRINGS, CALVES -> BodyRegion.LEGS
        }

    val isLowerBody: Boolean get() = region == BodyRegion.LEGS

    companion object {
        fun fromRaw(raw: String): MuscleGroup? = entries.firstOrNull { it.raw == raw }

        /** Converte il nome di un muscolo dato da un'API esterna (da verificare con i dati reali di MuscleWiki). */
        fun fromApiName(apiName: String): MuscleGroup? {
            val n = apiName.lowercase().replace("-", " ").trim()
            if (n == "lat") return LATS
            val table = listOf(
                "lower back" to LOWER_BACK, "lumbar" to LOWER_BACK, "erector" to LOWER_BACK,
                "shoulder" to SHOULDERS, "delt" to SHOULDERS,
                "latissimus" to LATS, "lats" to LATS,
                "trap" to TRAPS, "rhomboid" to TRAPS, "middle back" to TRAPS, "upper back" to TRAPS,
                "chest" to CHEST, "pec" to CHEST,
                "bicep" to BICEPS, "tricep" to TRICEPS, "forearm" to FOREARMS,
                "oblique" to OBLIQUES, "abdom" to ABS, "abs" to ABS, "core" to ABS,
                "quad" to QUADS, "hamstring" to HAMSTRINGS, "glute" to GLUTES,
                "calf" to CALVES, "calves" to CALVES, "back" to LATS
            )
            return table.firstOrNull { n.contains(it.first) }?.second
        }
    }
}

enum class Mechanic { COMPOUND, ISOLATION }

/** Esercizio del catalogo dell'app, indipendente dalla fonte (elenco incluso o API). */
data class CatalogExercise(
    val id: String,
    val name: String,
    val primary: List<MuscleGroup>,
    val secondary: List<MuscleGroup> = emptyList(),
    val equipment: String = "",
    val mechanic: Mechanic = Mechanic.COMPOUND,
    val steps: List<String> = emptyList()
) {
    val isLowerBody: Boolean get() = primary.any { it.isLowerBody }
    val isCompound: Boolean get() = mechanic == Mechanic.COMPOUND
}

/** Esercizio nel formato del backend (stile MuscleWiki, vedi supabase/functions/catalog). */
data class Exercise(
    val id: Int,
    val name: String,
    val primaryMuscles: List<String>,
    val secondaryMuscles: List<String>? = null,
    val category: String? = null,
    val difficulty: String? = null,
    val force: String? = null,
    val mechanic: String? = null,
    val steps: List<String> = emptyList()
) {
    /** Converte in esercizio del catalogo (scartato se i muscoli non sono riconosciuti). */
    fun toCatalog(): CatalogExercise? {
        val primary = primaryMuscles.mapNotNull { MuscleGroup.fromApiName(it) }
        if (primary.isEmpty()) return null
        val secondary = (secondaryMuscles ?: emptyList()).mapNotNull { MuscleGroup.fromApiName(it) }
        val isolation = (mechanic ?: "").lowercase().contains("isolation")
        return CatalogExercise("mw-$id", name, primary, secondary, category ?: "",
            if (isolation) Mechanic.ISOLATION else Mechanic.COMPOUND, steps)
    }

    companion object {
        fun decodeList(json: String): List<Exercise> =
            (MiniJson.parse(json).arr() ?: throw MiniJson.ParseException("Atteso un array")).mapNotNull { item ->
                val o = item.obj() ?: return@mapNotNull null
                val id = o["id"].int() ?: return@mapNotNull null
                val name = o["name"].str() ?: return@mapNotNull null
                Exercise(id, name, o["primary_muscles"].strings(),
                    o["secondary_muscles"].arr()?.mapNotNull { it.str() },
                    o["category"].str(), o["difficulty"].str(), o["force"].str(), o["mechanic"].str(),
                    o["steps"].strings())
            }

        fun encodeList(list: List<Exercise>): String = MiniJson.stringify(list.map {
            mapOf("id" to it.id, "name" to it.name, "primary_muscles" to it.primaryMuscles,
                "secondary_muscles" to it.secondaryMuscles, "category" to it.category, "difficulty" to it.difficulty,
                "force" to it.force, "mechanic" to it.mechanic, "steps" to it.steps)
        })
    }
}

/** Elenco di esercizi incluso nell'app (testi scritti da noi, in più lingue). */
object SeedCatalog {
    fun decode(json: String, language: String): List<CatalogExercise> {
        val seeds = MiniJson.parse(json).arr() ?: return emptyList()
        return seeds.mapNotNull { item ->
            val s = item.obj() ?: return@mapNotNull null
            val id = s["id"].str() ?: return@mapNotNull null
            val primary = s["muscles"].strings().mapNotNull { MuscleGroup.fromRaw(it) }
            if (primary.isEmpty()) return@mapNotNull null
            val names = s["names"].obj() ?: emptyMap()
            val steps = s["steps"].obj() ?: emptyMap()
            CatalogExercise(
                id = id,
                name = names[language].str() ?: names["en"].str() ?: id,
                primary = primary,
                secondary = s["secondary"].strings().mapNotNull { MuscleGroup.fromRaw(it) },
                equipment = s["equipment"].str() ?: "",
                mechanic = if (s["mechanic"].str() == "isolation") Mechanic.ISOLATION else Mechanic.COMPOUND,
                steps = steps[language]?.strings()?.takeIf { it.isNotEmpty() } ?: steps["en"].strings()
            )
        }
    }
}

object CatalogAccess {
    /** Piano Free: un esercizio per gruppo muscolare principale, il primo in ordine di id. Mid e Full: completo. */
    fun visible(all: List<CatalogExercise>, tier: SubscriptionTier): List<CatalogExercise> {
        if (FeatureGate.isAvailable(Feature.CATALOG_FULL, tier)) return all
        val seen = HashSet<MuscleGroup>()
        val result = ArrayList<CatalogExercise>()
        for (exercise in all.sortedBy { it.id }) {
            val muscle = exercise.primary.firstOrNull() ?: continue
            if (!seen.add(muscle)) continue
            result.add(exercise)
        }
        return result
    }
}

/** Collega il nome di un esercizio di una scheda a un esercizio del catalogo (somiglianza tra parole). */
object ExerciseMatcher {
    private val stopwords = setOf("con", "da", "al", "di", "il", "la", "lo", "the", "with", "a", "e", "and", "on")

    internal fun tokens(s: String): Set<String> {
        val folded = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "").lowercase()
        return folded.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 1 && it !in stopwords }.toSet()
    }

    fun similarity(a: String, b: String): Double {
        val ta = tokens(a); val tb = tokens(b)
        if (ta.isEmpty() || tb.isEmpty()) return 0.0
        return (ta intersect tb).size.toDouble() / (ta union tb).size.toDouble()
    }

    fun bestMatch(name: String, catalog: List<CatalogExercise>, threshold: Double = 0.5): CatalogExercise? =
        catalog.map { it to similarity(name, it.name) }.filter { it.second >= threshold }.maxByOrNull { it.second }?.first
}
