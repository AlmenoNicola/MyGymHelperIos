package app.mygymhelper.core

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

// ---------- Consigli sugli esercizi (Mid e Full) ----------

data class HistoryEntry(val dateMillis: Long, val exerciseId: String, val primary: List<MuscleGroup>, val setsDone: Int)

data class Recommendation(val exercise: CatalogExercise, val score: Double, val reasonKey: String)

/** Privilegia i muscoli scelti con meno serie negli ultimi 7 giorni, i multiarticolari e quelli non fatti da poco. */
object ExerciseRecommender {
    fun recommend(catalog: List<CatalogExercise>, targets: Set<MuscleGroup>, history: List<HistoryEntry>,
                  nowMillis: Long = System.currentTimeMillis(), limit: Int = 5): List<Recommendation> {
        val weekAgo = nowMillis - 7L * 86_400_000
        val weeklySets = HashMap<MuscleGroup, Int>()
        val lastDone = HashMap<String, Long>()
        for (h in history) {
            lastDone[h.exerciseId] = max(lastDone[h.exerciseId] ?: Long.MIN_VALUE, h.dateMillis)
            if (h.dateMillis < weekAgo) continue
            for (m in h.primary) weeklySets[m] = (weeklySets[m] ?: 0) + h.setsDone
        }
        val candidates = if (targets.isEmpty()) catalog else catalog.filter { ex -> ex.primary.any { it in targets } }
        val scored = candidates.map { ex ->
            val needs = ex.primary.map { 1.0 / (1.0 + (weeklySets[it] ?: 0) / 6.0) }
            val need = needs.sum() / max(needs.size, 1)
            var score = need
            if (ex.isCompound) score += 0.25
            var reason = if (need > 0.7) "rec.undertrained" else if (ex.isCompound) "rec.compound" else "rec.variety"
            val last = lastDone[ex.id]
            if (last != null) {
                if (nowMillis - last < 48L * 3_600_000) { score -= 0.5; reason = "rec.recent" }
            } else {
                score += 0.15
            }
            Recommendation(ex, score, reason)
        }
        return scored.sortedWith(compareByDescending<Recommendation> { it.score }.thenBy { it.exercise.id }).take(limit)
    }
}

// ---------- Motore adattivo (Full) ----------

/** Obiettivi di una scheda per un esercizio. */
data class PlanTarget(val sets: Int? = null, val repsMin: Int? = null, val repsMax: Int? = null,
                      val restSeconds: Int? = null, val weightKg: Double? = null)

data class SessionSetSample(val doneReps: Int, val plannedReps: Int, val stoppedEarly: Boolean, val averagePeak: Double = 0.0)
data class SessionSample(val dateMillis: Long, val weightKg: Double, val sets: List<SessionSetSample>)

data class AdaptiveAdvice(val weightKg: Double, val sets: Int, val reps: Int, val restSeconds: Int, val reasonKeys: List<String>) {
    /** Parametri proposti. Se il consiglio non ha un peso (nessun dato) si tiene quello attuale. */
    fun parameters(keepingWeight: Double) =
        WorkoutParameters(sets, reps, restSeconds, if (weightKg > 0) weightKg else keepingWeight).clamped()
}

object AdaptiveCoach {
    internal fun completionRate(s: SessionSample): Double {
        val planned = s.sets.sumOf { it.plannedReps }
        if (planned <= 0) return 0.0
        return s.sets.sumOf { min(it.doneReps, it.plannedReps) }.toDouble() / planned
    }

    /** Calo di velocità tra prima e ultima serie (0..1), 0 se non misurabile. */
    internal fun velocityDrop(s: SessionSample): Double {
        if (s.sets.size < 2) return 0.0
        val first = s.sets.first().averagePeak; val last = s.sets.last().averagePeak
        if (first <= 0 || last <= 0) return 0.0
        return max(0.0, 1 - last / first)
    }

    private fun clamp(v: Int, lo: Int, hi: Int) = min(max(v, lo), hi)

    fun advise(history: List<SessionSample>, isCompound: Boolean, defaultSets: Int, defaultReps: Int,
               plan: PlanTarget? = null, weightStep: Double = 1.25): AdaptiveAdvice {
        val baseRest = plan?.restSeconds ?: if (isCompound) 120 else 75
        val last = history.lastOrNull()
        if (last == null || last.sets.isEmpty()) {
            return AdaptiveAdvice(plan?.weightKg ?: 0.0, clamp(plan?.sets ?: defaultSets, 1, 8),
                clamp(plan?.repsMin ?: defaultReps, 1, 50), clamp(baseRest, 30, 300), listOf("coach.nodata"))
        }
        val completion = completionRate(last)
        val stopped = last.sets.count { it.stoppedEarly }
        val fatigue = velocityDrop(last)
        val previous = if (history.size >= 2) history[history.size - 2] else null
        val poorStreak = (previous?.let { completionRate(it) < 0.8 } ?: false) && completion < 0.8

        var weight = last.weightKg
        var sets = plan?.sets ?: last.sets.size
        var reps = last.sets.firstOrNull()?.plannedReps ?: defaultReps
        var rest = baseRest
        val reasons = ArrayList<String>()

        fun increment(w: Double) = max(weightStep, ((w * 0.025) / weightStep).swiftRound() * weightStep)
        fun lowered(w: Double, factor: Double) = max(0.0, floor((w * factor) / weightStep) * weightStep)

        if (poorStreak) {
            weight = lowered(weight, 0.9); rest += 30; reasons.add("coach.deload")
        } else if (completion >= 1.0 && stopped == 0) {
            if (fatigue < 0.2) {
                val ceiling = plan?.repsMax
                if (weight == 0.0 || (ceiling != null && reps < ceiling)) {
                    reps = min(reps + 1, ceiling ?: 50); reasons.add("coach.morereps")
                } else {
                    weight += increment(weight)
                    plan?.repsMin?.let { reps = it }
                    reasons.add("coach.progress")
                }
                if (plan?.sets == null && sets < 5 && last.sets.size >= 3 && (previous?.let { completionRate(it) >= 1 } ?: false)) {
                    sets += 1; reasons.add("coach.addset")
                }
            } else if (fatigue < 0.35) {
                rest += 15; reasons.add("coach.keepfatigue")
            } else {
                rest += 30; reasons.add("coach.highfatigue")
            }
        } else if (completion >= 0.85) {
            rest += 15; reasons.add("coach.keep")
        } else if (completion >= 0.7) {
            rest += 30; reasons.add("coach.keep")
        } else {
            weight = lowered(weight, 0.92)
            if (plan?.sets == null && sets > 2) sets -= 1
            rest += 30; reasons.add("coach.reduce")
        }
        return AdaptiveAdvice(weight, clamp(sets, 1, 8), clamp(reps, 1, 50), clamp(rest, 30, 300), reasons)
    }
}
