package app.mygymhelper.core

import java.net.URLEncoder

// ---------- Piano alimentare generale (nessuna ricetta) ----------

enum class FoodCategory { PROTEIN, CARBS, FATS, PRODUCE }
internal enum class FoodTag { MEAT, FISH, EGGS, DAIRY, LACTOSE, GLUTEN }
internal data class Food(val key: String, val category: FoodCategory, val tags: Set<FoodTag>)

data class MealPlan(val nameKey: String, val calories: Int, val proteinG: Int, val carbsG: Int, val fatG: Int,
                    /** Chiavi di traduzione di alimenti adatti alla dieta (solo indicazioni). */
                    val suggestions: List<String>)

data class DayNutrition(val calories: Int, val proteinG: Int, val carbsG: Int, val fatG: Int, val meals: List<MealPlan>)

/** Non sostituisce un nutrizionista: non considera allergie, intolleranze cliniche o patologie. */
object DietPlanner {
    internal val foods = listOf(
        Food("food.chicken", FoodCategory.PROTEIN, setOf(FoodTag.MEAT)),
        Food("food.turkey", FoodCategory.PROTEIN, setOf(FoodTag.MEAT)),
        Food("food.leanBeef", FoodCategory.PROTEIN, setOf(FoodTag.MEAT)),
        Food("food.whiteFish", FoodCategory.PROTEIN, setOf(FoodTag.FISH)),
        Food("food.tuna", FoodCategory.PROTEIN, setOf(FoodTag.FISH)),
        Food("food.eggs", FoodCategory.PROTEIN, setOf(FoodTag.EGGS)),
        Food("food.greekYogurt", FoodCategory.PROTEIN, setOf(FoodTag.DAIRY, FoodTag.LACTOSE)),
        Food("food.cottageCheese", FoodCategory.PROTEIN, setOf(FoodTag.DAIRY, FoodTag.LACTOSE)),
        Food("food.lactoseFreeYogurt", FoodCategory.PROTEIN, setOf(FoodTag.DAIRY)),
        Food("food.legumes", FoodCategory.PROTEIN, emptySet()),
        Food("food.tofu", FoodCategory.PROTEIN, emptySet()),
        Food("food.tempeh", FoodCategory.PROTEIN, emptySet()),
        Food("food.seitan", FoodCategory.PROTEIN, setOf(FoodTag.GLUTEN)),
        Food("food.rice", FoodCategory.CARBS, emptySet()),
        Food("food.potatoes", FoodCategory.CARBS, emptySet()),
        Food("food.quinoa", FoodCategory.CARBS, emptySet()),
        Food("food.polenta", FoodCategory.CARBS, emptySet()),
        Food("food.oats", FoodCategory.CARBS, setOf(FoodTag.GLUTEN)),
        Food("food.pasta", FoodCategory.CARBS, setOf(FoodTag.GLUTEN)),
        Food("food.bread", FoodCategory.CARBS, setOf(FoodTag.GLUTEN)),
        Food("food.oliveOil", FoodCategory.FATS, emptySet()),
        Food("food.nuts", FoodCategory.FATS, emptySet()),
        Food("food.avocado", FoodCategory.FATS, emptySet()),
        Food("food.seeds", FoodCategory.FATS, emptySet()),
        Food("food.butter", FoodCategory.FATS, setOf(FoodTag.DAIRY, FoodTag.LACTOSE)),
        Food("food.cheese", FoodCategory.FATS, setOf(FoodTag.DAIRY, FoodTag.LACTOSE)),
        Food("food.vegetables", FoodCategory.PRODUCE, emptySet()),
        Food("food.fruit", FoodCategory.PRODUCE, emptySet())
    )

    internal fun excluded(diets: Set<DietType>): Set<FoodTag> {
        val out = HashSet<FoodTag>()
        if (DietType.VEGETARIAN in diets) out += setOf(FoodTag.MEAT, FoodTag.FISH)
        if (DietType.VEGAN in diets) out += setOf(FoodTag.MEAT, FoodTag.FISH, FoodTag.EGGS, FoodTag.DAIRY, FoodTag.LACTOSE)
        if (DietType.GLUTEN_FREE in diets) out += FoodTag.GLUTEN
        if (DietType.LACTOSE_FREE in diets) out += FoodTag.LACTOSE
        return out
    }

    fun allowedFoods(diets: Set<DietType>, category: FoodCategory): List<String> {
        val ex = excluded(diets)
        return foods.filter { it.category == category && it.tags.none { t -> t in ex } }.map { it.key }
    }

    fun plan(targets: DailyTargets, diets: Set<DietType>, trainingDay: Boolean): DayNutrition {
        var calories = targets.calories.toDouble()
        var carbs = targets.carbsGrams.toDouble()
        val protein = targets.proteinGrams.toDouble()
        val fat = targets.fatGrams.toDouble()
        if (trainingDay) { val extra = calories * 0.08; calories += extra; carbs += extra / 4 }
        val shares = listOf("meal.breakfast" to 0.25, "meal.snack1" to 0.10, "meal.lunch" to 0.30,
            "meal.snack2" to 0.10, "meal.dinner" to 0.25)
        val lists = FoodCategory.entries.map { allowedFoods(diets, it) }
        val meals = shares.mapIndexed { i, (key, share) ->
            MealPlan(key, (calories * share).roundToIntSwift(), (protein * share).roundToIntSwift(),
                (carbs * share).roundToIntSwift(), (fat * share).roundToIntSwift(),
                lists.mapNotNull { l -> if (l.isEmpty()) null else l[i % l.size] })
        }
        return DayNutrition(calories.roundToIntSwift(), protein.roundToIntSwift(), carbs.roundToIntSwift(),
            fat.roundToIntSwift(), meals)
    }
}

// ---------- Open Food Facts ----------

/** Valori per 100 g di un prodotto Open Food Facts (dati ODbL: serve l'attribuzione). */
data class FoodProduct(val id: String, val name: String, val brand: String? = null, val kcal100g: Double? = null,
                       val protein100g: Double? = null, val carbs100g: Double? = null, val fat100g: Double? = null)

object FoodFacts {
    const val BASE_URL = "https://world.openfoodfacts.org"

    /** URL di ricerca; null se il testo è troppo corto. La richiesta va fatta con uno User-Agent identificativo. */
    fun searchUrl(query: String, language: String, pageSize: Int = 20): String? {
        val q = query.trim()
        if (q.length < 2) return null
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
        val size = pageSize.coerceIn(1, 50)
        return "$BASE_URL/cgi/search.pl?search_terms=${enc(q)}&search_simple=1&action=process&json=1" +
            "&page_size=$size&lc=${enc(language)}&fields=code,product_name,generic_name,brands,nutriments"
    }

    /** Decodifica tollerante: numeri come stringhe ("3,8"), codici numerici, kJ al posto di kcal, valori assurdi scartati. */
    fun decodeSearch(json: String): List<FoodProduct> {
        val root = MiniJson.parse(json).obj() ?: return emptyList()
        return (root["products"].arr() ?: emptyList()).mapNotNull { pv ->
            val p = pv.obj() ?: return@mapNotNull null
            val code = when (val c = p["code"]) { is String -> c; is Number -> c.toLong().toString(); else -> null }
            if (code.isNullOrEmpty()) return@mapNotNull null
            val productName = p["product_name"].str()
            val raw = if (!productName.isNullOrEmpty()) productName else p["generic_name"].str() ?: ""
            val name = raw.trim()
            if (name.isEmpty()) return@mapNotNull null
            val n = p["nutriments"].obj()
            val kcal = n?.get("energy-kcal_100g").num() ?: n?.get("energy_100g").num()?.let { it / 4.184 }
            val brand = p["brands"].str()?.split(",")?.firstOrNull()?.trim()?.takeIf { it.isNotEmpty() }
            fun plausible(v: Double?, max: Double) = v?.takeIf { it in 0.0..max }
            FoodProduct(code, name, brand, plausible(kcal, 900.0), plausible(n?.get("proteins_100g").num(), 100.0),
                plausible(n?.get("carbohydrates_100g").num(), 100.0), plausible(n?.get("fat_100g").num(), 100.0))
        }
    }
}
