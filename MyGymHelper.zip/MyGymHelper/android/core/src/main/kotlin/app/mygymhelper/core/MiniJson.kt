package app.mygymhelper.core

/**
 * JSON minimale senza dipendenze (il modulo core resta Kotlin puro, provabile anche fuori da Android).
 * Valori: null, Boolean, Double/Long, String, List<Any?>, Map<String, Any?>.
 */
object MiniJson {
    class ParseException(message: String) : Exception(message)

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.skipWs()
        val v = p.value()
        p.skipWs()
        if (!p.atEnd()) throw ParseException("Testo in eccesso alla posizione ${p.i}")
        return v
    }

    fun stringify(value: Any?): String = StringBuilder().also { write(it, value) }.toString()

    private fun write(sb: StringBuilder, v: Any?) {
        when (v) {
            null -> sb.append("null")
            is Boolean -> sb.append(v)
            is Int, is Long -> sb.append(v)
            is Float, is Double -> {
                val d = (v as Number).toDouble()
                if (d.isNaN() || d.isInfinite()) sb.append("null")
                else if (d == kotlin.math.floor(d) && kotlin.math.abs(d) < 1e15) sb.append(d.toLong()) else sb.append(d)
            }
            is String -> quote(sb, v)
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                for ((k, value) in v) {
                    if (!first) sb.append(',')
                    first = false
                    quote(sb, k.toString()); sb.append(':'); write(sb, value)
                }
                sb.append('}')
            }
            is Iterable<*> -> {
                sb.append('[')
                var first = true
                for (item in v) { if (!first) sb.append(','); first = false; write(sb, item) }
                sb.append(']')
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append('"')
    }

    private class Parser(val s: String) {
        var i = 0
        fun atEnd() = i >= s.length
        fun skipWs() { while (i < s.length && s[i].isWhitespace()) i++ }

        fun value(): Any? {
            skipWs()
            if (atEnd()) throw ParseException("Fine inattesa")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw ParseException("Carattere inatteso '$c' alla posizione $i")
            }
        }

        fun lit(word: String, v: Any?): Any? {
            if (!s.startsWith(word, i)) throw ParseException("Atteso $word alla posizione $i")
            i += word.length
            return v
        }

        fun num(): Any {
            val start = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] in ".eE+-")) i++
            val t = s.substring(start, i)
            return if (t.any { it in ".eE" }) t.toDoubleOrNull() ?: throw ParseException("Numero non valido $t")
            else t.toLongOrNull() ?: t.toDoubleOrNull() ?: throw ParseException("Numero non valido $t")
        }

        fun str(): String {
            i++ // "
            val sb = StringBuilder()
            while (true) {
                if (atEnd()) throw ParseException("Stringa non chiusa")
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (atEnd()) throw ParseException("Escape incompleto")
                        when (val e = s[i++]) {
                            '"' -> sb.append('"'); '\\' -> sb.append('\\'); '/' -> sb.append('/')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000C'); 'n' -> sb.append('\n')
                            'r' -> sb.append('\r'); 't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) throw ParseException("Escape unicode incompleto")
                                sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4
                            }
                            else -> throw ParseException("Escape non valido \\$e")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        fun arr(): List<Any?> {
            i++
            val out = ArrayList<Any?>()
            skipWs()
            if (!atEnd() && s[i] == ']') { i++; return out }
            while (true) {
                out.add(value()); skipWs()
                if (atEnd()) throw ParseException("Array non chiuso")
                when (s[i++]) { ',' -> continue; ']' -> return out; else -> throw ParseException("Atteso , o ]") }
            }
        }

        fun obj(): Map<String, Any?> {
            i++
            val out = LinkedHashMap<String, Any?>()
            skipWs()
            if (!atEnd() && s[i] == '}') { i++; return out }
            while (true) {
                skipWs()
                if (atEnd() || s[i] != '"') throw ParseException("Attesa chiave alla posizione $i")
                val k = str(); skipWs()
                if (atEnd() || s[i++] != ':') throw ParseException("Atteso :")
                out[k] = value(); skipWs()
                if (atEnd()) throw ParseException("Oggetto non chiuso")
                when (s[i++]) { ',' -> continue; '}' -> return out; else -> throw ParseException("Atteso , o }") }
            }
        }
    }
}

// Accesso comodo e tollerante ai valori letti.
@Suppress("UNCHECKED_CAST")
internal fun Any?.obj(): Map<String, Any?>? = this as? Map<String, Any?>
internal fun Any?.arr(): List<Any?>? = this as? List<Any?>
internal fun Any?.str(): String? = this as? String
internal fun Any?.num(): Double? = when (this) {
    is Number -> toDouble()
    is String -> trim().replace(',', '.').toDoubleOrNull()
    else -> null
}
internal fun Any?.int(): Int? = (this as? Number)?.let { if (it.toDouble() == kotlin.math.floor(it.toDouble())) it.toInt() else null }
internal fun Any?.bool(): Boolean? = this as? Boolean
internal fun Any?.strings(): List<String> = arr()?.mapNotNull { it.str() } ?: emptyList()
