package app.mygymhelper.core

import java.util.UUID

data class PlanEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val sets: Int? = null,
    val repsMin: Int? = null,
    val repsMax: Int? = null,
    val restSeconds: Int? = null,
    val weightKg: Double? = null
) {
    val target: PlanTarget get() = PlanTarget(sets, repsMin, repsMax, restSeconds, weightKg)
}

data class PlanDay(val id: String = UUID.randomUUID().toString(), val title: String, val entries: List<PlanEntry>)

data class TrainingPlan(val days: List<PlanDay>) {
    val allEntries: List<PlanEntry> get() = days.flatMap { it.entries }
}

// Stesse opzioni dell'app iOS (ICU): senza distinzione maiuscole e con classi Unicode,
// così \b, \w e \d funzionano anche con lettere accentate ("Venerdì").
private val regexCache = HashMap<String, Regex>()
private fun rx(pattern: String): Regex = synchronized(regexCache) {
    regexCache.getOrPut(pattern) {
        java.util.regex.Pattern.compile(pattern, java.util.regex.Pattern.UNICODE_CHARACTER_CLASS or
            java.util.regex.Pattern.CASE_INSENSITIVE or java.util.regex.Pattern.UNICODE_CASE).toRegex()
    }
}

private fun firstMatch(pattern: String, text: String): List<String?>? {
    val m = rx(pattern).find(text) ?: return null
    return m.groups.map { it?.value }
}

private fun removing(pattern: String, text: String) = rx(pattern).replace(text, " ")

/** Estrattore di schede di allenamento da testo (PDF o foto). Euristico: l'utente controlla sempre il risultato. */
object TrainingPlanParser {
    internal const val SETS_REPS_X = """(\d{1,2})\s*[x×*]\s*(\d{1,3})(?:\s*[-–]\s*(\d{1,3}))?"""
    internal const val SETS_REPS_WORDS = """(\d{1,2})\s*(?:serie|series|sets?)\s*(?:da|di|x|of|per)?\s*(\d{1,3})(?:\s*[-–]\s*(\d{1,3}))?"""
    internal const val WEIGHT = """(\d{1,3}(?:[.,]\d{1,2})?)\s*(?:kg|kili|chili)"""
    internal const val REST = """(?:rec(?:upero)?|rest|pausa|riposo)\.?\s*:?\s*(\d{1,3})\s*(min|m|''|"|sec|s|')?"""
    internal const val DAY_HEADING = """^(?:giorno|day|allenamento|workout|sessione|seduta|scheda|settimana|week)\b.{0,30}$"""
    internal const val WEEKDAY = """^(?:luned[iì]|marted[iì]|mercoled[iì]|gioved[iì]|venerd[iì]|sabato|domenica|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b.{0,20}$"""

    internal fun stripBullet(line: String) = line.replace(Regex("""^\s*(?:[-•*·]|\d{1,2}[.)])\s+"""), "")

    internal fun restSeconds(value: Int, unit: String?): Int = when (unit?.lowercase()) {
        "min", "m", "'" -> value * 60
        // Un recupero di pochi secondi non è realistico: "rec 3\"" si intende come 3 minuti (come su iOS).
        "''", "\"", "sec", "s" -> if (value < 10) value * 60 else value
        else -> if (value <= 10) value * 60 else value
    }

    private const val TRIM = " :-–—,.;()/\t"

    internal fun parseEntry(line: String): PlanEntry? {
        var used = SETS_REPS_X
        var sr = firstMatch(SETS_REPS_X, line)
        if (sr == null) { used = SETS_REPS_WORDS; sr = firstMatch(SETS_REPS_WORDS, line) }
        val g = sr ?: return null
        val sets = g[1]?.toIntOrNull() ?: return null
        val repsA = g[2]?.toIntOrNull() ?: return null
        val repsB = g.getOrNull(3)?.toIntOrNull()
        val lo = minOf(repsA, repsB ?: repsA); val hi = maxOf(repsA, repsB ?: repsA)
        if (sets !in 1..12 || lo !in 1..100) return null

        val weightKg = firstMatch(WEIGHT, line)?.get(1)?.replace(',', '.')?.toDoubleOrNull()
        val restSec = firstMatch(REST, line)?.let { r -> r[1]?.toIntOrNull()?.let { restSeconds(it, r.getOrNull(2)) } }

        var name = line
        for (p in listOf(used, WEIGHT, REST)) name = removing(p, name)
        name = name.trim { it in TRIM }
        name = name.split(Regex("\\s+")).filter { it.isNotEmpty() }.joinToString(" ")
        if (name.count { it.isLetter() } < 3) return null
        return PlanEntry(name = name, sets = sets, repsMin = lo, repsMax = hi, restSeconds = restSec, weightKg = weightKg)
    }

    internal fun dayTitle(line: String): String? {
        val clean = line.trim { it in " :-–—" }
        return if (firstMatch(DAY_HEADING, clean) != null || firstMatch(WEEKDAY, clean) != null) clean else null
    }

    fun parse(text: String): TrainingPlan {
        val days = ArrayList<PlanDay>()
        var currentTitle = ""
        var current = ArrayList<PlanEntry>()
        fun flush() { if (current.isNotEmpty()) days.add(PlanDay(title = currentTitle, entries = current)) }
        for (raw in text.lines()) {
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) continue
            val line = stripBullet(trimmed)
            val entry = parseEntry(line)
            if (entry != null) { current.add(entry); continue }
            val title = dayTitle(line)
            if (title != null) { flush(); currentTitle = title; current = ArrayList() }
        }
        flush()
        return TrainingPlan(days)
    }
}

// ---------- Scheda del nutrizionista ----------

data class ParsedMeal(val id: String = UUID.randomUUID().toString(), val name: String, val items: List<String>)

data class ParsedNutritionPlan(val calories: Int? = null, val proteinG: Int? = null, val carbsG: Int? = null,
                               val fatG: Int? = null, val meals: List<ParsedMeal> = emptyList())

object NutritionPlanParser {
    private const val MEAL_WORDS = "colazione|spuntino|pranzo|merenda|cena|breakfast|lunch|dinner|snack"

    private fun number(patterns: List<String>, text: String, range: IntRange): Int? {
        for (p in patterns) {
            val v = firstMatch(p, text)?.get(1)?.toIntOrNull()
            if (v != null && v in range) return v
        }
        return null
    }

    /** Come `String.capitalized` di Swift: iniziale maiuscola per ogni parola, resto minuscolo. */
    private fun capitalized(s: String) = s.split(" ").joinToString(" ") { w ->
        w.lowercase().replaceFirstChar { it.titlecase() }
    }

    fun parse(text: String): ParsedNutritionPlan {
        val calories = number(listOf("""(\d{3,4})\s*(?:kcal|cal\b)""", """calorie\D{0,12}(\d{3,4})"""), text, 800..6000)
        val protein = number(listOf("""(?:proteine|protein)\D{0,12}(\d{2,3})\s*g""", """(\d{2,3})\s*g\s*(?:di\s*)?(?:proteine|protein)"""), text, 20..400)
        val carbs = number(listOf("""(?:carboidrati|carbs?|carbohydrates)\D{0,12}(\d{2,3})\s*g""", """(\d{2,3})\s*g\s*(?:di\s*)?(?:carboidrati|carbs?|carbohydrates)"""), text, 20..800)
        val fat = number(listOf("""(?:grassi|lipidi|fats?)\D{0,12}(\d{2,3})\s*g""", """(\d{2,3})\s*g\s*(?:di\s*)?(?:grassi|lipidi|fats?)"""), text, 10..300)

        val meals = ArrayList<ParsedMeal>()
        var current: ParsedMeal? = null
        for (raw in text.lines()) {
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) continue
            val line = TrainingPlanParser.stripBullet(trimmed)
            val m = firstMatch("^($MEAL_WORDS)\\b\\s*[:\\-–]?\\s*(.*)$", line)
            val name = m?.get(1)
            if (m != null && name != null) {
                current?.let { meals.add(it) }
                val rest = m.getOrNull(2)?.trim().orEmpty()
                current = ParsedMeal(name = capitalized(name), items = if (rest.isEmpty()) emptyList() else listOf(rest))
            } else if (current != null) {
                current = current.copy(items = current.items + line)
            }
        }
        current?.let { meals.add(it) }
        return ParsedNutritionPlan(calories, protein, carbs, fat, meals)
    }
}

// ---------- Risposta di un eventuale modello AI locale ----------

object PlanAIOutput {
    const val TRAINING_PROMPT = "Estrai la scheda di allenamento dal testo. Rispondi SOLO con JSON valido nel formato " +
        "{\"days\":[{\"title\":\"\",\"entries\":[{\"name\":\"\",\"sets\":0,\"repsMin\":0,\"repsMax\":0,\"restSeconds\":0,\"weightKg\":0}]}]}. " +
        "Non inventare dati: se un valore manca, omettilo."

    /** Estrae il primo oggetto JSON dall'output del modello e lo trasforma in una scheda validata. */
    fun decodeTrainingPlan(output: String): TrainingPlan? {
        val start = output.indexOf('{'); val end = output.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        val json = try { MiniJson.parse(output.substring(start, end + 1)).obj() } catch (e: Exception) { null } ?: return null
        fun ok(v: Int?, r: IntRange) = v?.takeIf { it in r }
        val days = (json["days"].arr() ?: emptyList()).mapNotNull { dv ->
            val d = dv.obj() ?: return@mapNotNull null
            val entries = (d["entries"].arr() ?: emptyList()).mapNotNull { ev ->
                val e = ev.obj() ?: return@mapNotNull null
                val name = e["name"].str()?.trim() ?: return@mapNotNull null
                if (name.count { it.isLetter() } < 3) return@mapNotNull null
                val w = e["weightKg"].num()?.takeIf { it in 0.0..500.0 }
                PlanEntry(name = name, sets = ok(e["sets"].int(), 1..12), repsMin = ok(e["repsMin"].int(), 1..100),
                    repsMax = ok(e["repsMax"].int(), 1..100), restSeconds = ok(e["restSeconds"].int(), 10..600), weightKg = w)
            }
            if (entries.isEmpty()) null else PlanDay(title = d["title"].str() ?: "", entries = entries)
        }
        return if (days.isEmpty()) null else TrainingPlan(days)
    }
}
