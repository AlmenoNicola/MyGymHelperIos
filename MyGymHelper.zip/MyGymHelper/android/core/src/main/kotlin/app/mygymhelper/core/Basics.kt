package app.mygymhelper.core

import kotlin.math.round

// Port Kotlin del pacchetto Swift MyGymHelperCore: stesse regole, stesse costanti, stessi test.

/** Livelli di abbonamento. Free è gratuito; Mid e Full sono a pagamento. */
enum class SubscriptionTier { FREE, MID, FULL }

/** Funzioni dell'app soggette al livello di abbonamento. */
enum class Feature {
    REP_COUNTING, BMI, CATALOG_ONE_PER_TYPE, CATALOG_FULL, SAVED_EXERCISE_LISTS, MUSCLE_SELECTION,
    FIXED_COACHING, GENERAL_NUTRITION_ADVICE, WEARABLE, ADAPTIVE_COACHING, UPLOAD_PLANS, DIET_PLANS,
    OFFLINE_FULL, CLOUD_SYNC
}

object FeatureGate {
    fun minimumTier(feature: Feature): SubscriptionTier = when (feature) {
        Feature.REP_COUNTING, Feature.BMI, Feature.CATALOG_ONE_PER_TYPE -> SubscriptionTier.FREE
        Feature.CATALOG_FULL, Feature.SAVED_EXERCISE_LISTS, Feature.MUSCLE_SELECTION,
        Feature.FIXED_COACHING, Feature.GENERAL_NUTRITION_ADVICE, Feature.WEARABLE -> SubscriptionTier.MID
        Feature.ADAPTIVE_COACHING, Feature.UPLOAD_PLANS, Feature.DIET_PLANS,
        Feature.OFFLINE_FULL, Feature.CLOUD_SYNC -> SubscriptionTier.FULL
    }

    fun isAvailable(feature: Feature, tier: SubscriptionTier): Boolean = tier >= minimumTier(feature)
}

// ---------- BMI ----------

enum class BmiCategory { UNDERWEIGHT, NORMAL, OVERWEIGHT, OBESE }

data class BmiResult(val value: Double, val category: BmiCategory)

object BmiCalculator {
    /** BMI = peso (kg) / altezza (m)^2. Valido per adulti; non sostituisce il parere di un medico. */
    fun calculate(weightKg: Double, heightCm: Double): BmiResult? {
        if (weightKg <= 0 || heightCm <= 0) return null
        val m = heightCm / 100
        val bmi = weightKg / (m * m)
        val category = when {
            bmi < 18.5 -> BmiCategory.UNDERWEIGHT
            bmi < 25 -> BmiCategory.NORMAL
            bmi < 30 -> BmiCategory.OVERWEIGHT
            else -> BmiCategory.OBESE
        }
        return BmiResult(bmi, category)
    }
}

// ---------- Nutrizione ----------

enum class BiologicalSex(val raw: String) { MALE("male"), FEMALE("female");
    companion object { fun from(raw: String) = entries.firstOrNull { it.raw == raw } ?: MALE }
}

enum class ActivityLevel(val factor: Double) {
    SEDENTARY(1.2), LIGHT(1.375), MODERATE(1.55), HIGH(1.725), VERY_HIGH(1.9);
    companion object { fun from(factor: Double) = entries.minByOrNull { kotlin.math.abs(it.factor - factor) } ?: LIGHT }
}

enum class Goal(val raw: String) { LOSE("lose"), MAINTAIN("maintain"), GAIN("gain");
    companion object { fun from(raw: String) = entries.firstOrNull { it.raw == raw } ?: MAINTAIN }
}

enum class DietType(val raw: String) {
    OMNIVORE("omnivore"), VEGETARIAN("vegetarian"), GLUTEN_FREE("glutenFree"), VEGAN("vegan"), LACTOSE_FREE("lactoseFree");
    companion object { fun from(raw: String) = entries.firstOrNull { it.raw == raw } }
}

data class DailyTargets(val calories: Int, val proteinGrams: Int, val carbsGrams: Int, val fatGrams: Int)

/** Arrotondamento "da Swift": .5 si allontana dallo zero (Double.rounded()). */
internal fun Double.swiftRound(): Double = if (this >= 0) kotlin.math.floor(this + 0.5) else -kotlin.math.floor(-this + 0.5)
internal fun Double.roundToIntSwift(): Int = swiftRound().toInt()

/** Calcoli generali di fabbisogno. Coefficienti indicativi: da far rivedere a un professionista. */
object NutritionCalculator {
    /** Metabolismo basale, formula di Mifflin-St Jeor. */
    fun bmr(sex: BiologicalSex, weightKg: Double, heightCm: Double, ageYears: Int): Double {
        val base = 10 * weightKg + 6.25 * heightCm - 5 * ageYears
        return if (sex == BiologicalSex.MALE) base + 5 else base - 161
    }

    fun targets(sex: BiologicalSex, weightKg: Double, heightCm: Double, ageYears: Int,
                activity: ActivityLevel, goal: Goal): DailyTargets {
        val tdee = bmr(sex, weightKg, heightCm, ageYears) * activity.factor
        val adjusted = when (goal) { Goal.LOSE -> tdee * 0.85; Goal.MAINTAIN -> tdee; Goal.GAIN -> tdee * 1.10 }
        val proteinPerKg = if (goal == Goal.MAINTAIN) 1.6 else 1.8
        val protein = proteinPerKg * weightKg
        val fat = 0.9 * weightKg
        val carbsKcal = maxOf(0.0, adjusted - protein * 4 - fat * 9)
        return DailyTargets(adjusted.roundToIntSwift(), protein.roundToIntSwift(),
            (carbsKcal / 4).roundToIntSwift(), fat.roundToIntSwift())
    }
}

/** Chiavi del disclaimer (testo nelle risorse) e chiave di accettazione. */
object Disclaimer {
    const val TITLE_KEY = "disclaimer.title"
    const val BODY_KEY = "disclaimer.body"
    const val ACCEPTED_KEY = "disclaimer.accepted.v1"
}

internal fun round2(v: Double) = round(v * 100) / 100
