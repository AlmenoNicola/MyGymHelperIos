import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

// Chiavi del progetto Supabase e client ID Google: in android/local.properties (non va nel repository).
//   supabase.url=https://<ref>.supabase.co
//   supabase.anonKey=eyJ...
//   google.webClientId=1234-abc.apps.googleusercontent.com
//   privacy.url=https://tuosito.it/privacy
//   terms.url=https://tuosito.it/condizioni   (facoltativo: senza, si usano le condizioni di Google Play)
//   contact.email=supporto@tuosito.it
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun prop(name: String, default: String = "") = (localProps.getProperty(name)?.trim()?.takeIf { it.isNotEmpty() } ?: default).replace("\"", "")

android {
    namespace = "app.mygymhelper"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.mygymhelper"
        minSdk = 28            // Android 9
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        buildConfigField("String", "SUPABASE_URL", "\"${prop("supabase.url")}\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"${prop("supabase.anonKey")}\"")
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", "\"${prop("google.webClientId")}\"")
        buildConfigField("String", "PRIVACY_URL", "\"${prop("privacy.url", "https://example.com/privacy")}\"")
        buildConfigField("String", "TERMS_URL", "\"${prop("terms.url", "https://play.google.com/about/play-terms/")}\"")
        buildConfigField("String", "CONTACT_EMAIL", "\"${prop("contact.email", "contact@example.com")}\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    // Le lingue dell'app: inglese (predefinita) e italiano.
    androidResources {
        localeFilters += listOf("en", "it")
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation(project(":core"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.process)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons)
    debugImplementation(libs.compose.ui.tooling)

    implementation(libs.coroutines.android)
    implementation(libs.coroutines.play)

    // Abbonamenti Google Play
    implementation(libs.billing)
    // Health Connect (equivalente di Apple Salute)
    implementation(libs.health.connect)
    // Riconoscimento del testo sul telefono (schede da foto e PDF)
    implementation(libs.mlkit.text)
    // Account facoltativo (Supabase) e accesso con Google
    implementation(platform(libs.supabase.bom))
    implementation(libs.supabase.auth)
    implementation(libs.supabase.functions)
    implementation(libs.ktor.client.okhttp)
    implementation(libs.credentials)
    implementation(libs.credentials.play)
    implementation(libs.googleid)
}
