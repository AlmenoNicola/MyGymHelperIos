package app.mygymhelper.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.mygymhelper.Graph
import app.mygymhelper.core.ExerciseMatcher
import app.mygymhelper.core.Feature
import app.mygymhelper.core.FeatureGate
import app.mygymhelper.core.NutritionPlanParser
import app.mygymhelper.core.ParsedNutritionPlan
import app.mygymhelper.core.PlanDay
import app.mygymhelper.core.PlanEntry
import app.mygymhelper.core.TrainingPlan
import app.mygymhelper.core.TrainingPlanParser
import app.mygymhelper.core.TrainingPlanRecord
import app.mygymhelper.services.TextExtractor
import app.mygymhelper.ui.AppBackground
import app.mygymhelper.ui.GlassButton
import app.mygymhelper.ui.GlassCard
import app.mygymhelper.ui.LockedNote
import app.mygymhelper.ui.Navigator
import app.mygymhelper.ui.Palette
import app.mygymhelper.ui.PrimaryButton
import app.mygymhelper.ui.Screen
import app.mygymhelper.ui.ScreenHeader
import app.mygymhelper.ui.ScrollScreen
import app.mygymhelper.ui.SecondaryText
import app.mygymhelper.ui.kgText
import app.mygymhelper.ui.tr
import app.mygymhelper.ui.trText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date

// ---------- Importazione (condivisa con la scheda del nutrizionista) ----------

enum class PlanKind { TRAINING, NUTRITION }

data class TrainingDraft(val name: String, val plan: TrainingPlan, val sourceText: String, val recordId: String? = null)
data class NutritionDraft(val plan: ParsedNutritionPlan, val sourceText: String)

/** Stato dell'importazione: legge il file o la foto, estrae il testo e prepara una bozza da rivedere. */
class PlanImportModel(private val scope: CoroutineScope) {
    var isWorking by mutableStateOf(false); private set
    var failed by mutableStateOf(false)
    var trainingDraft by mutableStateOf<TrainingDraft?>(null)
    var nutritionDraft by mutableStateOf<NutritionDraft?>(null)

    fun handle(context: Context, uri: Uri, kind: PlanKind, name: String) {
        isWorking = true
        scope.launch {
            try {
                val text = TextExtractor.fromUri(context, uri)
                when (kind) {
                    PlanKind.TRAINING -> {
                        var plan = TrainingPlanParser.parse(text)
                        if (plan.days.isEmpty()) plan = TrainingPlan(listOf(PlanDay(title = "", entries = emptyList())))
                        trainingDraft = TrainingDraft(name, plan, text)
                    }
                    PlanKind.NUTRITION -> nutritionDraft = NutritionDraft(NutritionPlanParser.parse(text), text)
                }
            } catch (e: Exception) {
                failed = true
            } finally {
                isWorking = false
            }
        }
    }

    /** Scheda vuota da compilare a mano. */
    fun blank(context: Context, kind: PlanKind) {
        when (kind) {
            PlanKind.TRAINING -> trainingDraft = TrainingDraft(trText(context, "plans.review.newName"),
                TrainingPlan(listOf(PlanDay(title = "", entries = listOf(PlanEntry(name = ""))))), "")
            PlanKind.NUTRITION -> nutritionDraft = NutritionDraft(ParsedNutritionPlan(), "")
        }
    }
}

@Composable
fun rememberPlanImportModel(): PlanImportModel {
    val scope = rememberCoroutineScope()
    return remember { PlanImportModel(scope) }
}

private fun displayName(context: Context, uri: Uri): String {
    val name = runCatching {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()
    return name?.substringBeforeLast('.') ?: DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date())
}

/** Pulsanti per scegliere la fonte: file (PDF, immagine, testo), foto, inserimento manuale. Riga "AI locale" disattivata. */
@Composable
fun ImportButtons(model: PlanImportModel, kind: PlanKind) {
    val context = LocalContext.current
    val files = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) model.handle(context, uri, kind, displayName(context, uri))
    }
    val photos = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) model.handle(context, uri, kind, DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date()))
    }
    GlassCard {
        Text(tr("import.title"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(tr("import.file"), Modifier.weight(1f), icon = Icons.Filled.InsertDriveFile) {
                files.launch(arrayOf("application/pdf", "image/*", "text/plain"))
            }
            GlassButton(tr("import.photo"), Modifier.weight(1f), icon = Icons.Filled.Image) {
                photos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
        }
        GlassButton(tr("import.manual"), Modifier.fillMaxWidth(), icon = Icons.Filled.EditNote) { model.blank(context, kind) }
        if (model.isWorking) Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(18.dp), color = Palette.accent, strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp)); Text(tr("import.reading"), fontSize = 13.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("import.ai"), fontSize = 15.sp, color = Palette.secondary)
                SecondaryText(tr("import.aiNote"), 12)
            }
            Switch(false, {}, enabled = false)
        }
        SecondaryText(tr("import.privacy"), 12)
    }
    if (model.failed) AlertDialog(
        onDismissRequest = { model.failed = false },
        title = { Text(tr("import.failed")) },
        text = { Text(tr("import.failedMessage")) },
        confirmButton = { TextButton({ model.failed = false }) { Text("OK") } }
    )
}

/** Riquadro per chi non ha ancora dato il consenso ai dati sulla salute. */
@Composable
fun NeedConsentCard(textKey: String) {
    var showConsent by remember { mutableStateOf(false) }
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Lock, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(tr(textKey), fontSize = 15.sp)
        }
        PrimaryButton(tr("consent.open")) { showConsent = true }
    }
    if (showConsent) FullScreenDialog({ showConsent = false }) { ConsentScreen(onFinish = {}, onClose = { showConsent = false }) }
}

/** Finestra a tutto schermo con lo sfondo dell'app (equivalente dei fogli modali iOS). */
@Composable
fun FullScreenDialog(onDismiss: () -> Unit, dismissible: Boolean = true, content: @Composable () -> Unit) {
    Dialog(onDismiss, DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = dismissible,
        dismissOnClickOutside = false, decorFitsSystemWindows = false)) {
        AppBackground(Modifier.fillMaxSize()) { content() }
    }
}

/** Intestazione con Annulla / Salva e contenuto scorrevole, per le schermate di revisione. */
@Composable
fun ReviewFrame(title: String, saveEnabled: Boolean, onCancel: () -> Unit, onSave: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onCancel) { Text(tr("info.cancel"), color = Palette.accentText) }
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f), maxLines = 1)
            TextButton(onSave, enabled = saveEnabled) { Text(tr("plans.review.save"), color = if (saveEnabled) Palette.accentText else Palette.secondary, fontWeight = FontWeight.Bold) }
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp), content = content)
    }
}

@Composable
fun CheckWarning() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Warning, null, tint = Color(0xFFFF9F0A), modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp)); Text(tr("plans.review.check"), fontSize = 13.sp, color = Color(0xFFFF9F0A))
    }
}

@Composable
fun SourceText(text: String) {
    if (text.isBlank()) return
    var open by remember { mutableStateOf(false) }
    GlassCard(onClick = { open = !open }) {
        Text(tr("plans.review.source"), fontWeight = FontWeight.SemiBold)
        if (open) Text(text, fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = Palette.secondary)
    }
}

// ---------- Elenco schede ----------

/** Schede di allenamento (piano Full, con consenso). La più recente è quella usata dai consigli adattivi. */
@Composable
fun TrainingPlansScreen(nav: Navigator) {
    val tier by Graph.billing.tier.collectAsState()
    val data by Graph.store.data.collectAsState()
    val importer = rememberPlanImportModel()
    val allowed = FeatureGate.isAvailable(Feature.UPLOAD_PLANS, tier)
    val plans = data.trainingPlans.sortedByDescending { it.createdAt }
    var toDelete by remember { mutableStateOf<String?>(null) }
    val dateFormat = remember { DateFormat.getDateInstance(DateFormat.MEDIUM) }

    ScrollScreen(nav, back = true) {
        ScreenHeader(Icons.Filled.Description, tr("plans.list.title"), tr("plans.list.subtitle"))
        when {
            !allowed -> GlassCard(padding = PaddingValues(16.dp)) { LockedNote(tr("plans.list.locked")) { nav.openPlans() } }
            !Graph.prefs.consentGranted -> NeedConsentCard("plans.list.needConsent")
            else -> {
                ImportButtons(importer, PlanKind.TRAINING)
                if (plans.isEmpty()) GlassCard(padding = PaddingValues(16.dp)) { SecondaryText(tr("plans.list.empty"), 15) }
                else SecondaryText(tr("plans.list.activeNote"))
                plans.forEach { record ->
                    GlassCard(padding = PaddingValues(16.dp), modifier = Modifier.longPressable(
                        onClick = { nav.push(Screen.TrainingPlanDetail(record.id)) }, onLongClick = { toDelete = record.id })) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(record.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                SecondaryText(dateFormat.format(Date(record.createdAt)), 12)
                            }
                            if (record.id == plans.first().id) Text(tr("plans.list.active"), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.background(Palette.accent.copy(alpha = 0.35f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp))
                            Icon(Icons.Filled.ChevronRight, null, tint = Palette.secondary)
                        }
                    }
                }
            }
        }
    }
    importer.trainingDraft?.let { draft -> TrainingPlanReview(draft) { importer.trainingDraft = null } }
    toDelete?.let { id -> DeleteDialog(onDismiss = { toDelete = null }) { Graph.store.deleteTrainingPlan(id); toDelete = null } }
}

@Composable
fun DeleteDialog(titleKey: String = "history.delete", onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr(titleKey)) },
        confirmButton = { TextButton(onConfirm) { Text(tr("history.delete"), color = Palette.danger) } },
        dismissButton = { TextButton(onDismiss) { Text(tr("info.cancel")) } }
    )
}

// ---------- Dettaglio ----------

/** "4 × 8–10 · 60 kg · 90 s" */
fun entrySummary(e: PlanEntry): String {
    val parts = mutableListOf<String>()
    if (e.sets != null) {
        val reps = e.repsMin?.let { lo -> e.repsMax?.takeIf { it != lo }?.let { "$lo–$it" } ?: "$lo" } ?: "?"
        parts += "${e.sets} × $reps"
    }
    e.weightKg?.takeIf { it > 0 }?.let { parts += kgText(it) }
    e.restSeconds?.let { parts += "$it s" }
    return parts.joinToString(" · ")
}

@Composable
fun TrainingPlanDetailScreen(nav: Navigator, id: String) {
    val data by Graph.store.data.collectAsState()
    val all by Graph.catalog.all.collectAsState()
    val record: TrainingPlanRecord? = data.trainingPlans.firstOrNull { it.id == id }
    var editing by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    ScrollScreen(nav, back = true, title = record?.name ?: "", actions = {
        if (record != null) TextButton({ editing = true }) { Text(tr("plans.detail.edit"), color = Palette.accentText) }
    }) {
        if (record == null) {
            GlassCard { SecondaryText(tr("plans.detail.unreadable"), 15) }
        } else {
            record.plan.days.forEach { day ->
                GlassCard {
                    Text(day.title.ifBlank { tr("plans.review.day") }, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    day.entries.forEach { entry ->
                        val match = remember(entry.name, all) { ExerciseMatcher.bestMatch(entry.name, all) }
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(entry.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                                if (match != null) IconButton({ nav.push(Screen.WorkoutSetupFor(match)) }) {
                                    Icon(Icons.Filled.PlayCircle, tr("ex.train"), tint = Palette.accent, modifier = Modifier.size(30.dp))
                                }
                            }
                            SecondaryText(entrySummary(entry), 12)
                            if (match != null && match.name != entry.name) Text(tr("plans.detail.matched", match.name), fontSize = 11.sp, color = Palette.accentSoft)
                        }
                    }
                }
            }
            GlassButton(tr("history.delete"), Modifier.fillMaxWidth(), color = Palette.danger, icon = Icons.Filled.Delete) { confirmDelete = true }
        }
    }
    if (editing && record != null) TrainingPlanReview(TrainingDraft(record.name, record.plan, "", record.id)) { editing = false }
    if (confirmDelete) DeleteDialog("plans.detail.deleteConfirm", { confirmDelete = false }) {
        confirmDelete = false
        nav.pop()                                   // prima si chiude la schermata, poi si elimina
        Graph.store.deleteTrainingPlan(id)
    }
}

// ---------- Revisione modificabile ----------

/** L'estrazione è euristica: prima di salvare l'utente controlla e corregge ogni riga. */
@Composable
fun TrainingPlanReview(initial: TrainingDraft, onClose: () -> Unit) {
    val context = LocalContext.current
    val all by Graph.catalog.all.collectAsState()
    var name by remember { mutableStateOf(initial.name) }
    var days by remember { mutableStateOf(initial.plan.days) }

    val cleaned = TrainingPlan(days.mapNotNull { d ->
        val entries = d.entries.filter { it.name.isNotBlank() }.map { it.copy(name = it.name.trim()) }
        if (entries.isEmpty()) null else d.copy(entries = entries)
    })
    fun updateDay(id: String, change: (PlanDay) -> PlanDay) { days = days.map { if (it.id == id) change(it) else it } }

    FullScreenDialog(onClose, dismissible = false) {
        ReviewFrame(tr("plans.review.title"), cleaned.days.isNotEmpty(), onClose, onSave = {
            val finalName = name.trim().ifEmpty { trText(context, "plans.review.newName") }
            Graph.store.saveTrainingPlan(initial.recordId, finalName, cleaned)
            onClose()
        }) {
            GlassCard {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text(tr("plans.review.name")) }, singleLine = true)
                CheckWarning()
            }
            days.forEach { day ->
                GlassCard {
                    OutlinedTextField(day.title, { t -> updateDay(day.id) { it.copy(title = t) } }, Modifier.fillMaxWidth(),
                        label = { Text(tr("plans.review.dayTitle")) }, singleLine = true)
                    day.entries.forEach { entry ->
                        EntryEditor(entry, ExerciseMatcher.bestMatch(entry.name, all)?.name,
                            onChange = { e -> updateDay(day.id) { d -> d.copy(entries = d.entries.map { if (it.id == e.id) e else it }) } },
                            onDelete = { updateDay(day.id) { d -> d.copy(entries = d.entries.filterNot { it.id == entry.id }) } })
                    }
                    TextButton({ updateDay(day.id) { it.copy(entries = it.entries + PlanEntry(name = "")) } }) {
                        Icon(Icons.Filled.Add, null, tint = Palette.accentText); Spacer(Modifier.width(6.dp))
                        Text(tr("plans.review.addEntry"), color = Palette.accentText)
                    }
                    if (days.size > 1) TextButton({ days = days.filterNot { it.id == day.id } }) {
                        Icon(Icons.Filled.Delete, null, tint = Palette.danger); Spacer(Modifier.width(6.dp))
                        Text(tr("plans.review.deleteDay"), color = Palette.danger)
                    }
                }
            }
            GlassButton(tr("plans.review.addDay"), Modifier.fillMaxWidth(), icon = Icons.Filled.Add) {
                days = days + PlanDay(title = "", entries = listOf(PlanEntry(name = "")))
            }
            SourceText(initial.sourceText)
        }
    }
}

@Composable
private fun EntryEditor(entry: PlanEntry, matchName: String?, onChange: (PlanEntry) -> Unit, onDelete: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0x0DFFFFFF), androidx.compose.foundation.shape.RoundedCornerShape(18.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(entry.name, { onChange(entry.copy(name = it)) }, Modifier.weight(1f),
                label = { Text(tr("plans.review.exercise")) }, singleLine = true)
            IconButton(onDelete) { Icon(Icons.Filled.Delete, tr("history.delete"), tint = Palette.danger) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IntField(tr("plans.review.sets"), entry.sets, Modifier.weight(1f)) { onChange(entry.copy(sets = it)) }
            IntField(tr("plans.review.repsMin"), entry.repsMin, Modifier.weight(1f)) { onChange(entry.copy(repsMin = it)) }
            IntField(tr("plans.review.repsMax"), entry.repsMax, Modifier.weight(1f)) { onChange(entry.copy(repsMax = it)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DecimalField(tr("plans.review.weight"), entry.weightKg, Modifier.weight(1f)) { onChange(entry.copy(weightKg = it)) }
            IntField(tr("plans.review.rest"), entry.restSeconds, Modifier.weight(1f)) { onChange(entry.copy(restSeconds = it)) }
        }
        when {
            matchName != null -> Text(tr("plans.detail.matched", matchName), fontSize = 11.sp, color = Palette.accentSoft)
            entry.name.isNotBlank() -> SecondaryText(tr("plans.review.noMatch"), 11)
        }
    }
}

/** Campo numerico intero facoltativo (vuoto = non indicato). */
@Composable
fun IntField(label: String, value: Int?, modifier: Modifier = Modifier, onChange: (Int?) -> Unit) {
    OutlinedTextField(value?.toString() ?: "", { t ->
        val digits = t.filter { it.isDigit() }.take(5)
        onChange(digits.toIntOrNull())
    }, modifier, label = { Text(label, fontSize = 11.sp) }, placeholder = { Text("—") }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
}

/** Campo decimale facoltativo: accetta sia la virgola sia il punto. */
@Composable
fun DecimalField(label: String, value: Double?, modifier: Modifier = Modifier, onChange: (Double?) -> Unit) {
    val format = remember { NumberFormat.getNumberInstance().apply { maximumFractionDigits = 2; isGroupingUsed = false } }
    var text by remember { mutableStateOf(value?.let { format.format(it) } ?: "") }
    OutlinedTextField(text, { t ->
        val clean = t.filter { it.isDigit() || it == ',' || it == '.' }.take(7)
        text = clean
        onChange(clean.replace(',', '.').toDoubleOrNull())
    }, modifier, label = { Text(label, fontSize = 11.sp) }, placeholder = { Text("—") }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}
