package app.mygymhelper.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mygymhelper.Graph
import app.mygymhelper.R
import app.mygymhelper.data.LegalBlock
import app.mygymhelper.data.LegalDocs
import app.mygymhelper.ui.GlassButton
import app.mygymhelper.ui.GlassCard
import app.mygymhelper.ui.Navigator
import app.mygymhelper.ui.Palette
import app.mygymhelper.ui.PrimaryButton
import app.mygymhelper.ui.ScreenHeader
import app.mygymhelper.ui.ScrollScreen
import app.mygymhelper.ui.tr

/** Prima installazione: disclaimer con conferma esplicita (lo stesso testo è in Info e nella scheda dello store). */
@Composable
fun DisclaimerScreen(onAccept: () -> Unit) {
    var understood by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        ScreenHeader(Icons.Filled.MedicalServices, tr("disclaimer.title"), tr("disclaimer.subtitle"))
        GlassCard(Modifier.weight(1f)) {
            Column(Modifier.verticalScroll(rememberScrollState())) { LegalDocumentView("disclaimer") }
        }
        SwitchRow(tr("disclaimer.check"), understood) { understood = it }
        PrimaryButton(tr("disclaimer.accept"), enabled = understood, onClick = onAccept)
    }
}

/** Consenso esplicito e separato per i dati sulla salute: interruttore spento, si può proseguire senza. */
@Composable
fun ConsentScreen(onFinish: () -> Unit, onClose: (() -> Unit)? = null) {
    var checked by remember { mutableStateOf(false) }
    var showPrivacy by remember { mutableStateOf(false) }
    val prefs = Graph.prefs
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ScreenHeader(Icons.Filled.HealthAndSafety, tr("consent.title"), tr("consent.subtitle"))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            GlassCard { LegalDocumentView("consent", showsTitle = false) }
            GlassCard(onClick = { showPrivacy = !showPrivacy }) {
                Text(tr("info.privacy"), fontWeight = FontWeight.SemiBold)
                if (showPrivacy) LegalDocumentView("privacy", showsTitle = false)
            }
        }
        SwitchRow(tr("consent.check"), checked) { checked = it }
        PrimaryButton(tr("consent.accept"), enabled = checked) { prefs.grantConsent(); onFinish(); onClose?.invoke() }
        GlassButton(tr("consent.later"), Modifier.fillMaxWidth()) { prefs.declineConsent(); onFinish(); onClose?.invoke() }
    }
}

@Composable
fun SwitchRow(text: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    GlassCard(padding = androidx.compose.foundation.layout.PaddingValues(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Spacer(Modifier.size(12.dp))
            Switch(checked, onChange, enabled = enabled,
                colors = SwitchDefaults.colors(checkedTrackColor = Palette.accent, checkedThumbColor = androidx.compose.ui.graphics.Color.White))
        }
    }
}

/** Mostra un documento legale formattato (stessi file .md dell'app iOS). */
@Composable
fun LegalDocumentView(name: String, showsTitle: Boolean = true) {
    val context = LocalContext.current
    val appName = context.getString(R.string.app_name)
    val blocks = remember(name) { LegalDocs.load(context, name, appName) }
    val fallback = remember(name) { LegalDocs.isFallback(context, name) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (fallback) Text(tr("legal.itOnly"), fontSize = 13.sp, color = Palette.accentSoft)
        blocks.forEach { b ->
            when (b.kind) {
                LegalBlock.Kind.TITLE -> if (showsTitle) Text(b.text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                LegalBlock.Kind.HEADING -> Text(b.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                LegalBlock.Kind.PARAGRAPH -> Text(b.text, fontSize = 15.sp, color = androidx.compose.ui.graphics.Color(0xE6FFFFFF))
                LegalBlock.Kind.BULLET -> Row {
                    Text("•  ", color = Palette.accent)
                    Text(b.text, fontSize = 15.sp, color = androidx.compose.ui.graphics.Color(0xE6FFFFFF))
                }
            }
        }
    }
}

@Composable
fun LegalScreen(nav: Navigator, name: String, titleKey: String) {
    ScrollScreen(nav, back = true, title = tr(titleKey)) {
        GlassCard { LegalDocumentView(name) }
    }
}

/** Informativa aperta da Health Connect (fuori dalla navigazione normale). */
@Composable
fun LegalStandalone(name: String, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        GlassCard(Modifier.weight(1f)) { Column(Modifier.verticalScroll(rememberScrollState())) { LegalDocumentView(name) } }
        HorizontalDivider(color = Palette.glassBorder)
        PrimaryButton(tr("session.done"), onClick = onClose)
    }
}
