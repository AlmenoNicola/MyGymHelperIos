package app.mygymhelper

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.mygymhelper.ui.AppBackground
import app.mygymhelper.ui.AppRoot
import app.mygymhelper.ui.MyGymTheme
import app.mygymhelper.ui.Tab
import app.mygymhelper.ui.screens.ConsentScreen
import app.mygymhelper.ui.screens.DisclaimerScreen
import app.mygymhelper.ui.screens.LegalStandalone

class MainActivity : ComponentActivity() {
    /** Aperta da Health Connect per mostrare l'informativa ("perché questi permessi"). */
    private var showPrivacyOnly by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        showPrivacyOnly = isPermissionRationale(intent)
        setContent {
            MyGymTheme {
                val prefs = Graph.prefs
                AppBackground {
                    when {
                        showPrivacyOnly -> LegalStandalone("privacy") { showPrivacyOnly = false }
                        !prefs.disclaimerAccepted -> DisclaimerScreen { prefs.acceptDisclaimer() }
                        !prefs.consentDecided -> ConsentScreen(onFinish = {})
                        else -> AppRoot(Tab.WORKOUT)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (isPermissionRationale(intent)) showPrivacyOnly = true
    }

    override fun onResume() {
        super.onResume()
        Graph.billing.refresh()   // rinnovi, scadenze o acquisti fatti altrove
    }

    private fun isPermissionRationale(i: Intent?) =
        i?.action == "androidx.health.ACTION_SHOW_PERMISSIONS_RATIONALE" || i?.action == "android.intent.action.VIEW_PERMISSION_USAGE"
}
