package app.mygymhelper.services

import android.app.Activity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import app.mygymhelper.BuildConfig
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.OtpType
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.Google
import io.github.jan.supabase.auth.providers.builtin.IDToken
import io.github.jan.supabase.auth.providers.builtin.OTP
import io.github.jan.supabase.auth.status.SessionStatus
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.functions.Functions
import io.github.jan.supabase.functions.functions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Account facoltativo su Supabase (e-mail con codice, Google). Stesso progetto e stesse tabelle dell'app iOS.
 * Serve a collegare gli abbonamenti alla persona (obfuscatedAccountId) e ad autenticare le chiamate al backend.
 * I dati sanitari NON vengono mai caricati sul server.
 * Configurazione in android/local.properties: supabase.url, supabase.anonKey e google.webClientId
 * (la chiave "anon" è pubblica per progetto; la sicurezza è data dalle regole RLS dello schema).
 */
class AccountService(private val scope: CoroutineScope) {
    val client: SupabaseClient? = run {
        val url = BuildConfig.SUPABASE_URL.trim()
        val key = BuildConfig.SUPABASE_ANON_KEY.trim()
        if (url.startsWith("https://") && key.isNotEmpty()) createSupabaseClient(url, key) {
            install(Auth)
            install(Functions)
        } else null
    }

    private val _userId = MutableStateFlow<String?>(null)
    val userId: StateFlow<String?> = _userId.asStateFlow()
    var email by mutableStateOf<String?>(null); private set
    var isWorking by mutableStateOf(false); private set
    var lastError by mutableStateOf<String?>(null)

    val isConfigured: Boolean get() = client != null
    val isSignedIn: Boolean get() = _userId.value != null
    val googleConfigured: Boolean get() = BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()

    private var started = false

    /** Ascolta i cambi di sessione (accesso, uscita, rinnovo del token). La sessione resta salvata sul telefono. */
    fun start() {
        val c = client ?: return
        if (started) return
        started = true
        scope.launch {
            c.auth.sessionStatus.collect { status ->
                val user = (status as? SessionStatus.Authenticated)?.session?.user
                _userId.value = user?.id
                email = user?.email
            }
        }
    }

    /** Token verso il backend: quello dell'utente se ha fatto l'accesso, altrimenti la chiave anon. */
    suspend fun bearerToken(): String {
        val anon = BuildConfig.SUPABASE_ANON_KEY
        val c = client ?: return anon
        return runCatching { c.auth.currentAccessTokenOrNull() }.getOrNull() ?: anon
    }

    // ---------- Accesso ----------

    suspend fun sendEmailCode(address: String): Boolean = attempt { c ->
        c.auth.signInWith(OTP) { this.email = address; createUser = true }
    }

    suspend fun verifyEmailCode(code: String, address: String): Boolean = attempt { c ->
        c.auth.verifyEmailOtp(type = OtpType.Email.EMAIL, email = address, token = code)
    }

    /**
     * Accesso con Google tramite Credential Manager (finestra di sistema con gli account Google del telefono).
     * Il nonce casuale va a Supabase in chiaro e a Google come hash SHA-256 (protezione da riutilizzo del token).
     */
    suspend fun signInWithGoogle(activity: Activity): Boolean {
        if (!googleConfigured) return false
        val rawNonce = makeNonce()
        val option = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
            .setNonce(sha256(rawNonce))
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val idToken = try {
            val credential = CredentialManager.create(activity).getCredential(activity, request).credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL)
                GoogleIdTokenCredential.createFrom(credential.data).idToken
            else null
        } catch (e: GetCredentialCancellationException) {
            return false
        } catch (e: Exception) {
            lastError = e.localizedMessage; return false
        } ?: return false
        return attempt { c ->
            c.auth.signInWith(IDToken) {
                this.idToken = idToken
                provider = Google
                nonce = rawNonce
            }
        }
    }

    suspend fun signOut() { attempt { c -> c.auth.signOut() } }

    /**
     * Elimina l'account e i dati collegati sul server (funzione `delete-account`), poi esce.
     * Gli abbonamenti Google Play restano attivi finché l'utente non li annulla da Play Store.
     */
    suspend fun deleteAccount(): Boolean {
        val ok = attempt { c ->
            c.functions.invoke("delete-account", body = buildJsonObject { put("platform", "android") })
        }
        if (ok) signOut()
        return ok
    }

    private suspend fun attempt(action: suspend (SupabaseClient) -> Unit): Boolean {
        val c = client ?: return false
        isWorking = true
        return try {
            action(c); lastError = null; true
        } catch (e: Exception) {
            lastError = e.localizedMessage ?: e.toString(); false
        } finally {
            isWorking = false
        }
    }

    companion object {
        fun makeNonce(length: Int = 32): String {
            val chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._"
            val random = SecureRandom()
            return String(CharArray(length) { chars[random.nextInt(chars.length)] })
        }

        fun sha256(text: String): String =
            MessageDigest.getInstance("SHA-256").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
