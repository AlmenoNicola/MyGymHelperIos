package app.mygymhelper.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import app.mygymhelper.core.CatalogExercise
import app.mygymhelper.core.WorkoutParameters
import app.mygymhelper.services.BodyLimb
import app.mygymhelper.ui.screens.AccountScreen
import app.mygymhelper.ui.screens.ExerciseCollectionScreen
import app.mygymhelper.ui.screens.ExerciseDetailScreen
import app.mygymhelper.ui.screens.ExerciseListsScreen
import app.mygymhelper.ui.screens.ExercisesScreen
import app.mygymhelper.ui.screens.FoodSearchScreen
import app.mygymhelper.ui.screens.HistoryScreen
import app.mygymhelper.ui.screens.InfoScreen
import app.mygymhelper.ui.screens.LegalScreen
import app.mygymhelper.ui.screens.NutritionScreen
import app.mygymhelper.ui.screens.PaywallScreen
import app.mygymhelper.ui.screens.TrainingPlanDetailScreen
import app.mygymhelper.ui.screens.TrainingPlansScreen
import app.mygymhelper.ui.screens.WorkoutSessionScreen
import app.mygymhelper.ui.screens.WorkoutSetupScreen

/** Schermate raggiungibili dentro una scheda (equivalente dei NavigationLink iOS). */
sealed interface Screen {
    data object WorkoutSetup : Screen
    data class WorkoutSetupFor(val exercise: CatalogExercise) : Screen
    data class Session(val limb: BodyLimb, val parameters: WorkoutParameters, val exercise: CatalogExercise?) : Screen
    data object History : Screen
    data object Exercises : Screen
    data class ExerciseDetail(val exercise: CatalogExercise) : Screen
    data object Lists : Screen
    data class Collection(val title: String, val exercises: List<CatalogExercise>) : Screen
    data object TrainingPlans : Screen
    data class TrainingPlanDetail(val id: String) : Screen
    data object Nutrition : Screen
    data object FoodSearch : Screen
    data object Plans : Screen
    data object Info : Screen
    data class Legal(val name: String, val titleKey: String) : Screen
    data object Account : Screen
}

enum class Tab(val titleKey: String, val icon: ImageVector, val root: Screen) {
    WORKOUT("tab.workout", Icons.Filled.SportsGymnastics, Screen.WorkoutSetup),
    EXERCISES("tab.exercises", Icons.Filled.FitnessCenter, Screen.Exercises),
    NUTRITION("tab.nutrition", Icons.Filled.Restaurant, Screen.Nutrition),
    PLANS("tab.plans", Icons.Filled.Star, Screen.Plans),
    INFO("tab.info", Icons.Filled.Info, Screen.Info)
}

/** Navigazione: una pila di schermate per ogni scheda, come le NavigationStack dell'app iOS. */
class Navigator(private val stacks: Map<Tab, SnapshotStateList<Screen>>, private val select: (Tab) -> Unit, val currentTab: () -> Tab) {
    fun push(screen: Screen) { stacks.getValue(currentTab()).add(screen) }
    fun pop(): Boolean {
        val s = stacks.getValue(currentTab())
        if (s.size <= 1) return false
        s.removeAt(s.lastIndex); return true
    }
    fun canGoBack(): Boolean = stacks.getValue(currentTab()).size > 1
    fun openPlans() { push(Screen.Plans) }
    fun switchTo(tab: Tab) = select(tab)
}

@Composable
fun AppRoot(startTab: Tab = Tab.WORKOUT) {
    var tab by rememberSaveable { mutableStateOf(startTab) }
    val stacks = remember { Tab.entries.associateWith { mutableStateListOf(it.root) } }
    val nav = remember { Navigator(stacks, { tab = it }, { tab }) }
    val stack = stacks.getValue(tab)
    BackHandler(enabled = stack.size > 1) { nav.pop() }

    // Durante l'allenamento la barra delle schede si nasconde: cambiare scheda chiuderebbe la sessione.
    val inSession = stack.last() is Screen.Session
    Scaffold(
        containerColor = Color.Transparent,
        // Gli spazi per la barra di stato li aggiungono le singole schermate.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (!inSession) NavigationBar(containerColor = Color(0xF0262038)) {
                Tab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = t == tab,
                        onClick = {
                            if (t == tab) stacks.getValue(t).let { while (it.size > 1) it.removeAt(it.lastIndex) }   // tocco ripetuto: torna all'inizio
                            tab = t
                        },
                        icon = { Icon(t.icon, null) },
                        label = { Text(tr(t.titleKey)) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Palette.accentText,
                            selectedTextColor = Palette.accentText, indicatorColor = Color(0x33FF6B29),
                            unselectedIconColor = Palette.secondary, unselectedTextColor = Palette.secondary)
                    )
                }
            }
        }
    ) { padding ->
        AppBackground {
            Box(Modifier.fillMaxSize().padding(padding)) {
                ScreenContent(stack.last(), nav)
            }
        }
    }
}

@Composable
private fun ScreenContent(screen: Screen, nav: Navigator) {
    when (screen) {
        Screen.WorkoutSetup -> WorkoutSetupScreen(nav, null)
        is Screen.WorkoutSetupFor -> WorkoutSetupScreen(nav, screen.exercise)
        is Screen.Session -> WorkoutSessionScreen(nav, screen.limb, screen.parameters, screen.exercise)
        Screen.History -> HistoryScreen(nav)
        Screen.Exercises -> ExercisesScreen(nav)
        is Screen.ExerciseDetail -> ExerciseDetailScreen(nav, screen.exercise)
        Screen.Lists -> ExerciseListsScreen(nav)
        is Screen.Collection -> ExerciseCollectionScreen(nav, screen.title, screen.exercises)
        Screen.TrainingPlans -> TrainingPlansScreen(nav)
        is Screen.TrainingPlanDetail -> TrainingPlanDetailScreen(nav, screen.id)
        Screen.Nutrition -> NutritionScreen(nav)
        Screen.FoodSearch -> FoodSearchScreen(nav)
        Screen.Plans -> PaywallScreen(nav)
        Screen.Info -> InfoScreen(nav)
        is Screen.Legal -> LegalScreen(nav, screen.name, screen.titleKey)
        Screen.Account -> AccountScreen(nav)
    }
}
