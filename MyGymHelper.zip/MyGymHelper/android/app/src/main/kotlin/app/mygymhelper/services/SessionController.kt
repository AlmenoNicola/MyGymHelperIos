package app.mygymhelper.services

import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.mygymhelper.core.CatalogExercise
import app.mygymhelper.core.SessionCue
import app.mygymhelper.core.SessionEngine
import app.mygymhelper.core.SessionPhase
import app.mygymhelper.core.SessionSample
import app.mygymhelper.core.SessionSetSample
import app.mygymhelper.core.SetLog
import app.mygymhelper.core.SetRecord
import app.mygymhelper.core.WorkoutParameters
import app.mygymhelper.core.WorkoutSessionRecord

enum class BodyLimb(val raw: String) { ARM("arm"), LEG("leg");
    companion object { fun from(raw: String) = entries.firstOrNull { it.raw == raw } ?: ARM }
}

/** Collega macchina a stati, sensori, avvisi e salvataggio di una sessione (come SessionController.swift). */
class SessionController(
    context: Context,
    val limb: BodyLimb,
    parameters: WorkoutParameters,
    val exercise: CatalogExercise?,
    options: CueOptions
) {
    val totalSets = parameters.sets.coerceAtLeast(1)
    val targetReps = parameters.reps.coerceAtLeast(1)
    val restSeconds = parameters.restSeconds
    val weightKg = parameters.weightKg
    val startedAt = System.currentTimeMillis()
    val motion = MotionService(context)

    var phase by mutableStateOf<SessionPhase>(SessionPhase.NotStarted); private set
    var currentReps by mutableStateOf(0); private set
    var records by mutableStateOf<List<SetRecord>>(emptyList()); private set

    private val engine = SessionEngine(totalSets, targetReps, restSeconds)
    private val cues = CueService(context, options)
    private val metrics = ArrayList<Pair<Double, Boolean>>()   // (picco medio, segnale poco affidabile)
    private var running = false

    /** Orologio monotono: non cambia se l'utente modifica l'ora del telefono. */
    private val now: Double get() = SystemClock.elapsedRealtime() / 1000.0

    val currentSetNumber: Int
        get() = when (val p = phase) {
            is SessionPhase.Working -> p.set
            is SessionPhase.Resting -> p.afterSet + 1
            SessionPhase.NotStarted -> 1
            SessionPhase.Finished -> records.size
        }

    fun start() {
        if (running || phase != SessionPhase.NotStarted) return
        running = true
        motion.onRepCount = { apply(engine.repsCounted(it, now)) }
        motion.start()
        motion.beginSet()
        apply(engine.start(now))
    }

    fun tick() = apply(engine.tick(now))
    fun stop(doneReps: Int) = apply(engine.stop(doneReps, now))
    fun skipRest() = apply(engine.skipRest(now))
    fun endEarly() = apply(engine.endNow(now))

    /** Rilascia sensori e audio. */
    fun end() {
        if (!running) return
        running = false
        motion.stop()
        cues.shutdown()
    }

    private fun apply(list: List<SessionCue>) {
        for (cue in list) {
            cues.play(cue)
            when (cue) {
                is SessionCue.RestStarted, SessionCue.SessionFinished -> motion.pauseCounting()
                SessionCue.RestEnded -> motion.beginSet()
                else -> Unit
            }
        }
        phase = engine.phase
        currentReps = engine.currentReps
        records = engine.records.toList()
        while (metrics.size < records.size) metrics.add(motion.averagePeak to motion.lowConfidence.value)
    }

    /** La sessione appena svolta nel formato del motore adattivo (piano Full). */
    fun sample() = SessionSample(startedAt, weightKg, records.mapIndexed { i, r ->
        SessionSetSample(r.doneReps, r.plannedReps, r.stoppedEarly, metrics.getOrNull(i)?.first ?: 0.0)
    })

    /** Record da salvare nello storico (solo con il consenso). */
    fun makeRecord() = WorkoutSessionRecord(
        startedAt = startedAt, endedAt = System.currentTimeMillis(), limb = limb.raw,
        plannedSets = totalSets, plannedReps = targetReps, restSeconds = restSeconds,
        exerciseId = exercise?.id ?: "", exerciseName = exercise?.name ?: "", weightKg = weightKg,
        sets = records.mapIndexed { i, r ->
            val m = metrics.getOrNull(i)
            SetLog(r.number, r.plannedReps, r.doneReps, r.stoppedEarly, r.durationSeconds, m?.first ?: 0.0, m?.second ?: false)
        })
}
