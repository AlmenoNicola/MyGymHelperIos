package app.mygymhelper.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mygymhelper.BuildConfig
import app.mygymhelper.Graph
import app.mygymhelper.core.SubscriptionTier
import app.mygymhelper.services.PlanOffer
import app.mygymhelper.services.PlayProducts
import app.mygymhelper.ui.GlassButton
import app.mygymhelper.ui.GlassCard
import app.mygymhelper.ui.Navigator
import app.mygymhelper.ui.Palette
import app.mygymhelper.ui.PrimaryButton
import app.mygymhelper.ui.ScreenHeader
import app.mygymhelper.ui.ScrollScreen
import app.mygymhelper.ui.SecondaryText
import app.mygymhelper.ui.tr
import app.mygymhelper.ui.trText

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

fun Context.openUrl(url: String) {
    runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

fun tierKey(t: SubscriptionTier) = when (t) { SubscriptionTier.FREE -> "tier.free"; SubscriptionTier.MID -> "tier.mid"; SubscriptionTier.FULL -> "tier.full" }

private val compareRows = listOf(
    "compare.counting" to listOf(true, true, true),
    "compare.bmi" to listOf(true, true, true),
    "compare.catalogBasic" to listOf(true, true, true),
    "compare.catalogFull" to listOf(false, true, true),
    "compare.lists" to listOf(false, true, true),
    "compare.fixedCoaching" to listOf(false, true, true),
    "compare.nutrition" to listOf(false, true, true),
    "compare.adaptive" to listOf(false, false, true),
    "compare.import" to listOf(false, false, true),
    "compare.meals" to listOf(false, false, true)
)

/** "P7D" -> "7 giorni", "P1M" -> "mese" ... (testi tradotti). */
private fun periodText(context: Context, iso: String): String {
    val m = Regex("""P(\d+)([DWMY])""").matchEntire(iso) ?: return iso
    val n = m.groupValues[1].toInt()
    val days = when (m.groupValues[2]) { "D" -> n; "W" -> n * 7; else -> -1 }
    return when {
        days > 0 -> trText(context, "android.plans.days", days)
        m.groupValues[2] == "M" && n == 1 -> trText(context, "android.plans.month")
        m.groupValues[2] == "Y" && n == 1 -> trText(context, "android.plans.year")
        else -> iso
    }
}

/**
 * Schermata degli abbonamenti (Google Play). Prezzo, periodo e prova arrivano da Play e sono mostrati
 * accanto al pulsante, con rinnovo automatico e modalità di disdetta, come richiesto dalle norme di Google Play
 * sugli abbonamenti. Il pagamento avviene nella finestra di Google Play.
 */
@Composable
fun PaywallScreen(nav: Navigator) {
    val context = LocalContext.current
    val billing = Graph.billing
    val tier by billing.tier.collectAsState()
    val offers by billing.offers.collectAsState()
    val active by billing.activeProduct.collectAsState()
    val status by billing.status.collectAsState()

    ScrollScreen(nav, back = nav.canGoBack(), actions = {
        TextButton({ billing.restore() }) { Text(tr("plans.restore"), color = Palette.accentText) }
        if (tier > SubscriptionTier.FREE) TextButton({ context.openUrl(billing.manageUrl(context.packageName)) }) {
            Text(tr("plans.manage"), color = Palette.accentText)
        }
    }, title = null) {
        ScreenHeader(Icons.Filled.Star, tr("plans.title"), tr("plans.subtitle"))
        Row(verticalAlignment = Alignment.CenterVertically) {
            SecondaryText(tr("plans.current"), 15); Spacer(Modifier.weight(1f))
            Text(tr(tierKey(tier)), fontWeight = FontWeight.Bold,
                modifier = Modifier.background(Palette.gradient, CircleShape).padding(horizontal = 14.dp, vertical = 6.dp))
        }

        GlassCard(padding = PaddingValues(16.dp)) {
            Row {
                Spacer(Modifier.weight(1f))
                SubscriptionTier.entries.forEach { t ->
                    Text(tr(tierKey(t)), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                        color = if (t == SubscriptionTier.FULL) Palette.accentSoft else Color.White, modifier = Modifier.width(48.dp))
                }
            }
            compareRows.forEach { (key, tiers) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr(key), fontSize = 13.sp, modifier = Modifier.weight(1f))
                    tiers.forEach { on ->
                        val label = tr(if (on) "compare.included" else "compare.notIncluded")
                        Icon(if (on) Icons.Filled.CheckCircle else Icons.Filled.Remove, null,
                            tint = if (on) Palette.accent else Color(0x4DFFFFFF),
                            modifier = Modifier.width(48.dp).size(18.dp).semantics { contentDescription = label })
                    }
                }
            }
        }

        if (offers.isEmpty()) GlassCard(padding = PaddingValues(16.dp)) { SecondaryText(tr("android.plans.unavailable"), 15) }
        offers.forEach { offer -> OfferCard(offer, current = offer.productId == active) {
            context.findActivity()?.let { billing.purchase(it, offer) }
        } }

        SecondaryText(tr("android.plans.renewal"), 12)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton({ context.openUrl(BuildConfig.PRIVACY_URL) }) { Text(tr("info.privacy"), fontSize = 12.sp, color = Palette.accentText) }
            TextButton({ context.openUrl(BuildConfig.TERMS_URL) }) { Text(tr("info.terms"), fontSize = 12.sp, color = Palette.accentText) }
        }
        SecondaryText(tr("plans.disclaimer"), 11)
    }

    status?.let { key ->
        AlertDialog(onDismissRequest = { billing.clearStatus() }, text = { Text(tr(key)) },
            confirmButton = { TextButton({ billing.clearStatus() }) { Text("OK") } })
    }
}

@Composable
private fun OfferCard(offer: PlanOffer, current: Boolean, onBuy: () -> Unit) {
    val context = LocalContext.current
    val period = periodText(context, offer.billingPeriod)
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxWidth().background(Color(0x14FFFFFF), shape)
        .border(if (offer.tier == SubscriptionTier.FULL) 1.5.dp else 1.dp,
            if (offer.tier == SubscriptionTier.FULL) Palette.accent else Palette.glassBorder, shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr(tierKey(offer.tier)), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            SecondaryText(tr(if (offer.basePlanId == PlayProducts.YEARLY) "android.plans.yearly" else "android.plans.monthly"), 13)
            Spacer(Modifier.weight(1f))
            Text("${offer.formattedPrice} / $period", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        offer.freeTrialPeriod?.let {
            Text(tr("android.plans.trial", periodText(context, it), offer.formattedPrice, period), fontSize = 13.sp, color = Palette.accentSoft)
        }
        if (current) SecondaryText(tr("android.plans.active"), 13)
        else PrimaryButton(tr(if (offer.freeTrialPeriod != null) "android.plans.startTrial" else "android.plans.subscribe"), onClick = onBuy)
    }
}
