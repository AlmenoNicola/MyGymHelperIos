package app.mygymhelper.services

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import app.mygymhelper.core.SubscriptionTier
import app.mygymhelper.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Identificatori in Google Play Console (Monetizza > Abbonamenti), equivalenti dei prodotti App Store:
 * due abbonamenti, ognuno con i piani base "monthly" e "yearly"; la prova di 7 giorni è un'offerta
 * con id "free-trial" e criterio di idoneità "Nuovo cliente che non ha mai avuto un abbonamento" (per sviluppatore),
 * così si ottiene una volta sola come su iOS.
 */
object PlayProducts {
    const val MID = "mygymhelper_mid"
    const val FULL = "mygymhelper_full"
    const val MONTHLY = "monthly"
    const val YEARLY = "yearly"
    const val TRIAL_OFFER = "free-trial"
    val all = listOf(MID, FULL)
    fun tier(productId: String) = when (productId) { FULL -> SubscriptionTier.FULL; MID -> SubscriptionTier.MID; else -> SubscriptionTier.FREE }
}

/** Una voce acquistabile mostrata nella schermata Piani (prezzi e prova presi da Google Play, mai scritti a mano). */
data class PlanOffer(
    val productId: String,
    val basePlanId: String,
    val tier: SubscriptionTier,
    val offerToken: String,
    val formattedPrice: String,
    val billingPeriod: String,          // ISO 8601: P1M, P1Y
    val freeTrialPeriod: String?,       // es. P7D, solo se l'utente ne ha diritto
    val details: ProductDetails
)

/**
 * Abbonamenti con Google Play Billing. Il livello si calcola dagli acquisti attivi restituiti da Play;
 * gli acquisti vanno "confermati" (acknowledge) entro 3 giorni, altrimenti Google li rimborsa.
 * Se l'utente ha un account, l'acquisto porta il suo id (obfuscatedAccountId) per collegarlo sul server
 * (funzione google-play-notifications). Senza rete si tiene l'ultimo livello verificato per 14 giorni.
 */
class BillingManager(
    context: Context,
    private val prefs: Prefs,
    private val scope: CoroutineScope,
    private val accountId: () -> String?
) : PurchasesUpdatedListener {
    private val _tier = MutableStateFlow(SubscriptionTier.FREE)
    val tier: StateFlow<SubscriptionTier> = _tier.asStateFlow()
    private val _offers = MutableStateFlow<List<PlanOffer>>(emptyList())
    val offers: StateFlow<List<PlanOffer>> = _offers.asStateFlow()
    private val _activeProduct = MutableStateFlow<String?>(null)
    val activeProduct: StateFlow<String?> = _activeProduct.asStateFlow()
    private val _status = MutableStateFlow<String?>(null)
    /** Messaggio da mostrare (chiave di testo), per esempio un acquisto in attesa. */
    val status: StateFlow<String?> = _status.asStateFlow()

    private var activeToken: String? = null
    private val pendingShown = mutableSetOf<String>()
    private var started = false

    private val client: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .enableAutoServiceReconnection()
        .build()

    fun start() {
        if (started) return
        started = true
        restoreCachedTier()
        connect()
    }

    private fun connect() {
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    scope.launch { loadOffers(); refreshNow() }
                }
            }
            override fun onBillingServiceDisconnected() { /* riconnessione automatica (enableAutoServiceReconnection) */ }
        })
    }

    /** Da chiamare al ritorno nell'app: rinnovi, scadenze, acquisti fatti su un altro dispositivo. */
    fun refresh() { if (client.isReady) scope.launch { refreshNow() } }

    /** "Ripristina": rilegge gli acquisti dell'account Google attivo sul telefono. */
    fun restore() { if (client.isReady) scope.launch { loadOffers(); refreshNow() } else connect() }

    fun clearStatus() { _status.value = null }

    private suspend fun loadOffers() {
        val params = QueryProductDetailsParams.newBuilder().setProductList(PlayProducts.all.map {
            QueryProductDetailsParams.Product.newBuilder().setProductId(it).setProductType(BillingClient.ProductType.SUBS).build()
        }).build()
        val details: List<ProductDetails> = suspendCancellableCoroutine { cont ->
            client.queryProductDetailsAsync(params) { result, queryResult ->
                cont.resume(if (result.responseCode == BillingClient.BillingResponseCode.OK) queryResult.productDetailsList else emptyList())
            }
        }
        _offers.value = details.flatMap { pd ->
            val all = pd.subscriptionOfferDetails ?: emptyList()
            listOf(PlayProducts.MONTHLY, PlayProducts.YEARLY).mapNotNull { base ->
                // Play restituisce solo le offerte per cui l'utente è idoneo: la prova c'è solo se ne ha diritto.
                val forBase = all.filter { it.basePlanId == base }
                val chosen = forBase.firstOrNull { it.offerId == PlayProducts.TRIAL_OFFER } ?: forBase.firstOrNull { it.offerId == null }
                    ?: return@mapNotNull null
                val phases = chosen.pricingPhases.pricingPhaseList
                val recurring = phases.lastOrNull() ?: return@mapNotNull null
                val trial = phases.firstOrNull { it.priceAmountMicros == 0L }
                PlanOffer(pd.productId, base, PlayProducts.tier(pd.productId), chosen.offerToken,
                    recurring.formattedPrice, recurring.billingPeriod, trial?.billingPeriod, pd)
            }
        }.sortedWith(compareBy({ it.tier.ordinal }, { it.basePlanId != PlayProducts.MONTHLY }))
    }

    private suspend fun refreshNow() {
        val purchases: List<Purchase>? = suspendCancellableCoroutine { cont ->
            client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()) { result, list ->
                cont.resume(if (result.responseCode == BillingClient.BillingResponseCode.OK) list else null)
            }
        }
        if (purchases == null) return                  // errore di Play: si tiene il livello in cache
        handle(purchases)
    }

    private fun handle(purchases: List<Purchase>) {
        var best = SubscriptionTier.FREE
        var product: String? = null
        var token: String? = null
        for (p in purchases) {
            if (p.purchaseState != Purchase.PurchaseState.PURCHASED) {
                if (p.purchaseState == Purchase.PurchaseState.PENDING && pendingShown.add(p.purchaseToken)) _status.value = "android.plans.pending"
                continue
            }
            if (!p.isAcknowledged) acknowledge(p)
            for (id in p.products) {
                val level = PlayProducts.tier(id)
                if (level > best) { best = level; product = id; token = p.purchaseToken }
            }
        }
        _tier.value = best
        _activeProduct.value = product
        activeToken = token
        prefs.cachedTier = best.ordinal
    }

    private fun acknowledge(p: Purchase) {
        client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) { }
    }

    /** Avvia l'acquisto (o il cambio di piano, con proporzione del tempo residuo). */
    fun purchase(activity: Activity, offer: PlanOffer) {
        val product = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(offer.details).setOfferToken(offer.offerToken).build()
        val builder = BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(product))
        accountId()?.let { builder.setObfuscatedAccountId(it) }
        val old = activeToken
        if (old != null && _activeProduct.value != offer.productId) {
            builder.setSubscriptionUpdateParams(BillingFlowParams.SubscriptionUpdateParams.newBuilder()
                .setOldPurchaseToken(old)
                .setSubscriptionReplacementMode(BillingFlowParams.SubscriptionUpdateParams.ReplacementMode.WITH_TIME_PRORATION)
                .build())
        }
        client.launchBillingFlow(activity, builder.build())
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> scope.launch { refreshNow() }      // rilegge tutto, compresi altri abbonamenti
            BillingClient.BillingResponseCode.USER_CANCELED -> {}
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> scope.launch { refreshNow() }
            else -> _status.value = "android.plans.purchaseFailed"
        }
    }

    private fun restoreCachedTier() {
        val date = prefs.cachedTierVerifiedAt
        if (date == 0L || System.currentTimeMillis() - date > OFFLINE_GRACE_MS) return
        _tier.value = SubscriptionTier.entries.getOrElse(prefs.cachedTier) { SubscriptionTier.FREE }
    }

    /** Pagina di Google Play per gestire o annullare l'abbonamento. */
    fun manageUrl(packageName: String): String {
        val product = _activeProduct.value
        return if (product != null) "https://play.google.com/store/account/subscriptions?sku=$product&package=$packageName"
        else "https://play.google.com/store/account/subscriptions"
    }

    private companion object {
        const val OFFLINE_GRACE_MS = 14L * 24 * 3600 * 1000
    }
}
