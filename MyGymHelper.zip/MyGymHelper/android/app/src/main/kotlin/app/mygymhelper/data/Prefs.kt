package app.mygymhelper.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.edit
import app.mygymhelper.core.Disclaimer

/**
 * Impostazioni semplici (come UserDefaults su iOS), osservabili da Compose.
 * Stesse chiavi dell'app iOS. Il consenso salva data e versione dei testi accettati (prova della scelta).
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("mygymhelper", Context.MODE_PRIVATE)

    var disclaimerAccepted by mutableStateOf(sp.getBoolean(Disclaimer.ACCEPTED_KEY, false)); private set
    var consentAt by mutableStateOf(sp.getLong(KEY_CONSENT_AT, 0L)); private set
    var consentDecided by mutableStateOf(sp.getBoolean(KEY_CONSENT_DECIDED, false)); private set
    var healthSyncEnabled by mutableStateOf(sp.getBoolean(KEY_HEALTH, false)); private set
    var cueSound by mutableStateOf(sp.getBoolean("cue.sound", true)); private set
    var cueVoice by mutableStateOf(sp.getBoolean("cue.voice", true)); private set
    var cueHaptics by mutableStateOf(sp.getBoolean("cue.haptics", true)); private set

    val consentGranted: Boolean get() = consentAt > 0

    fun acceptDisclaimer() {
        disclaimerAccepted = true
        sp.edit {
            putBoolean(Disclaimer.ACCEPTED_KEY, true)
            putLong("disclaimer.acceptedAt", System.currentTimeMillis())
            putString("disclaimer.acceptedVersion", LEGAL_VERSION)
        }
    }

    fun grantConsent() {
        consentAt = System.currentTimeMillis(); consentDecided = true
        sp.edit { putLong(KEY_CONSENT_AT, consentAt); putString(KEY_CONSENT_VERSION, LEGAL_VERSION); putBoolean(KEY_CONSENT_DECIDED, true) }
    }

    fun declineConsent() {
        consentDecided = true
        sp.edit { putBoolean(KEY_CONSENT_DECIDED, true) }
    }

    /** Revoca: azzera il consenso e spegne lo scambio con Health Connect (i dati locali li cancella AppStore). */
    fun revokeConsent() {
        consentAt = 0L; healthSyncEnabled = false
        sp.edit { putLong(KEY_CONSENT_AT, 0L); remove(KEY_CONSENT_VERSION); putBoolean(KEY_HEALTH, false) }
    }

    fun setHealthSync(on: Boolean) { healthSyncEnabled = on; sp.edit { putBoolean(KEY_HEALTH, on) } }
    fun setCueSound(on: Boolean) { cueSound = on; sp.edit { putBoolean("cue.sound", on) } }
    fun setCueVoice(on: Boolean) { cueVoice = on; sp.edit { putBoolean("cue.voice", on) } }
    fun setCueHaptics(on: Boolean) { cueHaptics = on; sp.edit { putBoolean("cue.haptics", on) } }

    // Livello di abbonamento in cache (per l'avvio senza rete).
    var cachedTier: Int
        get() = sp.getInt("entitlement.tier", 0)
        set(v) = sp.edit { putInt("entitlement.tier", v); putLong("entitlement.lastVerified", System.currentTimeMillis()) }
    val cachedTierVerifiedAt: Long get() = sp.getLong("entitlement.lastVerified", 0L)

    /** Elimina tutte le impostazioni: al prossimo avvio (e subito, in memoria) ricompaiono disclaimer e consenso. */
    fun clearAll() {
        sp.edit { clear() }
        disclaimerAccepted = false; consentAt = 0L; consentDecided = false; healthSyncEnabled = false
        cueSound = true; cueVoice = true; cueHaptics = true
    }

    companion object {
        /** Versione dei testi legali, salvata insieme all'accettazione. */
        const val LEGAL_VERSION = "2026-10-20-bozza"
        const val KEY_CONSENT_AT = "consent.health.grantedAt"
        const val KEY_CONSENT_VERSION = "consent.health.version"
        const val KEY_CONSENT_DECIDED = "consent.health.decided"
        const val KEY_HEALTH = "health.sync.enabled"
    }
}
