package app.mygymhelper.services

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContract
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeightRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.records.metadata.Device
import androidx.health.connect.client.records.metadata.Metadata
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import app.mygymhelper.data.Prefs
import java.time.Instant
import java.time.ZoneId

/**
 * Collegamento facoltativo con Health Connect (equivalente di Apple Salute), tutto sul telefono:
 * - lettura di peso e altezza, solo quando l'utente preme "Importa";
 * - scrittura degli allenamenti di forza completati, se il collegamento è attivo.
 * Richiede il consenso ai dati sanitari. Su Android 9-13 serve l'app Health Connect dal Play Store;
 * da Android 14 è parte del sistema.
 */
class HealthConnectService(private val context: Context, private val prefs: Prefs) {

    val permissions: Set<String> = setOf(
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(HeightRecord::class),
        HealthPermission.getWritePermission(ExerciseSessionRecord::class)
    )

    private val sdkStatus: Int get() = HealthConnectClient.getSdkStatus(context)
    val isAvailable: Boolean get() = sdkStatus == HealthConnectClient.SDK_AVAILABLE
    /** Health Connect c'è ma va installato o aggiornato dal Play Store (Android 9-13). */
    val needsInstall: Boolean get() = sdkStatus == HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED

    private val client: HealthConnectClient? get() = if (isAvailable) HealthConnectClient.getOrCreate(context) else null

    val isEnabled: Boolean get() = isAvailable && prefs.healthSyncEnabled && prefs.consentGranted

    /** Contratto per la richiesta dei permessi (schermata di sistema di Health Connect). */
    fun permissionContract(): ActivityResultContract<Set<String>, Set<String>> =
        PermissionController.createRequestPermissionResultContract()

    suspend fun grantedPermissions(): Set<String> =
        runCatching { client?.permissionController?.getGrantedPermissions() ?: emptySet() }.getOrDefault(emptySet())

    /** Pagina del Play Store per installare o aggiornare Health Connect. */
    fun installIntent(): Intent = Intent(Intent.ACTION_VIEW,
        Uri.parse("market://details?id=$PROVIDER&url=healthconnect%3A%2F%2Fonboarding")).setPackage("com.android.vending")

    /** Spegne il collegamento e restituisce i permessi a Health Connect. */
    suspend fun disable() {
        prefs.setHealthSync(false)
        runCatching { client?.permissionController?.revokeAllPermissions() }
    }

    /** Ultimo peso registrato (kg). Null se manca o se la lettura non è permessa. */
    suspend fun latestWeightKg(): Double? {
        if (!isEnabled) return null
        return runCatching {
            client?.readRecords(ReadRecordsRequest(WeightRecord::class, TimeRangeFilter.before(Instant.now()),
                ascendingOrder = false, pageSize = 1))?.records?.firstOrNull()?.weight?.inKilograms
        }.getOrNull()
    }

    suspend fun latestHeightCm(): Double? {
        if (!isEnabled) return null
        return runCatching {
            client?.readRecords(ReadRecordsRequest(HeightRecord::class, TimeRangeFilter.before(Instant.now()),
                ascendingOrder = false, pageSize = 1))?.records?.firstOrNull()?.height?.inMeters?.times(100)
        }.getOrNull()
    }

    /** Salva un allenamento di forza, se il collegamento è attivo e la scrittura è permessa. */
    suspend fun saveWorkoutIfEnabled(startMillis: Long, endMillis: Long, title: String?) {
        if (!isEnabled || endMillis <= startMillis) return
        val write = HealthPermission.getWritePermission(ExerciseSessionRecord::class)
        if (write !in grantedPermissions()) return
        val start = Instant.ofEpochMilli(startMillis)
        val end = Instant.ofEpochMilli(endMillis)
        val zone = ZoneId.systemDefault().rules
        runCatching {
            client?.insertRecords(listOf(ExerciseSessionRecord(
                startTime = start, startZoneOffset = zone.getOffset(start),
                endTime = end, endZoneOffset = zone.getOffset(end),
                metadata = Metadata.activelyRecorded(Device(type = Device.TYPE_PHONE)),
                exerciseType = ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING,
                title = title?.takeIf { it.isNotBlank() }
            )))
        }
        // Errori (Health Connect assente, permesso revocato): l'allenamento resta comunque nello storico dell'app.
    }

    /**
     * Cancella da Health Connect gli allenamenti scritti da questa app (Health Connect permette di cancellare
     * solo i dati scritti dall'app stessa). Usato da "Elimina tutti i dati".
     */
    suspend fun deleteOwnWorkouts() {
        val c = client ?: return
        val write = HealthPermission.getWritePermission(ExerciseSessionRecord::class)
        if (write !in grantedPermissions()) return
        runCatching { c.deleteRecords(ExerciseSessionRecord::class, TimeRangeFilter.before(Instant.now())) }
    }

    companion object {
        const val PROVIDER = "com.google.android.apps.healthdata"
    }
}
