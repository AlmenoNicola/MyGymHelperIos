package app.mygymhelper.ui.screens

import android.app.Activity
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FrontHand
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mygymhelper.Graph
import app.mygymhelper.core.AdaptiveCoach
import app.mygymhelper.core.CatalogExercise
import app.mygymhelper.core.CoachingAdvice
import app.mygymhelper.core.CoachingSupport
import app.mygymhelper.core.Feature
import app.mygymhelper.core.FeatureGate
import app.mygymhelper.core.FixedCoaching
import app.mygymhelper.core.SessionPhase
import app.mygymhelper.core.WorkoutParameters
import app.mygymhelper.services.BodyLimb
import app.mygymhelper.services.CueOptions
import app.mygymhelper.services.SessionController
import app.mygymhelper.ui.Chip
import app.mygymhelper.ui.CounterRow
import app.mygymhelper.ui.GlassButton
import app.mygymhelper.ui.GlassCard
import app.mygymhelper.ui.LockedNote
import app.mygymhelper.ui.Navigator
import app.mygymhelper.ui.Palette
import app.mygymhelper.ui.PrimaryButton
import app.mygymhelper.ui.ProgressRing
import app.mygymhelper.ui.Screen
import app.mygymhelper.ui.ScreenHeader
import app.mygymhelper.ui.ScrollScreen
import app.mygymhelper.ui.SecondaryText
import app.mygymhelper.ui.WeightRow
import app.mygymhelper.ui.kgText
import app.mygymhelper.ui.tr
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

// ---------- Testi dei consigli (condivisi da impostazione e riepilogo) ----------

@Composable
fun adviceText(item: CoachingAdvice, bodyweight: Boolean): String = when (item) {
    is CoachingAdvice.IncreaseWeight -> if (bodyweight) tr("advice.moreReps") else tr("advice.increase", kgText(item.byKg).removeSuffix(" kg"))
    CoachingAdvice.KeepAsIs -> tr("advice.keep")
    is CoachingAdvice.DecreaseWeight -> tr("advice.decrease", item.percent)
    CoachingAdvice.AddSet -> tr("advice.addSet")
    CoachingAdvice.RemoveSet -> tr("advice.removeSet")
}

@Composable
fun ParametersLine(p: WorkoutParameters) {
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("${p.sets} × ${p.reps}", fontWeight = FontWeight.SemiBold)
        Text(if (p.weightKg > 0) kgText(p.weightKg) else "—", fontWeight = FontWeight.SemiBold)
        Text("${p.restSeconds} s", fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AdviceCard(title: String, reasons: List<String>, parameters: WorkoutParameters, details: List<String> = emptyList(), onApply: (() -> Unit)? = null) {
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.AutoAwesome, null, tint = Palette.accent, modifier = Modifier.size(18.dp))
            Spacer(Modifier.size(8.dp)); Text(title, fontWeight = FontWeight.Bold)
        }
        reasons.forEach { SecondaryText(tr(it), 15) }
        details.forEach { Text(it, fontSize = 15.sp) }
        ParametersLine(parameters)
        if (onApply != null) PrimaryButton(tr("advice.apply"), onClick = onApply)
    }
}

// ---------- Impostazione dell'allenamento ----------

@Composable
fun WorkoutSetupScreen(nav: Navigator, openedWith: CatalogExercise?) {
    val prefs = Graph.prefs
    val data by Graph.store.data.collectAsState()
    val tier by Graph.billing.tier.collectAsState()
    var exercise by remember { mutableStateOf(openedWith) }
    var limb by rememberSaveable { mutableStateOf(if (openedWith?.isLowerBody == true) BodyLimb.LEG else BodyLimb.ARM) }
    var sets by rememberSaveable { mutableIntStateOf(3) }
    var reps by rememberSaveable { mutableIntStateOf(10) }
    var rest by rememberSaveable { mutableIntStateOf(90) }
    var weight by rememberSaveable { mutableDoubleStateOf(0.0) }
    var showPicker by remember { mutableStateOf(false) }
    var prefilledFor by remember { mutableStateOf<String?>(null) }
    val current = WorkoutParameters(sets, reps, rest, weight)
    fun apply(p: WorkoutParameters) { sets = p.sets; reps = p.reps; rest = p.restSeconds; weight = p.weightKg }

    // Precompila da scheda e ultima sessione, una volta per esercizio.
    LaunchedEffect(exercise?.id, data) {
        val ex = exercise ?: return@LaunchedEffect
        if (prefilledFor == ex.id) return@LaunchedEffect
        prefilledFor = ex.id
        CoachingSupport.planTarget(ex, data.trainingPlans)?.let { t ->
            t.sets?.let { sets = it }; t.repsMin?.let { reps = it }; t.restSeconds?.let { rest = it }; t.weightKg?.let { weight = it }
        }
        data.sessions.lastOrNull { it.exerciseId == ex.id }?.let { last ->
            weight = last.weightKg
            if (last.plannedSets > 0) sets = last.plannedSets
            if (last.plannedReps > 0) reps = last.plannedReps
            if (last.restSeconds > 0) rest = last.restSeconds
        }
        apply(WorkoutParameters(sets, reps, rest, weight).clamped())
    }

    ScrollScreen(nav, back = openedWith != null, title = openedWith?.name) {
        if (openedWith == null) ScreenHeader(Icons.Filled.Bolt, tr("setup.title"), tr("setup.subtitle"))

        GlassCard(padding = androidx.compose.foundation.layout.PaddingValues(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.FitnessCenter, null, tint = Palette.accent)
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    SecondaryText(tr("setup.exercise"), 12)
                    Text(exercise?.name ?: tr("setup.noExercise"), fontWeight = FontWeight.Bold)
                }
                if (openedWith == null) GlassButton(tr(if (exercise == null) "setup.choose" else "setup.change")) { showPicker = true }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            BodyLimb.entries.forEach { item ->
                val on = item == limb
                Column(Modifier.weight(1f).clip(RoundedCornerShape(28.dp))
                    .background(if (on) Palette.gradient else Brush.linearGradient(listOf(Color(0x12FFFFFF), Color(0x12FFFFFF))))
                    .clickable { limb = item }.padding(vertical = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(if (item == BodyLimb.ARM) Icons.Filled.SportsGymnastics else Icons.Filled.DirectionsWalk, null,
                        tint = if (on) Color.White else Palette.secondary, modifier = Modifier.size(34.dp))
                    Text(tr(if (item == BodyLimb.ARM) "limb.arm" else "limb.leg"), fontWeight = FontWeight.Bold,
                        color = if (on) Color.White else Palette.secondary)
                }
            }
        }
        SecondaryText(tr("workout.pocketWarning"))

        val ex = exercise
        if (ex != null) {
            val adaptive = if (FeatureGate.isAvailable(Feature.ADAPTIVE_COACHING, tier))
                CoachingSupport.adaptive(ex, data.sessions, data.trainingPlans, sets, reps) else null
            val fixed = if (adaptive == null && FeatureGate.isAvailable(Feature.FIXED_COACHING, tier))
                CoachingSupport.fixed(ex, data.sessions) else null
            when {
                adaptive != null -> {
                    val proposed = adaptive.parameters(weight)
                    AdviceCard(tr("advice.adaptiveTitle"), adaptive.reasonKeys, proposed) { apply(proposed) }
                }
                fixed != null -> {
                    val proposed = fixed.applied(current)
                    AdviceCard(tr("advice.title"), listOf(fixed.reasonKey), proposed,
                        fixed.advice.map { adviceText(it, weight == 0.0) }) { apply(proposed) }
                }
                FeatureGate.isAvailable(Feature.FIXED_COACHING, tier) -> SecondaryText(tr("advice.noHistory"))
                else -> LockedNote(tr("advice.locked")) { nav.openPlans() }
            }
        }

        GlassCard {
            CounterRow(tr("counter.sets"), sets, WorkoutParameters.SETS_RANGE) { sets = it }
            CounterRow(tr("counter.reps"), reps, WorkoutParameters.REPS_RANGE) { reps = it }
            CounterRow(tr("counter.rest"), rest, WorkoutParameters.REST_RANGE, step = 15) { rest = it }
            if (exercise != null) WeightRow(tr("setup.weight"), weight) { weight = it }
        }

        GlassCard {
            Text(tr("cue.title"), fontWeight = FontWeight.Bold)
            ToggleLine(tr("cue.voice"), prefs.cueVoice) { prefs.setCueVoice(it) }
            ToggleLine(tr("cue.sound"), prefs.cueSound) { prefs.setCueSound(it) }
            ToggleLine(tr("cue.haptics"), prefs.cueHaptics) { prefs.setCueHaptics(it) }
        }

        PrimaryButton(tr("workout.start"), icon = Icons.Filled.PlayArrow) {
            nav.push(Screen.Session(limb, current.clamped(), exercise))
        }
        if (openedWith == null) GlassButton(tr("history.open"), Modifier.fillMaxWidth(), icon = Icons.Filled.History) { nav.push(Screen.History) }
    }

    if (showPicker) ExercisePickerSheet(onDismiss = { showPicker = false }) { picked ->
        exercise = picked
        if (picked != null) limb = if (picked.isLowerBody) BodyLimb.LEG else BodyLimb.ARM else weight = 0.0
        prefilledFor = null
        showPicker = false
    }
}

@Composable
fun ToggleLine(text: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(text, modifier = Modifier.weight(1f))
        Switch(checked, onChange, enabled = enabled,
            colors = SwitchDefaults.colors(checkedTrackColor = Palette.accent, checkedThumbColor = Color.White))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExercisePickerSheet(onDismiss: () -> Unit, onPick: (CatalogExercise?) -> Unit) {
    val tier by Graph.billing.tier.collectAsState()
    val all by Graph.catalog.all.collectAsState()
    var query by remember { mutableStateOf("") }
    val items = remember(all, tier, query) {
        Graph.catalog.visible(tier).filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }.sortedBy { it.name.lowercase() }
    }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text(tr("setup.choose"), fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(bottom = 8.dp))
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text(tr("ex.search")) }, singleLine = true)
            LazyColumn(Modifier.fillMaxWidth().height(480.dp)) {
                item {
                    Text(tr("setup.noExercise"), color = Palette.accentText, modifier = Modifier.fillMaxWidth().clickable { onPick(null) }.padding(vertical = 14.dp))
                }
                items(items, key = { it.id }) { ex ->
                    Column(Modifier.fillMaxWidth().clickable { onPick(ex) }.padding(vertical = 10.dp)) {
                        Text(ex.name, fontWeight = FontWeight.SemiBold)
                        SecondaryText(musclesLine(ex.primary), 12)
                    }
                }
            }
        }
    }
}

// ---------- Sessione ----------

@Composable
fun WorkoutSessionScreen(nav: Navigator, limb: BodyLimb, parameters: WorkoutParameters, exercise: CatalogExercise?) {
    val context = LocalContext.current
    val prefs = Graph.prefs
    // Il controller si crea una sola volta per questa schermata.
    val controller = remember {
        SessionController(context, limb, parameters, exercise, CueOptions(prefs.cueSound, prefs.cueVoice, prefs.cueHaptics))
    }
    var showStop by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    val phase = controller.phase

    // Schermo acceso durante l'allenamento (i sensori si fermano se l'app va in background).
    DisposableEffect(Unit) {
        val window = context.findActivity()?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        controller.start()
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            controller.end()
        }
    }
    LaunchedEffect(Unit) { while (true) { delay(250); controller.tick() } }
    // Tasto/gesto Indietro durante l'allenamento: termina la sessione e mostra il riepilogo (come "Termina").
    androidx.activity.compose.BackHandler(enabled = phase != SessionPhase.Finished) { controller.endEarly() }
    LaunchedEffect(phase) {
        if (phase == SessionPhase.Finished && !saved && prefs.consentGranted && controller.records.isNotEmpty()) {
            saved = true
            Graph.store.addSession(controller.makeRecord())
            val end = System.currentTimeMillis()
            // Scope dell'app: la scrittura in Health Connect finisce anche se si chiude subito il riepilogo.
            Graph.scope.launch { Graph.health.saveWorkoutIfEnabled(controller.startedAt, end, exercise?.name) }
        }
    }

    when (phase) {
        SessionPhase.Finished -> SessionSummary(nav, controller, saved)
        is SessionPhase.Resting -> SessionFrame(controller) {
            Text(tr("session.rest"), fontWeight = FontWeight.SemiBold, color = Palette.secondary)
            ProgressRing(if (controller.restSeconds > 0) phase.remaining / controller.restSeconds.toFloat() else 0f) {
                Text("${phase.remaining}", fontSize = 88.sp, fontWeight = FontWeight.ExtraBold)
            }
            Text(tr("session.next", phase.afterSet + 1), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            PrimaryButton(tr("session.skipRest"), icon = Icons.Filled.SkipNext) { controller.skipRest() }
            TextButton({ controller.endEarly() }) { Text(tr("session.end"), color = Palette.secondary) }
        }
        else -> SessionFrame(controller) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                exercise?.let { Text(it.name, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                Text(tr("session.set", controller.currentSetNumber, controller.totalSets), color = Palette.secondary, fontWeight = FontWeight.SemiBold)
                if (controller.weightKg > 0) Text(kgText(controller.weightKg), color = Palette.accentSoft)
            }
            ProgressRing(controller.currentReps / controller.targetReps.toFloat()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${controller.currentReps}", fontSize = 88.sp, fontWeight = FontWeight.ExtraBold)
                    Text("/ ${controller.targetReps}", fontSize = 20.sp, color = Palette.secondary)
                }
            }
            val calibrating by controller.motion.calibrating.collectAsState()
            val low by controller.motion.lowConfidence.collectAsState()
            when {
                !controller.motion.isAvailable -> StatusPill(tr("session.noSensor"), warning = true)
                calibrating -> StatusPill(tr("session.calibrating"))
                low -> StatusPill(tr("workout.pocketWarning"), warning = true)
            }
            Spacer(Modifier.weight(1f))
            GlassButton(tr("session.stopped"), Modifier.fillMaxWidth(), color = Palette.danger, icon = Icons.Filled.FrontHand) { showStop = true }
            TextButton({ controller.endEarly() }) { Text(tr("session.end"), color = Palette.secondary) }
        }
    }

    if (showStop) StopDialog(controller.targetReps, controller.currentReps, onDismiss = { showStop = false }) {
        controller.stop(it); showStop = false
    }
}

@Composable
private fun SessionFrame(controller: SessionController, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..controller.totalSets).forEach { n ->
                val done = n <= controller.records.size
                val current = n == controller.currentSetNumber
                Box(Modifier.weight(1f).height(8.dp).clip(CircleShape).background(
                    when { done -> Palette.gradient; current -> Brush.linearGradient(listOf(Palette.accent.copy(alpha = .55f), Palette.accent.copy(alpha = .55f)))
                        else -> Brush.linearGradient(listOf(Color(0x1FFFFFFF), Color(0x1FFFFFFF))) }))
            }
        }
        content()
    }
}

@Composable
private fun StatusPill(text: String, warning: Boolean = false) {
    Row(Modifier.clip(RoundedCornerShape(22.dp)).background(Palette.glass).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (warning) { Icon(Icons.Filled.Warning, null, tint = Color(0xFFFF9F0A), modifier = Modifier.size(18.dp)); Spacer(Modifier.size(8.dp)) }
        Text(text, fontSize = 14.sp, color = if (warning) Color(0xFFFF9F0A) else Color.White)
    }
}

/** "Mi sono fermato": quante ripetizioni sono state fatte. */
@Composable
private fun StopDialog(target: Int, initial: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var reps by remember { mutableIntStateOf(initial.coerceAtMost(target)) }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(tr("stop.title")) },
        text = { CounterRow(tr("counter.reps"), reps, 0..target) { reps = it } },
        confirmButton = { TextButton({ onConfirm(reps) }) { Text(tr("stop.confirm"), color = Palette.accentText) } },
        dismissButton = { TextButton(onDismiss) { Text(tr("info.cancel")) } })
}

@Composable
private fun SessionSummary(nav: Navigator, controller: SessionController, saved: Boolean) {
    val data by Graph.store.data.collectAsState()
    val tier by Graph.billing.tier.collectAsState()
    val records = controller.records
    val ex = controller.exercise
    val current = WorkoutParameters(controller.totalSets, controller.targetReps, controller.restSeconds, controller.weightKg)
    ScrollScreen(nav = null) {
        ScreenHeader(Icons.Filled.Flag, tr("summary.title"), tr("summary.subtitle"))
        GlassCard {
            if (ex != null) Row { Text(ex.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (controller.weightKg > 0) SecondaryText(kgText(controller.weightKg), 15) }
            records.forEach { r ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("session.setResult", r.number, r.doneReps, r.plannedReps), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    if (r.stoppedEarly) Text(tr("session.stoppedTag"), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(CircleShape).background(Color(0x59FF3B30)).padding(horizontal = 10.dp, vertical = 4.dp))
                    else Icon(Icons.Filled.CheckCircle, null, tint = Palette.accent)
                }
            }
            if (records.isEmpty()) SecondaryText(tr("summary.empty"), 15)
        }
        if (records.isNotEmpty()) {
            if (ex != null && FeatureGate.isAvailable(Feature.ADAPTIVE_COACHING, tier)) {
                // La sessione appena salvata è già nello storico: si esclude e si aggiunge quella in memoria.
                val past = data.sessions.filter { kotlin.math.abs(it.startedAt - controller.startedAt) > 1000 }
                val advice = AdaptiveCoach.advise(CoachingSupport.samples(ex.id, past) + controller.sample(), ex.isCompound,
                    controller.totalSets, controller.targetReps, CoachingSupport.planTarget(ex, data.trainingPlans))
                AdviceCard(tr("advice.nextTime"), advice.reasonKeys, advice.parameters(controller.weightKg))
            } else if (FeatureGate.isAvailable(Feature.FIXED_COACHING, tier)) {
                val fixed = FixedCoaching.advise(records.map { it.outcome }, ex?.isCompound ?: false, ex?.isLowerBody ?: (controller.limb == BodyLimb.LEG))
                AdviceCard(tr("advice.title"), listOf(fixed.reasonKey), fixed.applied(current), fixed.advice.map { adviceText(it, controller.weightKg == 0.0) })
                if (ex == null && FeatureGate.isAvailable(Feature.ADAPTIVE_COACHING, tier)) SecondaryText(tr("advice.chooseExercise"))
            } else {
                GlassCard { LockedNote(tr("advice.locked")) { nav.openPlans() } }
            }
        }
        if (!saved) SecondaryText(tr("session.notSaved"))
        PrimaryButton(tr("session.done")) { nav.pop() }
    }
}

// ---------- Storico ----------

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HistoryScreen(nav: Navigator) {
    val data by Graph.store.data.collectAsState()
    var toDelete by remember { mutableStateOf<String?>(null) }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    ScrollScreen(nav, back = true) {
        ScreenHeader(Icons.Filled.History, tr("history.title"), tr("history.subtitle"))
        when {
            !Graph.prefs.consentGranted -> GlassCard { Text(tr("history.noConsent")) }
            data.sessions.isEmpty() -> GlassCard { SecondaryText(tr("history.empty"), 15) }
            else -> data.sessions.sortedByDescending { it.startedAt }.forEach { s ->
                Box(Modifier.combinedClickable(onClick = {}, onLongClick = { toDelete = s.id })) {
                    GlassCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.exerciseName.ifEmpty { tr(if (s.limb == "leg") "limb.leg" else "limb.arm") }, fontWeight = FontWeight.Bold)
                                SecondaryText(fmt.format(Date(s.startedAt)) + if (s.weightKg > 0) " · ${kgText(s.weightKg)}" else "", 14)
                            }
                            Text(tr("history.sets", s.sets.size, s.plannedSets), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
    toDelete?.let { id ->
        AlertDialog(onDismissRequest = { toDelete = null },
            title = { Text(tr("history.delete")) },
            confirmButton = { TextButton({ Graph.store.deleteSession(id); toDelete = null }) { Text(tr("history.delete"), color = Palette.danger) } },
            dismissButton = { TextButton({ toDelete = null }) { Text(tr("info.cancel")) } })
    }
}
