package app.mygymhelper.data

import android.content.Context
import app.mygymhelper.core.AppData
import app.mygymhelper.core.AppDataCodec
import app.mygymhelper.core.ExerciseListRecord
import app.mygymhelper.core.HealthProfile
import app.mygymhelper.core.NutritionPlanRecord
import app.mygymhelper.core.ParsedNutritionPlan
import app.mygymhelper.core.TrainingPlan
import app.mygymhelper.core.TrainingPlanRecord
import app.mygymhelper.core.WorkoutSessionRecord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

/**
 * Archivio locale dei dati sulla salute (storico, elenchi, schede, piano del nutrizionista, profilo).
 * Un file JSON in noBackupFilesDir: escluso dai backup automatici, resta solo su questo telefono
 * (come l'archivio SwiftData escluso da iCloud su iOS). Si scrive solo con il consenso.
 */
class AppStore(context: Context, private val prefs: Prefs, private val scope: CoroutineScope) {
    private val file = File(context.noBackupFilesDir, "mygymhelper-data.json")
    private val writeLock = Mutex()
    /** Scritture una alla volta, nell'ordine in cui sono chieste. */
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val io = Dispatchers.IO.limitedParallelism(1)

    // Lettura sincrona all'avvio (file piccolo): nessuna modifica può arrivare prima dei dati salvati
    // e sovrascriverli.
    private val _data = MutableStateFlow(
        runCatching { if (file.exists()) AppDataCodec.decode(file.readText()) else AppData() }.getOrDefault(AppData())
    )
    val data: StateFlow<AppData> = _data.asStateFlow()

    private fun mutate(change: (AppData) -> AppData) {
        if (!prefs.consentGranted) return      // senza consenso non si salvano dati sanitari
        _data.update(change)
        persist()
    }

    private fun persist() {
        scope.launch(io) {
            writeLock.withLock {
                val snapshot = _data.value          // sempre lo stato più recente
                if (snapshot == AppData() && !file.exists()) return@withLock
                val tmp = File(file.parentFile, file.name + ".tmp")
                tmp.writeText(AppDataCodec.encode(snapshot))
                if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }   // scrittura atomica
            }
        }
    }

    // Storico
    fun addSession(s: WorkoutSessionRecord) = mutate { it.copy(sessions = it.sessions + s) }
    fun deleteSession(id: String) = mutate { d -> d.copy(sessions = d.sessions.filterNot { it.id == id }) }

    // Elenchi
    fun createList(name: String, exerciseIds: List<String> = emptyList()) =
        mutate { it.copy(lists = it.lists + ExerciseListRecord(name = name, exerciseIds = exerciseIds)) }
    fun addToList(listId: String, exerciseId: String) = mutate { d ->
        d.copy(lists = d.lists.map { if (it.id == listId && exerciseId !in it.exerciseIds) it.copy(exerciseIds = it.exerciseIds + exerciseId) else it })
    }
    fun deleteList(id: String) = mutate { d -> d.copy(lists = d.lists.filterNot { it.id == id }) }

    // Schede di allenamento (la più recente è quella usata per i consigli)
    fun saveTrainingPlan(id: String?, name: String, plan: TrainingPlan) = mutate { d ->
        if (id != null && d.trainingPlans.any { it.id == id })
            d.copy(trainingPlans = d.trainingPlans.map { if (it.id == id) it.copy(name = name, plan = plan) else it })
        else d.copy(trainingPlans = d.trainingPlans + TrainingPlanRecord(name = name, plan = plan))
    }
    fun deleteTrainingPlan(id: String) = mutate { d -> d.copy(trainingPlans = d.trainingPlans.filterNot { it.id == id }) }

    // Scheda del nutrizionista: se ne tiene una
    fun saveNutritionPlan(plan: ParsedNutritionPlan) = mutate { it.copy(nutritionPlan = NutritionPlanRecord(plan = plan)) }
    fun deleteNutritionPlan() = mutate { it.copy(nutritionPlan = null) }

    // Profilo (creato solo dopo il consenso)
    fun updateProfile(change: (HealthProfile) -> HealthProfile) = mutate { it.copy(profile = change(it.profile ?: HealthProfile())) }
    fun ensureProfile() { if (_data.value.profile == null) updateProfile { it } }

    /** Cancella tutti i dati sulla salute salvati sul telefono. */
    fun deleteHealthData() {
        _data.value = AppData()
        scope.launch(io) { writeLock.withLock { file.delete() } }   // dopo le scritture già in coda
    }
}
