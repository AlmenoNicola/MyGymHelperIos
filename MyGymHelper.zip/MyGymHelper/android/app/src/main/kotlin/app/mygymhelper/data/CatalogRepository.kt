package app.mygymhelper.data

import android.content.Context
import app.mygymhelper.BuildConfig
import app.mygymhelper.core.CatalogAccess
import app.mygymhelper.core.CatalogExercise
import app.mygymhelper.core.Exercise
import app.mygymhelper.core.MiniJson
import app.mygymhelper.core.SeedCatalog
import app.mygymhelper.core.SubscriptionTier
import app.mygymhelper.services.AccountService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Catalogo esercizi: elenco incluso nell'app (funziona subito e offline) più, se c'è il backend Supabase,
 * gli esercizi MuscleWiki dalla funzione `catalog`. La cache su disco vale al massimo 30 giorni
 * (condizioni MuscleWiki): senza rete non si usa mai un catalogo scaduto.
 */
class CatalogRepository(private val context: Context, private val account: AccountService) {
    val language: String = Locale.getDefault().language.ifEmpty { "en" }
    private val _all = MutableStateFlow(loadSeed())
    val all: StateFlow<List<CatalogExercise>> = _all.asStateFlow()
    private var didRefresh = false
    private val cacheFile get() = File(context.cacheDir, "catalog-$language.json")

    private fun loadSeed(): List<CatalogExercise> = runCatching {
        val json = context.assets.open("exercises_seed.json").bufferedReader().use { it.readText() }
        SeedCatalog.decode(json, Locale.getDefault().language.ifEmpty { "en" })
    }.getOrDefault(emptyList())

    fun visible(tier: SubscriptionTier) = CatalogAccess.visible(_all.value, tier)
    fun exercise(id: String) = _all.value.firstOrNull { it.id == id }

    suspend fun refreshRemote() {
        if (didRefresh || BuildConfig.SUPABASE_URL.isBlank()) return
        val remote = withContext(Dispatchers.IO) { cachedOrFetch() } ?: return
        val seeds = _all.value.filter { it.id.startsWith("seed-") }
        _all.value = seeds + remote.mapNotNull { it.toCatalog() }
        didRefresh = true
    }

    private suspend fun cachedOrFetch(): List<Exercise>? {
        runCatching {
            val o = MiniJson.parse(cacheFile.readText()) as? Map<*, *>
            val savedAt = (o?.get("savedAt") as? Number)?.toLong() ?: 0L
            if (System.currentTimeMillis() - savedAt < MAX_AGE_MS) {
                return Exercise.decodeList(MiniJson.stringify(o?.get("exercises")))
            }
        }
        return runCatching {
            val url = URL("${BuildConfig.SUPABASE_URL.trimEnd('/')}/functions/v1/catalog?lang=${URLEncoder.encode(language, "UTF-8")}")
            val token = account.bearerToken()
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000; readTimeout = 60_000
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
            }
            try {
                if (conn.responseCode !in 200..299) return null
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val list = Exercise.decodeList(body)
                cacheFile.writeText("{\"savedAt\":${System.currentTimeMillis()},\"exercises\":${Exercise.encodeList(list)}}")
                list
            } finally { conn.disconnect() }
        }.getOrNull()
    }

    companion object { const val MAX_AGE_MS = 30L * 24 * 3600 * 1000 }
}
