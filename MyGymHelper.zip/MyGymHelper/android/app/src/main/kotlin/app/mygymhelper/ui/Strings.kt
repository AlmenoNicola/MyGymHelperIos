package app.mygymhelper.ui

import android.annotation.SuppressLint
import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Testi tradotti con le stesse chiavi dell'app iOS ("ex.title", "session.set" ...).
 * Le risorse si generano da App/Localizable.xcstrings con tools/xcstrings_to_android.py:
 * la chiave "session.set %lld %lld" diventa la risorsa R.string.session_set.
 * Serve anche per le chiavi calcolate (muscle.<nome>, food.<nome>, coach.<motivo> ...).
 */
private val idCache = ConcurrentHashMap<String, Int>()

@SuppressLint("DiscouragedApi")
private fun stringId(context: Context, key: String): Int {
    val name = key.substringBefore(' ').replace(Regex("[^A-Za-z0-9_]"), "_")
    return idCache.getOrPut(name) { context.resources.getIdentifier(name, "string", context.packageName) }
}

fun trText(context: Context, key: String, vararg args: Any): String {
    val id = stringId(context, key)
    if (id == 0) return key
    return if (args.isEmpty()) context.getString(id) else context.getString(id, *args)
}

@Composable
fun tr(key: String, vararg args: Any): String = trText(LocalContext.current, key, *args)
