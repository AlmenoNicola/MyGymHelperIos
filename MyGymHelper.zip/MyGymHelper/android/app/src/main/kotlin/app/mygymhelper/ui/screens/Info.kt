package app.mygymhelper.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mygymhelper.BuildConfig
import app.mygymhelper.Graph
import app.mygymhelper.ui.GlassButton
import app.mygymhelper.ui.GlassCard
import app.mygymhelper.ui.Navigator
import app.mygymhelper.ui.Palette
import app.mygymhelper.ui.PrimaryButton
import app.mygymhelper.ui.Screen
import app.mygymhelper.ui.ScreenHeader
import app.mygymhelper.ui.ScrollScreen
import app.mygymhelper.ui.SecondaryText
import app.mygymhelper.ui.tr
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

/** Informazioni: account, Health Connect, documenti legali, consenso, fonti dei dati e cancellazione dei dati locali. */
@Composable
fun InfoScreen(nav: Navigator) {
    val context = LocalContext.current
    val prefs = Graph.prefs
    val account = Graph.account
    val health = Graph.health
    val scope = rememberCoroutineScope()
    val userId by account.userId.collectAsState()
    var showConsent by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmRevoke by remember { mutableStateOf(false) }
    val granted = prefs.consentGranted

    // Richiesta dei permessi Health Connect: si attiva solo se l'utente li concede tutti.
    val permissionLauncher = rememberLauncherForActivityResult(health.permissionContract()) { result ->
        prefs.setHealthSync(result.containsAll(health.permissions))
    }
    // Se l'utente ha tolto i permessi dalle impostazioni di Health Connect, l'interruttore torna spento.
    LaunchedEffect(prefs.healthSyncEnabled) {
        if (prefs.healthSyncEnabled && health.isAvailable && !health.grantedPermissions().containsAll(health.permissions)) prefs.setHealthSync(false)
    }

    ScrollScreen(nav) {
        ScreenHeader(Icons.Filled.Info, tr("info.title"), tr("info.subtitle"))

        if (account.isConfigured) {
            GlassCard(padding = PaddingValues(16.dp), onClick = { nav.push(Screen.Account) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AccountCircle, null, tint = Palette.accent, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("account.title"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        SecondaryText(account.email ?: tr(if (userId != null) "account.signedIn" else "account.optional"), 12)
                    }
                    Icon(Icons.Filled.ChevronRight, null, tint = Palette.secondary)
                }
            }
        }

        GlassCard(padding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
            LinkRow(tr("info.disclaimer"), Icons.Filled.MedicalServices) { nav.push(Screen.Legal("disclaimer", "info.disclaimer")) }
            HorizontalDivider(color = Color(0x26FFFFFF))
            LinkRow(tr("info.privacy"), Icons.Filled.Security) { nav.push(Screen.Legal("privacy", "info.privacy")) }
            HorizontalDivider(color = Color(0x26FFFFFF))
            LinkRow(tr("info.terms"), Icons.Filled.Description) { context.openUrl(BuildConfig.TERMS_URL) }
        }

        GlassCard {
            Text(tr("info.consentStatus"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
            if (granted) {
                SecondaryText(tr("info.granted", DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(prefs.consentAt))), 15)
                GlassButton(tr("info.revoke"), color = Palette.danger) { confirmRevoke = true }
            } else {
                SecondaryText(tr("info.notGranted"), 15)
                PrimaryButton(tr("info.grant")) { showConsent = true }
            }
        }

        // Health Connect: facoltativo, solo con il consenso ai dati sanitari.
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Favorite, null, tint = Palette.accent); Spacer(Modifier.width(10.dp))
                Text(tr("android.health.title"), fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Switch(prefs.healthSyncEnabled && granted, { on ->
                    if (on) {
                        when {
                            health.isAvailable -> permissionLauncher.launch(health.permissions)
                            health.needsInstall -> runCatching { context.startActivity(health.installIntent()) }
                        }
                    } else scope.launch { health.disable() }
                }, enabled = granted && (health.isAvailable || health.needsInstall),
                    colors = SwitchDefaults.colors(checkedTrackColor = Palette.accent, checkedThumbColor = Color.White))
            }
            SecondaryText(tr(when {
                !granted -> "health.needConsent"
                health.needsInstall -> "android.health.install"
                !health.isAvailable -> "android.health.unavailable"
                else -> "android.health.note"
            }), 12)
        }

        GlassCard {
            Text(tr("info.sources"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
            SecondaryText(tr("info.sourcesExercises"))
            SecondaryText(tr("food.attribution"))
            SecondaryText(tr("info.sourcesLocal"))
        }

        GlassButton(tr("info.delete"), Modifier.fillMaxWidth(), color = Palette.danger) { confirmDelete = true }
        Text("MyGymHelper ${BuildConfig.VERSION_NAME}", fontSize = 11.sp, color = Color(0x66FFFFFF),
            modifier = Modifier.align(Alignment.CenterHorizontally))
    }

    if (showConsent) FullScreenDialog({ showConsent = false }) { ConsentScreen(onFinish = {}, onClose = { showConsent = false }) }

    if (confirmRevoke) DeleteDialog("info.revoke", { confirmRevoke = false }) {
        confirmRevoke = false
        // Revoca: azzera il consenso, cancella i dati sanitari sul telefono e spegne Health Connect.
        Graph.scope.launch { health.deleteOwnWorkouts(); health.disable() }   // scope dell'app: non si interrompe cambiando schermata
        prefs.revokeConsent()
        Graph.store.deleteHealthData()
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text(tr("info.deleteConfirm")) },
        confirmButton = { TextButton({
            confirmDelete = false
            // Prima si cancellano gli allenamenti scritti in Health Connect (servono ancora i permessi), poi il resto.
            Graph.scope.launch {               // scope dell'app: la cancellazione finisce anche se si cambia schermata
                health.deleteOwnWorkouts()
                health.disable()
                Graph.store.deleteHealthData()
                prefs.clearAll()          // ricompaiono subito disclaimer e consenso
            }
        }) { Text(tr("info.delete"), color = Palette.danger) } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text(tr("info.cancel")) } }
    )
}

@Composable
private fun LinkRow(title: String, icon: ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Palette.accent, modifier = Modifier.width(28.dp))
        Spacer(Modifier.width(14.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
        Icon(Icons.Filled.ChevronRight, null, tint = Palette.secondary)
    }
}

// ---------- Account ----------

/**
 * Account facoltativo: accesso con Google o e-mail (codice a 6 cifre), uscita ed eliminazione dell'account.
 * L'app funziona anche senza account; i dati sanitari non vengono mai caricati.
 */
@Composable
fun AccountScreen(nav: Navigator) {
    val context = LocalContext.current
    val account = Graph.account
    val scope = rememberCoroutineScope()
    val userId by account.userId.collectAsState()
    var email by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var codeSent by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var deleted by remember { mutableStateOf(false) }
    val cleanEmail = email.trim().lowercase()

    ScrollScreen(nav, back = true) {
        ScreenHeader(Icons.Filled.AccountCircle, tr("account.title"), tr("account.subtitle"))

        if (userId != null) {
            GlassCard {
                SecondaryText(tr("account.signedInAs"), 12)
                Text(account.email ?: "—", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                GlassButton(tr("account.signOut")) { scope.launch { account.signOut() } }
                HorizontalDivider(color = Color(0x26FFFFFF))
                GlassButton(tr("account.delete"), color = Palette.danger) { confirmDelete = true }
                SecondaryText(tr("android.account.deleteNote"), 12)
            }
        } else {
            SecondaryText(tr("account.why"), 15)
            if (account.googleConfigured) GlassButton(tr("account.google"), Modifier.fillMaxWidth()) {
                context.findActivity()?.let { activity -> scope.launch { account.signInWithGoogle(activity) } }
            }
            GlassCard {
                Text(tr("account.emailTitle"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), placeholder = { Text(tr("account.emailField")) },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
                if (codeSent) {
                    OutlinedTextField(code, { code = it.filter(Char::isDigit).take(6) }, Modifier.fillMaxWidth(),
                        placeholder = { Text(tr("account.codeField")) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    PrimaryButton(tr("account.verify"), enabled = code.length >= 6) {
                        scope.launch { account.verifyEmailCode(code.trim(), cleanEmail) }
                    }
                    SecondaryText(tr("account.codeSent"), 12)
                } else {
                    PrimaryButton(tr("account.sendCode"), enabled = cleanEmail.contains("@")) {
                        scope.launch { codeSent = account.sendEmailCode(cleanEmail) }
                    }
                }
            }
        }

        if (account.isWorking) CircularProgressIndicator(color = Palette.accent, modifier = Modifier.align(Alignment.CenterHorizontally))
        account.lastError?.let { error ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Warning, null, tint = Color(0xFFFF9F0A), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp)); Text(error, fontSize = 13.sp, color = Color(0xFFFF9F0A))
            }
        }
        if (deleted) Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CheckCircle, null, tint = Palette.accentSoft, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp)); Text(tr("account.deleted"), fontSize = 13.sp, color = Palette.accentSoft)
        }
        SecondaryText(tr("account.privacy"), 12)
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text(tr("account.deleteConfirm")) },
        text = { Text(tr("android.account.deleteMessage")) },
        confirmButton = { TextButton({
            confirmDelete = false
            scope.launch { deleted = account.deleteAccount() }
        }) { Text(tr("account.delete"), color = Palette.danger) } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text(tr("info.cancel")) } }
    )
}
