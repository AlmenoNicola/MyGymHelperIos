package app.mygymhelper

import android.app.Application
import android.content.Context
import app.mygymhelper.data.AppStore
import app.mygymhelper.data.CatalogRepository
import app.mygymhelper.data.Prefs
import app.mygymhelper.services.AccountService
import app.mygymhelper.services.BillingManager
import app.mygymhelper.services.HealthConnectService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Dispatchers

/** Punto di ingresso: crea i servizi una volta sola (equivalente degli oggetti iniettati in MyGymHelperApp.swift). */
class MyGymApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
    }
}

/** Servizi condivisi dell'app. */
object Graph {
    lateinit var context: Context; private set
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    lateinit var prefs: Prefs; private set
    lateinit var store: AppStore; private set
    lateinit var catalog: CatalogRepository; private set
    lateinit var billing: BillingManager; private set
    lateinit var account: AccountService; private set
    lateinit var health: HealthConnectService; private set

    fun init(app: Application) {
        context = app
        prefs = Prefs(app)
        store = AppStore(app, prefs, scope)
        account = AccountService(scope)
        catalog = CatalogRepository(app, account)
        billing = BillingManager(app, prefs, scope) { account.userId.value }
        health = HealthConnectService(app, prefs)
        billing.start()
        account.start()
    }
}
