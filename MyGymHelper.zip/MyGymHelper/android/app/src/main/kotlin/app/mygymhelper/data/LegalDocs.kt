package app.mygymhelper.data

import android.content.Context
import java.util.Locale

/** Blocco di un documento legale (titolo, intestazione, paragrafo, elenco puntato). */
data class LegalBlock(val kind: Kind, val text: String) {
    enum class Kind { TITLE, HEADING, PARAGRAPH, BULLET }
}

/**
 * Testi legali da assets/legal/<nome>.<lingua>.md (stessi file dell'app iOS).
 * Lingua del telefono, altrimenti inglese, poi italiano. "[nome dell'app]" diventa il nome dell'app.
 */
object LegalDocs {
    private fun read(context: Context, name: String, lang: String): String? =
        runCatching { context.assets.open("legal/$name.$lang.md").bufferedReader().use { it.readText() } }.getOrNull()

    fun isFallback(context: Context, name: String): Boolean =
        read(context, name, Locale.getDefault().language) == null

    fun load(context: Context, name: String, appName: String): List<LegalBlock> {
        val text = listOf(Locale.getDefault().language, "en", "it").firstNotNullOfOrNull { read(context, name, it) } ?: return emptyList()
        return parse(text.replace("[nome dell'app]", appName))
    }

    fun parse(text: String): List<LegalBlock> = text.lines().mapNotNull { raw ->
        val line = raw.trim()
        when {
            line.isEmpty() -> null
            line.startsWith("## ") -> LegalBlock(LegalBlock.Kind.HEADING, line.drop(3))
            line.startsWith("# ") -> LegalBlock(LegalBlock.Kind.TITLE, line.drop(2))
            line.startsWith("- ") -> LegalBlock(LegalBlock.Kind.BULLET, line.drop(2))
            else -> LegalBlock(LegalBlock.Kind.PARAGRAPH, line)
        }
    }
}
