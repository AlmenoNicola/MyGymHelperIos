package app.mygymhelper.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat

/** Stile grafico condiviso con l'app iOS: scuro, gradiente profondo, accento arancio, schede "vetro". */
object Palette {
    val accent = Color(0xFFFF6B29)
    val accentSoft = Color(0xFFFFA833)
    val accentText = Color(0xFFFF8A3D)
    val bgTop = Color(0xFF0F1224)
    val bgBottom = Color(0xFF29143D)
    val secondary = Color(0xADEBEBF5)
    val glass = Color(0x14FFFFFF)
    val glassBorder = Color(0x24FFFFFF)
    val danger = Color(0xFFFF6961)
    val sheet = Color(0xFF1C1830)
    val gradient = Brush.linearGradient(listOf(accentSoft, accent))
}

private val colors: ColorScheme = darkColorScheme(
    primary = Palette.accent, onPrimary = Color.White, secondary = Palette.accentSoft,
    background = Palette.bgTop, surface = Color(0xFF1C1A2E), onSurface = Color.White, onBackground = Color.White,
    surfaceVariant = Color(0xFF2C2A40), onSurfaceVariant = Palette.secondary, error = Palette.danger
)

@Composable
fun MyGymTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = colors, content = content)

/** Sfondo comune: gradiente e due aloni sfocati. */
@Composable
fun AppBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Palette.bgTop, Palette.bgBottom)))) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Brush.radialGradient(listOf(Palette.accent.copy(alpha = 0.30f), Color.Transparent),
                center = Offset(size.width * 0.95f, size.height * 0.02f), radius = size.width * 0.75f),
                radius = size.width * 0.75f, center = Offset(size.width * 0.95f, size.height * 0.02f))
            drawCircle(Brush.radialGradient(listOf(Color(0x4D9628BE), Color.Transparent),
                center = Offset(size.width * 0.05f, size.height * 0.85f), radius = size.width * 0.8f),
                radius = size.width * 0.8f, center = Offset(size.width * 0.05f, size.height * 0.85f))
        }
        content()
    }
}

/** Scheda in vetro con angoli morbidi. */
@Composable
fun GlassCard(modifier: Modifier = Modifier, padding: PaddingValues = PaddingValues(20.dp),
              onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    var m = modifier.fillMaxWidth().clip(shape).background(Palette.glass).border(1.dp, Palette.glassBorder, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(padding), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

/** Titolo grande di schermata con icona su cerchio in gradiente. */
@Composable
fun ScreenHeader(icon: ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(60.dp).shadow(14.dp, CircleShape, ambientColor = Palette.accent, spotColor = Palette.accent)
            .clip(CircleShape).background(Palette.gradient), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, lineHeight = 32.sp)
            Text(subtitle, fontSize = 15.sp, color = Palette.secondary)
        }
    }
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null, onClick: () -> Unit) {
    Button(onClick, modifier.fillMaxWidth(), enabled = enabled, shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = Palette.accent, contentColor = Color.White),
        contentPadding = PaddingValues(vertical = 16.dp)) {
        if (icon != null) { Icon(icon, null); Spacer(Modifier.width(8.dp)) }
        Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, color: Color = Color.White, icon: ImageVector? = null,
                enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(onClick, modifier, enabled = enabled, shape = CircleShape,
        border = BorderStroke(1.dp, Palette.glassBorder),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color(0x1FFFFFFF), contentColor = color)) {
        if (icon != null) { Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

/** Riga con titolo e contatore meno/più. */
@Composable
fun CounterRow(title: String, value: Int, range: IntRange, step: Int = 1, display: String = value.toString(), onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        RoundStepButton(Icons.Filled.Remove, "−") { onChange((value - step).coerceAtLeast(range.first)) }
        Text(display, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.width(72.dp))
        RoundStepButton(Icons.Filled.Add, "+") { onChange((value + step).coerceAtMost(range.last)) }
    }
}

/** Riga del peso con passo di 1,25 kg (0 = corpo libero). */
@Composable
fun WeightRow(title: String, value: Double, onChange: (Double) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        RoundStepButton(Icons.Filled.Remove, "−") { onChange((value - 1.25).coerceAtLeast(0.0)) }
        Text(if (value > 0) kgText(value) else tr("setup.bodyweight"), fontSize = 18.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.width(96.dp))
        RoundStepButton(Icons.Filled.Add, "+") { onChange((value + 1.25).coerceAtMost(500.0)) }
    }
}

@Composable
private fun RoundStepButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    FilledTonalIconButton(onClick, Modifier.size(44.dp),
        colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Color(0x1FFFFFFF), contentColor = Color.White)) {
        Icon(icon, label)
    }
}

/** "62,5 kg" con il separatore decimale della lingua del telefono. */
fun kgText(v: Double): String = NumberFormat.getNumberInstance().apply { maximumFractionDigits = 2 }.format(v) + " kg"

/** Anello di avanzamento (ripetizioni o pausa). */
@Composable
fun ProgressRing(progress: Float, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val animated by animateFloatAsState(progress.coerceIn(0f, 1f), label = "ring")
    Box(modifier.size(270.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(11.dp)) {
            val stroke = 22.dp.toPx()
            drawArc(Color(0x1AFFFFFF), 0f, 360f, false, style = Stroke(stroke))
            drawArc(Palette.gradient, -90f, 360f * animated, false, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        content()
    }
}

/** Avviso di funzione disponibile con un piano superiore; tocco: apre i Piani. */
@Composable
fun LockedNote(text: String, onOpenPlans: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().let { if (onOpenPlans != null) it.clickable(onClick = onOpenPlans) else it },
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Lock, null, tint = Palette.secondary, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 13.sp, color = Palette.secondary, modifier = Modifier.weight(1f))
        if (onOpenPlans != null) Text(tr("plans.see"), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Palette.accentSoft)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(CircleShape).background(if (selected) Palette.gradient else Brush.linearGradient(listOf(Color(0x1AFFFFFF), Color(0x1AFFFFFF))))
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Color.White)
    }
}

@Composable
fun SecondaryText(text: String, size: Int = 13) = Text(text, fontSize = size.sp, color = Palette.secondary)
