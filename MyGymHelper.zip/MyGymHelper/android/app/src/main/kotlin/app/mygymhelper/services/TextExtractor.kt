package app.mygymhelper.services

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.nio.charset.Charset

/**
 * Estrae il testo da schede in PDF, foto o file di testo, tutto sul telefono
 * (PdfRenderer e ML Kit, modello incluso nell'app: nessun server). L'utente conferma sempre nella revisione.
 */
object TextExtractor {
    class ExtractException(message: String) : Exception(message)

    /** Pagine massime da riconoscere in un PDF (per non bloccare il telefono). */
    const val MAX_OCR_PAGES = 10

    suspend fun fromUri(context: Context, uri: Uri): String {
        val type = context.contentResolver.getType(uri) ?: ""
        val name = uri.lastPathSegment?.lowercase() ?: ""
        return when {
            type == "application/pdf" || name.endsWith(".pdf") -> fromPdf(context, uri)
            type.startsWith("image/") -> fromImage(context, uri)
            else -> withContext(Dispatchers.IO) {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw ExtractException("unreadable")
                val utf8 = runCatching { Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(bytes)).toString() }.getOrNull()
                (utf8 ?: String(bytes, Charset.forName("ISO-8859-1"))).also { if (it.isBlank()) throw ExtractException("empty") }
            }
        }
    }

    /** Foto: InputImage.fromFilePath legge anche la rotazione EXIF. */
    suspend fun fromImage(context: Context, uri: Uri): String {
        val image = withContext(Dispatchers.IO) { InputImage.fromFilePath(context, uri) }
        return recognize(image)
    }

    /**
     * PDF: ogni pagina viene disegnata come immagine (lato lungo 2000 px) e letta con l'OCR.
     * (Il testo incorporato si potrebbe leggere direttamente solo da Android 15: per ora si usa l'OCR per tutte le versioni.)
     */
    private suspend fun fromPdf(context: Context, uri: Uri): String {
        val pages = mutableListOf<String>()
        val pfd = withContext(Dispatchers.IO) { context.contentResolver.openFileDescriptor(uri, "r") } ?: throw ExtractException("unreadable")
        pfd.use { fd ->
            PdfRenderer(fd).use { renderer ->
                for (i in 0 until minOf(renderer.pageCount, MAX_OCR_PAGES)) {
                    val bitmap = withContext(Dispatchers.Default) {
                        renderer.openPage(i).use { page ->
                            val scale = 2000f / maxOf(page.width, page.height, 1)
                            val bmp = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1),
                                (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)        // le pagine PDF hanno sfondo trasparente
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bmp
                        }
                    }
                    pages += recognize(InputImage.fromBitmap(bitmap, 0))
                    bitmap.recycle()
                }
            }
        }
        val text = pages.joinToString("\n")
        if (text.isBlank()) throw ExtractException("empty")
        return text
    }

    /** OCR con ML Kit (alfabeto latino: italiano, inglese e simili). Righe in ordine di lettura. */
    private suspend fun recognize(image: InputImage): String {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val result: Text = recognizer.process(image).await()
            // Dall'alto verso il basso; le righe alla stessa altezza (es. "Panca" | "4x8") si leggono da sinistra a destra.
            val sorted = result.textBlocks.flatMap { it.lines }.sortedBy { it.boundingBox?.centerY() ?: 0 }
            val rows = mutableListOf<MutableList<Text.Line>>()
            for (line in sorted) {
                val y = line.boundingBox?.centerY() ?: 0
                val row = rows.lastOrNull()
                val first = row?.first()?.boundingBox
                if (row != null && first != null && kotlin.math.abs(first.centerY() - y) <= first.height() / 2) row += line
                else rows += mutableListOf(line)
            }
            return rows.joinToString("\n") { row -> row.sortedBy { it.boundingBox?.left ?: 0 }.joinToString(" ") { it.text } }
        } finally {
            recognizer.close()
        }
    }
}
