package app.mygymhelper.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mygymhelper.Graph
import app.mygymhelper.core.BodyRegion
import app.mygymhelper.core.CatalogExercise
import app.mygymhelper.core.CoachingSupport
import app.mygymhelper.core.ExerciseRecommender
import app.mygymhelper.core.Feature
import app.mygymhelper.core.FeatureGate
import app.mygymhelper.core.Mechanic
import app.mygymhelper.core.MuscleGroup
import app.mygymhelper.ui.GlassButton
import app.mygymhelper.ui.GlassCard
import app.mygymhelper.ui.Navigator
import app.mygymhelper.ui.Palette
import app.mygymhelper.ui.PrimaryButton
import app.mygymhelper.ui.Screen
import app.mygymhelper.ui.ScreenHeader
import app.mygymhelper.ui.ScrollScreen
import app.mygymhelper.ui.SecondaryText
import app.mygymhelper.ui.tr
import app.mygymhelper.ui.trText
import java.util.Locale

// ---------- Nomi tradotti ----------

/** Nome tradotto del muscolo (stesse chiavi dell'app iOS: "muscle.<raw>"). */
@Composable
fun muscleTitle(m: MuscleGroup): String = tr("muscle." + m.raw)

@Composable
fun regionTitle(r: BodyRegion): String = tr("region." + r.raw)

@Composable
fun musclesLine(list: List<MuscleGroup>): String {
    val context = LocalContext.current
    return list.joinToString(", ") { trText(context, "muscle." + it.raw) }
}

enum class BodySide(val titleKey: String) { FRONT("map.front"), BACK("map.back") }

// ---------- Mappa del corpo ----------

private class Zone(val muscle: MuscleGroup, val cx: Float, val cy: Float, val w: Float, val h: Float, val mirrored: Boolean = true)

private val frontZones = listOf(
    Zone(MuscleGroup.SHOULDERS, 27f, 47f, 17f, 17f), Zone(MuscleGroup.CHEST, 41f, 58f, 16f, 17f),
    Zone(MuscleGroup.ABS, 50f, 86f, 15f, 30f, mirrored = false), Zone(MuscleGroup.OBLIQUES, 37f, 88f, 7f, 28f),
    Zone(MuscleGroup.BICEPS, 18f, 70f, 10f, 24f), Zone(MuscleGroup.FOREARMS, 14f, 98f, 9f, 28f),
    Zone(MuscleGroup.QUADS, 40f, 142f, 17f, 50f), Zone(MuscleGroup.CALVES, 39f, 196f, 12f, 36f)
)
private val backZones = listOf(
    Zone(MuscleGroup.TRAPS, 50f, 46f, 22f, 16f, mirrored = false), Zone(MuscleGroup.SHOULDERS, 27f, 50f, 16f, 16f),
    Zone(MuscleGroup.LATS, 40f, 76f, 16f, 30f), Zone(MuscleGroup.LOWER_BACK, 50f, 104f, 18f, 16f, mirrored = false),
    Zone(MuscleGroup.TRICEPS, 18f, 70f, 10f, 24f), Zone(MuscleGroup.FOREARMS, 14f, 98f, 9f, 28f),
    Zone(MuscleGroup.GLUTES, 42f, 128f, 17f, 17f), Zone(MuscleGroup.HAMSTRINGS, 40f, 158f, 16f, 32f),
    Zone(MuscleGroup.CALVES, 39f, 200f, 12f, 32f)
)

/** Mappa del corpo schematica (disegnata da noi, coordinate su 100×225 come su iOS): tocca un muscolo per sceglierlo. */
@Composable
fun BodyMap(side: BodySide, selected: Set<MuscleGroup>, modifier: Modifier = Modifier, onChange: (Set<MuscleGroup>) -> Unit) {
    val haptics = LocalHapticFeedback.current
    BoxWithConstraints(modifier.aspectRatio(100f / 225f)) {
        val s = maxWidth / 100f
        // Sagoma
        Blob(s, 50f, 14f, 22f, 22f, 11f)
        Blob(s, 50f, 30f, 8f, 8f, 6f)
        Blob(s, 50f, 80f, 46f, 78f, 10f)
        Blob(s, 17f, 86f, 12f, 78f, 6f)
        Blob(s, 83f, 86f, 12f, 78f, 6f)
        Blob(s, 40f, 168f, 20f, 112f, 8f)
        Blob(s, 60f, 168f, 20f, 112f, 8f)
        val zones = if (side == BodySide.FRONT) frontZones else backZones
        zones.forEach { z ->
            val label = muscleTitle(z.muscle)
            val positions = if (z.mirrored) listOf(z.cx, 100f - z.cx) else listOf(z.cx)
            positions.forEach { cx ->
                val on = z.muscle in selected
                val radius = s * (minOf(z.w, z.h) / 2.2f)
                val shape = RoundedCornerShape(radius)
                Box(
                    Modifier.offset(x = s * (cx - z.w / 2), y = s * (z.cy - z.h / 2)).size(s * z.w, s * z.h)
                        .clip(shape)
                        .background(if (on) Palette.gradient else androidx.compose.ui.graphics.SolidColor(Color(0x24FFFFFF)))
                        .border(1.dp, if (on) Color(0x99FFFFFF) else Color(0x40FFFFFF), shape)
                        .semantics { contentDescription = label; this.selected = on }
                        .clickable {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onChange(if (on) selected - z.muscle else selected + z.muscle)
                        }
                )
            }
        }
    }
}

@Composable
private fun Blob(s: Dp, cx: Float, cy: Float, w: Float, h: Float, r: Float) {
    Box(Modifier.offset(x = s * (cx - w / 2), y = s * (cy - h / 2)).size(s * w, s * h)
        .clip(RoundedCornerShape(s * r)).background(Color(0x0FFFFFFF)))
}

/** Blocchi predefiniti (braccia, gambe, torace...): un tocco seleziona tutti i muscoli della zona. */
@Composable
fun RegionChips(selected: Set<MuscleGroup>, onChange: (Set<MuscleGroup>) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        BodyRegion.entries.forEach { region ->
            val all = region.muscles.toSet()
            val on = selected.containsAll(all)
            app.mygymhelper.ui.Chip(regionTitle(region), on) { onChange(if (on) selected - all else selected + all) }
        }
    }
}

// ---------- Catalogo ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExercisesScreen(nav: Navigator) {
    val tier by Graph.billing.tier.collectAsState()
    val all by Graph.catalog.all.collectAsState()
    val data by Graph.store.data.collectAsState()
    var side by rememberSaveable { mutableStateOf(BodySide.FRONT) }
    var selected by remember { mutableStateOf(setOf<MuscleGroup>()) }
    var query by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(Unit) { Graph.catalog.refreshRemote() }

    val pool = remember(all, tier) { Graph.catalog.visible(tier) }
    val filtered = pool.filter { ex ->
        (selected.isEmpty() || ex.primary.any { it in selected }) && (query.isBlank() || ex.name.contains(query.trim(), ignoreCase = true))
    }
    val recommendations = remember(pool, selected, data.sessions, tier) {
        if (!FeatureGate.isAvailable(Feature.FIXED_COACHING, tier)) emptyList()
        else ExerciseRecommender.recommend(pool, selected, CoachingSupport.historyEntries(data.sessions, all), limit = 3)
    }

    ScrollScreen(nav) {
        ScreenHeader(Icons.Filled.SportsGymnastics, tr("ex.title"), tr("ex.subtitle"))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassButton(tr("ex.lists"), Modifier.weight(1f), icon = Icons.AutoMirrored.Filled.List) { nav.push(Screen.Lists) }
            GlassButton(tr("ex.plans"), Modifier.weight(1f), icon = Icons.Filled.Description) { nav.push(Screen.TrainingPlans) }
        }
        GlassCard {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                BodySide.entries.forEachIndexed { i, s ->
                    SegmentedButton(selected = side == s, onClick = { side = s },
                        shape = SegmentedButtonDefaults.itemShape(i, BodySide.entries.size),
                        colors = SegmentedButtonDefaults.colors(activeContainerColor = Palette.accent, activeContentColor = Color.White,
                            inactiveContainerColor = Color.Transparent, inactiveContentColor = Color.White)) { Text(tr(s.titleKey)) }
                }
            }
            Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                BodyMap(side, selected, Modifier.height(300.dp)) { selected = it }
            }
            RegionChips(selected) { selected = it }
            if (selected.isNotEmpty()) TextButton({ selected = emptySet() }) { Text(tr("ex.clear"), color = Palette.accentText, fontSize = 13.sp) }
        }

        if (recommendations.isNotEmpty()) {
            GlassCard {
                Text(tr("ex.recommended"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                recommendations.forEach { rec ->
                    Column(Modifier.fillMaxWidth().clickable { nav.push(Screen.ExerciseDetail(rec.exercise)) }) {
                        Text(rec.exercise.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(tr(rec.reasonKey), fontSize = 12.sp, color = Palette.accentSoft)
                    }
                }
            }
        }

        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text(tr("ex.search")) },
            singleLine = true, shape = CircleShape)

        if (!FeatureGate.isAvailable(Feature.CATALOG_FULL, tier)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Lock, null, tint = Palette.secondary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp)); SecondaryText(tr("ex.freeLimit"))
            }
        }
        if (filtered.isEmpty()) GlassCard(padding = PaddingValues(16.dp)) { SecondaryText(tr("ex.none"), 15) }
        filtered.forEach { ex -> ExerciseRow(ex) { nav.push(Screen.ExerciseDetail(ex)) } }
    }
}

@Composable
fun ExerciseRow(exercise: CatalogExercise, onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    GlassCard(padding = PaddingValues(16.dp), onClick = if (onLongClick == null) onClick else null,
        modifier = if (onLongClick != null) Modifier.longPressable(onClick, onLongClick) else Modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(exercise.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                SecondaryText(musclesLine(exercise.primary), 12)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = Palette.secondary)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
fun Modifier.longPressable(onClick: () -> Unit, onLongClick: () -> Unit): Modifier =
    this.clip(RoundedCornerShape(28.dp)).combinedClickable(onClick = onClick, onLongClick = onLongClick)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ExerciseDetailScreen(nav: Navigator, exercise: CatalogExercise) {
    val tier by Graph.billing.tier.collectAsState()
    var showLists by remember { mutableStateOf(false) }
    val canSaveLists = FeatureGate.isAvailable(Feature.SAVED_EXERCISE_LISTS, tier)

    ScrollScreen(nav, back = true) {
        ScreenHeader(Icons.Filled.FitnessCenter, exercise.name, musclesLine(exercise.primary))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(tr(if (exercise.mechanic == Mechanic.COMPOUND) "mech.compound" else "mech.isolation"), Palette.accent.copy(alpha = 0.35f), bold = true)
            if (exercise.equipment.isNotBlank()) Pill(exercise.equipment.replaceFirstChar { it.titlecase(Locale.getDefault()) }, Color(0x1AFFFFFF), bold = true)
            exercise.secondary.forEach { Pill(muscleTitle(it), Color(0x0FFFFFFF)) }
        }
        if (exercise.steps.isNotEmpty()) {
            GlassCard {
                Text(tr("ex.how"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                exercise.steps.forEachIndexed { i, step ->
                    Row {
                        Text("${i + 1}", fontWeight = FontWeight.Bold, color = Palette.accent, modifier = Modifier.width(22.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(step, fontSize = 15.sp)
                    }
                }
            }
        }
        PrimaryButton(tr("ex.train"), icon = Icons.Filled.PlayArrow) { nav.push(Screen.WorkoutSetupFor(exercise)) }
        if (canSaveLists) GlassButton(tr("ex.addToList"), Modifier.fillMaxWidth(), icon = Icons.AutoMirrored.Filled.PlaylistAdd) { showLists = true }
        else app.mygymhelper.ui.LockedNote(tr("ex.listsLocked")) { nav.openPlans() }
    }
    if (showLists) AddToListSheet(exercise) { showLists = false }
}

@Composable
private fun Pill(text: String, background: Color, bold: Boolean = false) {
    Text(text, fontSize = 12.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.clip(CircleShape).background(background).padding(horizontal = 12.dp, vertical = 6.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddToListSheet(exercise: CatalogExercise, onDismiss: () -> Unit) {
    val data by Graph.store.data.collectAsState()
    var newName by remember { mutableStateOf("") }
    ModalBottomSheet(onDismiss, containerColor = Palette.sheet) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(tr("ex.addToList"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (!Graph.prefs.consentGranted) {
                GlassCard { Text(tr("lists.needConsent")) }
            } else {
                data.lists.sortedBy { it.createdAt }.forEach { list ->
                    GlassCard(padding = PaddingValues(16.dp), onClick = { Graph.store.addToList(list.id, exercise.id); onDismiss() }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(list.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (exercise.id in list.exerciseIds) Icon(Icons.Filled.CheckCircle, null, tint = Palette.accent)
                        }
                    }
                }
                GlassCard(padding = PaddingValues(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(newName, { newName = it }, Modifier.weight(1f), placeholder = { Text(tr("lists.newName")) }, singleLine = true)
                        Spacer(Modifier.width(10.dp))
                        TextButton({
                            val name = newName.trim()
                            if (name.isNotEmpty()) { Graph.store.createList(name, listOf(exercise.id)); onDismiss() }
                        }) { Text(tr("lists.create"), color = Palette.accentText, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            GlassButton(tr("info.cancel"), onClick = onDismiss)
        }
    }
}

// ---------- Elenchi ----------

@Composable
fun ExerciseListsScreen(nav: Navigator) {
    val tier by Graph.billing.tier.collectAsState()
    val all by Graph.catalog.all.collectAsState()
    val data by Graph.store.data.collectAsState()
    val context = LocalContext.current
    val pool = remember(all, tier) { Graph.catalog.visible(tier) }
    val canSave = FeatureGate.isAvailable(Feature.SAVED_EXERCISE_LISTS, tier)
    var showNew by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<String?>(null) }

    ScrollScreen(nav, back = true) {
        ScreenHeader(Icons.AutoMirrored.Filled.List, tr("lists.title"), tr("lists.subtitle"))
        Text(tr("lists.presets"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
        BodyRegion.entries.forEach { region ->
            val items = pool.filter { ex -> ex.primary.any { it.region == region } }
            if (items.isNotEmpty()) {
                val title = regionTitle(region)
                GlassCard(padding = PaddingValues(16.dp), onClick = { nav.push(Screen.Collection(title, items)) }) {
                    Row { Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); SecondaryText("${items.size}", 15) }
                }
            }
        }
        Text(tr("lists.mine"), fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(top = 8.dp))
        when {
            !canSave -> app.mygymhelper.ui.LockedNote(tr("ex.listsLocked")) { nav.openPlans() }
            !Graph.prefs.consentGranted -> app.mygymhelper.ui.LockedNote(tr("lists.needConsent"), null)
            else -> {
                data.lists.sortedBy { it.createdAt }.forEach { list ->
                    GlassCard(padding = PaddingValues(16.dp),
                        modifier = Modifier.longPressable(
                            onClick = { nav.push(Screen.Collection(list.name, list.exerciseIds.mapNotNull { Graph.catalog.exercise(it) })) },
                            onLongClick = { toDelete = list.id })) {
                        Row { Text(list.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); SecondaryText("${list.exerciseIds.size}", 15) }
                    }
                }
                if (data.lists.isNotEmpty()) SecondaryText(trText(context, "android.longPressDelete"), 12)
                GlassButton(tr("lists.new"), Modifier.fillMaxWidth(), icon = Icons.Filled.Add) { showNew = true }
            }
        }
    }

    if (showNew) AlertDialog(
        onDismissRequest = { showNew = false; newName = "" },
        title = { Text(tr("lists.new")) },
        text = { OutlinedTextField(newName, { newName = it }, placeholder = { Text(tr("lists.newName")) }, singleLine = true) },
        confirmButton = { TextButton({ newName.trim().takeIf { it.isNotEmpty() }?.let { Graph.store.createList(it) }; newName = ""; showNew = false }) { Text(tr("lists.create")) } },
        dismissButton = { TextButton({ newName = ""; showNew = false }) { Text(tr("info.cancel")) } }
    )
    toDelete?.let { id ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(tr("history.delete")) },
            confirmButton = { TextButton({ Graph.store.deleteList(id); toDelete = null }) { Text(tr("history.delete"), color = Palette.danger) } },
            dismissButton = { TextButton({ toDelete = null }) { Text(tr("info.cancel")) } }
        )
    }
}

@Composable
fun ExerciseCollectionScreen(nav: Navigator, title: String, exercises: List<CatalogExercise>) {
    ScrollScreen(nav, back = true, title = title) {
        if (exercises.isEmpty()) GlassCard(padding = PaddingValues(16.dp)) { SecondaryText(tr("ex.none"), 15) }
        exercises.forEach { ex -> ExerciseRow(ex) { nav.push(Screen.ExerciseDetail(ex)) } }
    }
}
