package app.mygymhelper.services

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import app.mygymhelper.core.PrincipalAxis
import app.mygymhelper.core.RepDetector
import app.mygymhelper.core.Vector3
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Legge l'accelerazione lineare (gravità già rimossa) a 50 Hz, trova l'asse dominante (calibrazione di 3 s)
 * e conta le ripetizioni con il RepDetector del core. Come MotionService.swift: i calcoli girano su un thread
 * dedicato, lo stato per la UI esce sul thread principale. Valori in g (m/s² diviso 9,80665) come su iPhone.
 */
class MotionService(context: Context) : SensorEventListener {
    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor: Sensor? = manager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val main = Handler(Looper.getMainLooper())

    // Stato del thread dei sensori
    private val calibration = ArrayList<Pair<Double, Vector3>>()
    private var axis: Vector3? = null
    private var detector = RepDetector()
    @Volatile private var counting = false
    private var lastCount = -1
    private var lastLow = false

    private val _repCount = MutableStateFlow(0)
    val repCount: StateFlow<Int> = _repCount.asStateFlow()
    private val _calibrating = MutableStateFlow(true)
    val calibrating: StateFlow<Boolean> = _calibrating.asStateFlow()
    private val _lowConfidence = MutableStateFlow(false)
    val lowConfidence: StateFlow<Boolean> = _lowConfidence.asStateFlow()
    @Volatile var averagePeak = 0.0; private set
    val isAvailable: Boolean get() = sensor != null

    /** Chiamato sul thread principale quando cambia il numero di ripetizioni della serie. */
    var onRepCount: ((Int) -> Unit)? = null

    fun start() {
        val s = sensor ?: return
        val t = HandlerThread("motion").also { it.start() }
        thread = t
        handler = Handler(t.looper)
        manager.registerListener(this, s, 20_000, handler)   // 20 ms = 50 Hz
    }

    fun stop() {
        manager.unregisterListener(this)
        thread?.quitSafely(); thread = null; handler = null
    }

    /** Nuova serie: azzera il conteggio, mantiene l'asse calibrato. */
    fun beginSet() {
        handler?.post {
            detector = RepDetector(); counting = true; lastCount = -1; lastLow = false
            publish(0, false, 0.0)
        } ?: run { counting = true }
    }

    /** Smette di contare (pausa). */
    fun pauseCounting() { handler?.post { counting = false } ?: run { counting = false } }

    override fun onSensorChanged(event: SensorEvent) {
        if (!counting) return
        val g = SensorManager.GRAVITY_EARTH.toDouble()
        val v = Vector3(event.values[0] / g, event.values[1] / g, event.values[2] / g)
        val t = event.timestamp / 1e9
        val a = axis
        if (a == null) {
            calibration.add(t to v)
            while (calibration.isNotEmpty() && t - calibration.first().first > CALIBRATION_S) calibration.removeAt(0)
            val first = calibration.firstOrNull() ?: return
            if (t - first.first < CALIBRATION_S * 0.95) return
            // Se l'utente non si è ancora mosso la finestra scorre e si riprova: evita un asse casuale.
            if ((calibration.maxOfOrNull { it.second.length } ?: 0.0) < MIN_MOTION) return
            val found = PrincipalAxis.estimate(calibration.map { it.second }) ?: Vector3(1.0, 0.0, 0.0)
            axis = found
            for ((st, sv) in calibration) detector.process(sv.dot(found), st)   // riesame della finestra
            calibration.clear()
            main.post { _calibrating.value = false }
        } else {
            detector.process(v.dot(a), t)
        }
        val count = detector.count
        val low = detector.signalConfidence < 0.4
        if (count == lastCount && low == lastLow) return
        lastCount = count; lastLow = low
        val peaks = detector.events.map { it.peakAmplitude }
        publish(count, low, if (peaks.isEmpty()) 0.0 else peaks.average())
    }

    private fun publish(count: Int, low: Boolean, peak: Double) {
        averagePeak = peak
        main.post {
            _repCount.value = count
            _lowConfidence.value = low
            onRepCount?.invoke(count)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    companion object {
        private const val CALIBRATION_S = 3.0
        private const val MIN_MOTION = 0.15
    }
}
