package app.mygymhelper.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mygymhelper.BuildConfig
import app.mygymhelper.Graph
import app.mygymhelper.core.ActivityLevel
import app.mygymhelper.core.BiologicalSex
import app.mygymhelper.core.BmiCalculator
import app.mygymhelper.core.BmiCategory
import app.mygymhelper.core.DailyTargets
import app.mygymhelper.core.DietPlanner
import app.mygymhelper.core.DietType
import app.mygymhelper.core.Disclaimer
import app.mygymhelper.core.Feature
import app.mygymhelper.core.FeatureGate
import app.mygymhelper.core.FoodFacts
import app.mygymhelper.core.FoodProduct
import app.mygymhelper.core.Goal
import app.mygymhelper.core.HealthProfile
import app.mygymhelper.core.NutritionCalculator
import app.mygymhelper.core.ParsedMeal
import app.mygymhelper.core.SubscriptionTier
import app.mygymhelper.ui.Chip
import app.mygymhelper.ui.CounterRow
import app.mygymhelper.ui.GlassButton
import app.mygymhelper.ui.GlassCard
import app.mygymhelper.ui.LockedNote
import app.mygymhelper.ui.Navigator
import app.mygymhelper.ui.Palette
import app.mygymhelper.ui.Screen
import app.mygymhelper.ui.ScreenHeader
import app.mygymhelper.ui.ScrollScreen
import app.mygymhelper.ui.SecondaryText
import app.mygymhelper.ui.tr
import app.mygymhelper.ui.trText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Nutrizione: profilo (dati sanitari, solo con consenso), BMI (Free), obiettivi di calorie e macro (Mid+),
 * piano dei pasti (Full), scheda del nutrizionista (Full), ricerca alimenti (Mid+).
 * Indicazioni generali: non sostituisce un nutrizionista e non considera allergie o patologie.
 */
@Composable
fun NutritionScreen(nav: Navigator) {
    val tier by Graph.billing.tier.collectAsState()
    val data by Graph.store.data.collectAsState()
    val consent = Graph.prefs.consentGranted

    // Il profilo si crea solo dopo il consenso (contiene dati sanitari).
    LaunchedEffect(consent, data.profile == null) { if (consent && data.profile == null) Graph.store.ensureProfile() }

    ScrollScreen(nav) {
        ScreenHeader(Icons.Filled.Restaurant, tr("nutrition.title"), tr("nutrition.subtitle"))
        val profile = data.profile
        when {
            !consent -> NeedConsentCard("consent.locked")
            profile == null -> CircularProgressIndicator(color = Palette.accent, modifier = Modifier.align(Alignment.CenterHorizontally))
            else -> NutritionContent(nav, profile, tier)
        }
        SecondaryText(tr(Disclaimer.BODY_KEY), 13)
    }
}

private fun dietsOf(p: HealthProfile): Set<DietType> =
    p.diets.mapNotNull { DietType.from(it) }.toSet().ifEmpty { setOf(DietType.OMNIVORE) }

@Composable
private fun NutritionContent(nav: Navigator, profile: HealthProfile, tier: SubscriptionTier) {
    val importer = rememberPlanImportModel()
    var editingPlan by remember { mutableStateOf<NutritionDraft?>(null) }
    val targets = NutritionCalculator.targets(BiologicalSex.from(profile.sex), profile.weightKg, profile.heightCm,
        profile.age, ActivityLevel.from(profile.activity), Goal.from(profile.goal))

    ProfileCard(profile)
    BmiCard(profile.weightKg, profile.heightCm)

    if (FeatureGate.isAvailable(Feature.GENERAL_NUTRITION_ADVICE, tier)) {
        TargetsCard(targets)
        GlassButton(tr("food.search.open"), Modifier.fillMaxWidth(), icon = Icons.Filled.Search) { nav.push(Screen.FoodSearch) }
    } else GlassCard(padding = PaddingValues(16.dp)) { LockedNote(tr("nutrition.targetsLocked")) { nav.openPlans() } }

    if (FeatureGate.isAvailable(Feature.DIET_PLANS, tier)) MealPlanCard(targets, dietsOf(profile))
    else GlassCard(padding = PaddingValues(16.dp)) { LockedNote(tr("nutrition.mealsLocked")) { nav.openPlans() } }

    if (FeatureGate.isAvailable(Feature.UPLOAD_PLANS, tier)) {
        NutritionistCard { editingPlan = it }
        ImportButtons(importer, PlanKind.NUTRITION)
    }

    importer.nutritionDraft?.let { NutritionPlanReview(it) { importer.nutritionDraft = null } }
    editingPlan?.let { NutritionPlanReview(it) { editingPlan = null } }
}

// ---------- Profilo ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProfileCard(profile: HealthProfile) {
    val store = Graph.store
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var healthMessage by remember { mutableStateOf<String?>(null) }
    val diets = dietsOf(profile)

    GlassCard {
        Text(tr("profile.title"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Segmented(listOf("male" to tr("profile.male"), "female" to tr("profile.female")), profile.sex) { v -> store.updateProfile { it.copy(sex = v) } }
        CounterRow(tr("profile.age"), profile.age, 18..100) { v -> store.updateProfile { it.copy(age = v) } }
        CounterRow(tr("bmi.weight"), profile.weightKg.roundToInt(), 30..250) { v -> store.updateProfile { it.copy(weightKg = v.toDouble()) } }
        CounterRow(tr("bmi.height"), profile.heightCm.roundToInt(), 120..230) { v -> store.updateProfile { it.copy(heightCm = v.toDouble()) } }
        if (Graph.prefs.healthSyncEnabled) {
            // Legge da Health Connect l'ultimo peso e l'ultima altezza (solo su richiesta dell'utente).
            GlassButton(tr("android.health.import"), Modifier.fillMaxWidth(), icon = Icons.Filled.Favorite) {
                scope.launch {
                    val w = Graph.health.latestWeightKg()
                    val h = Graph.health.latestHeightCm()
                    store.updateProfile { p ->
                        p.copy(weightKg = w?.let { it.roundToInt().coerceIn(30, 250).toDouble() } ?: p.weightKg,
                            heightCm = h?.let { it.roundToInt().coerceIn(120, 230).toDouble() } ?: p.heightCm)
                    }
                    healthMessage = trText(context, if (w == null && h == null) "android.health.noData" else "android.health.imported")
                }
            }
            healthMessage?.let { SecondaryText(it, 12) }
        }
        DropdownField(tr("profile.activity"),
            listOf(ActivityLevel.SEDENTARY to "activity.sedentary", ActivityLevel.LIGHT to "activity.light",
                ActivityLevel.MODERATE to "activity.moderate", ActivityLevel.HIGH to "activity.high",
                ActivityLevel.VERY_HIGH to "activity.veryHigh").map { it.first.factor to tr(it.second) },
            ActivityLevel.from(profile.activity).factor) { v -> store.updateProfile { it.copy(activity = v) } }
        Text(tr("profile.goal"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Segmented(Goal.entries.map { it.raw to tr("goal." + it.raw) }, profile.goal) { v -> store.updateProfile { it.copy(goal = v) } }
        Text(tr("profile.diets"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DietType.entries.forEach { diet ->
                Chip(tr("diet." + diet.raw), diet in diets) {
                    // Onnivora esclude le altre diete; le altre si possono combinare (es. vegana + senza glutine).
                    var set = diets
                    set = if (diet == DietType.OMNIVORE) setOf(DietType.OMNIVORE) else {
                        val s = (set - DietType.OMNIVORE).let { if (diet in it) it - diet else it + diet }
                        s.ifEmpty { setOf(DietType.OMNIVORE) }
                    }
                    store.updateProfile { p -> p.copy(diets = DietType.entries.filter { it in set }.map { it.raw }) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { i, (value, label) ->
            SegmentedButton(selected = value == selected, onClick = { onSelect(value) },
                shape = SegmentedButtonDefaults.itemShape(i, options.size),
                colors = SegmentedButtonDefaults.colors(activeContainerColor = Palette.accent, activeContentColor = Color.White,
                    inactiveContainerColor = Color.Transparent, inactiveContentColor = Color.White)) { Text(label, maxLines = 1) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> DropdownField(label: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = it }) {
        OutlinedTextField(options.firstOrNull { it.first == selected }?.second ?: "", {}, readOnly = true,
            label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable))
        ExposedDropdownMenu(expanded, { expanded = false }) {
            options.forEach { (value, text) -> DropdownMenuItem({ Text(text) }, { onSelect(value); expanded = false }) }
        }
    }
}

// ---------- BMI e obiettivi ----------

@Composable
private fun BmiCard(weightKg: Double, heightCm: Double) {
    val r = BmiCalculator.calculate(weightKg, heightCm) ?: return
    val key = when (r.category) {
        BmiCategory.UNDERWEIGHT -> "bmi.under"; BmiCategory.NORMAL -> "bmi.normal"
        BmiCategory.OVERWEIGHT -> "bmi.over"; BmiCategory.OBESE -> "bmi.obese"
    }
    val nf = remember { NumberFormat.getNumberInstance().apply { minimumFractionDigits = 1; maximumFractionDigits = 1 } }
    GlassCard {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SecondaryText("BMI", 15)
            Text(nf.format(r.value), fontSize = 64.sp, fontWeight = FontWeight.ExtraBold,
                style = TextStyle(brush = Palette.gradient))
            Text(tr(key), fontWeight = FontWeight.Bold, fontSize = 17.sp)
            LinearProgressIndicator(progress = { ((r.value.coerceIn(15.0, 40.0) - 15) / 25).toFloat() },
                modifier = Modifier.fillMaxWidth().height(8.dp), color = Palette.accent, trackColor = Color(0x1AFFFFFF))
            SecondaryText(tr("bmi.adultsOnly"), 11)
        }
    }
}

@Composable
private fun TargetsCard(t: DailyTargets) {
    GlassCard {
        Text(tr("nutrition.targets"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${t.calories}", fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, style = TextStyle(brush = Palette.gradient))
            Spacer(Modifier.width(6.dp)); SecondaryText("kcal", 17)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Macro(tr("nutrition.protein"), t.proteinGrams, Modifier.weight(1f))
            Macro(tr("nutrition.carbs"), t.carbsGrams, Modifier.weight(1f))
            Macro(tr("nutrition.fat"), t.fatGrams, Modifier.weight(1f))
        }
        SecondaryText(tr("nutrition.indicative"), 11)
    }
}

@Composable
private fun Macro(title: String, grams: Int, modifier: Modifier) {
    Column(modifier.background(Color(0x12FFFFFF), RoundedCornerShape(16.dp)).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$grams g", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        SecondaryText(title, 12)
    }
}

@Composable
private fun MealPlanCard(targets: DailyTargets, diets: Set<DietType>) {
    var trainingDay by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    val day = DietPlanner.plan(targets, diets, trainingDay)
    GlassCard {
        Text(tr("nutrition.meals"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
        ToggleLine(tr("nutrition.trainingDay"), trainingDay) { trainingDay = it }
        SecondaryText(tr("nutrition.dayTotal", day.calories, day.proteinG, day.carbsG, day.fatG), 15)
        day.meals.forEach { meal ->
            Column(Modifier.padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row {
                    Text(tr(meal.nameKey), fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Text("${meal.calories} kcal", fontSize = 15.sp)
                }
                SecondaryText(tr("nutrition.macros", meal.proteinG, meal.carbsG, meal.fatG), 12)
                Text(meal.suggestions.joinToString(" · ") { trText(context, it) }, fontSize = 12.sp, color = Palette.accentSoft)
            }
        }
        SecondaryText(tr("nutrition.noRecipes"), 11)
    }
}

// ---------- Scheda del nutrizionista ----------

@Composable
private fun NutritionistCard(onEdit: (NutritionDraft) -> Unit) {
    val data by Graph.store.data.collectAsState()
    val plan = data.nutritionPlan?.plan ?: return
    var confirmDelete by remember { mutableStateOf(false) }
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("nutritionist.title"), fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
            GlassButton(tr("plans.detail.edit")) { onEdit(NutritionDraft(plan, "")) }
        }
        plan.calories?.let { Text("$it kcal", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        val macros = listOfNotNull(plan.proteinG?.let { "P $it g" }, plan.carbsG?.let { "C $it g" }, plan.fatG?.let { "G $it g" })
        if (macros.isNotEmpty()) SecondaryText(macros.joinToString(" · "), 15)
        plan.meals.forEach { meal ->
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(meal.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                meal.items.forEach { Text("• $it", fontSize = 12.sp) }
            }
        }
        TextButton({ confirmDelete = true }) { Text(tr("history.delete"), color = Palette.danger, fontSize = 13.sp) }
    }
    if (confirmDelete) DeleteDialog(onDismiss = { confirmDelete = false }) { Graph.store.deleteNutritionPlan(); confirmDelete = false }
}

/** Revisione della scheda del nutrizionista. Se ne tiene una sola: la nuova sostituisce la precedente. */
@Composable
fun NutritionPlanReview(initial: NutritionDraft, onClose: () -> Unit) {
    var plan by remember { mutableStateOf(initial.plan) }
    fun updateMeal(id: String, change: (ParsedMeal) -> ParsedMeal) { plan = plan.copy(meals = plan.meals.map { if (it.id == id) change(it) else it }) }

    FullScreenDialog(onClose, dismissible = false) {
        ReviewFrame(tr("nutritionist.reviewTitle"), true, onClose, onSave = {
            val meals = plan.meals.mapNotNull { m ->
                val items = m.items.map { it.trim() }.filter { it.isNotEmpty() }
                val name = m.name.trim()
                if (name.isEmpty() && items.isEmpty()) null else m.copy(name = name, items = items)
            }
            Graph.store.saveNutritionPlan(plan.copy(meals = meals))
            onClose()
        }) {
            GlassCard {
                CheckWarning()
                IntField(tr("nutrition.calories"), plan.calories, Modifier.fillMaxWidth()) { plan = plan.copy(calories = it) }
                IntField(tr("nutrition.protein"), plan.proteinG, Modifier.fillMaxWidth()) { plan = plan.copy(proteinG = it) }
                IntField(tr("nutrition.carbs"), plan.carbsG, Modifier.fillMaxWidth()) { plan = plan.copy(carbsG = it) }
                IntField(tr("nutrition.fat"), plan.fatG, Modifier.fillMaxWidth()) { plan = plan.copy(fatG = it) }
            }
            plan.meals.forEach { meal ->
                GlassCard {
                    OutlinedTextField(meal.name, { t -> updateMeal(meal.id) { it.copy(name = t) } }, Modifier.fillMaxWidth(),
                        label = { Text(tr("nutritionist.mealName")) }, singleLine = true)
                    OutlinedTextField(meal.items.joinToString("\n"), { t -> updateMeal(meal.id) { it.copy(items = t.split("\n")) } },
                        Modifier.fillMaxWidth(), label = { Text(tr("nutritionist.items")) }, minLines = 2, maxLines = 10)
                    TextButton({ plan = plan.copy(meals = plan.meals.filterNot { it.id == meal.id }) }) {
                        Icon(Icons.Filled.Delete, null, tint = Palette.danger); Spacer(Modifier.width(6.dp))
                        Text(tr("nutritionist.deleteMeal"), color = Palette.danger)
                    }
                }
            }
            GlassButton(tr("nutritionist.addMeal"), Modifier.fillMaxWidth(), icon = Icons.Filled.Add) {
                plan = plan.copy(meals = plan.meals + ParsedMeal(name = "", items = emptyList()))
            }
            SourceText(initial.sourceText)
        }
    }
}

// ---------- Ricerca alimenti (Open Food Facts) ----------

private enum class SearchState { IDLE, LOADING, DONE, FAILED }

/** Open Food Facts chiede uno User-Agent con nome dell'app, versione e un contatto. */
private val foodUserAgent: String get() = "MyGymHelper/${BuildConfig.VERSION_NAME} (Android; ${BuildConfig.CONTACT_EMAIL})"

/** Si inviano solo le parole cercate, nessun dato sanitario. Dati ODbL: l'attribuzione resta sempre visibile. */
suspend fun searchFoods(query: String, language: String): List<FoodProduct> = withContext(Dispatchers.IO) {
    val url = FoodFacts.searchUrl(query, language) ?: return@withContext emptyList()
    val conn = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15_000; readTimeout = 20_000
        setRequestProperty("User-Agent", foodUserAgent)
        setRequestProperty("Accept", "application/json")
    }
    try {
        if (conn.responseCode !in 200..299) throw java.io.IOException("HTTP ${conn.responseCode}")
        FoodFacts.decodeSearch(conn.inputStream.bufferedReader().use { it.readText() })
    } finally { conn.disconnect() }
}

@Composable
fun FoodSearchScreen(nav: Navigator) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<FoodProduct>>(emptyList()) }
    var state by remember { mutableStateOf(SearchState.IDLE) }
    var job by remember { mutableStateOf<Job?>(null) }
    val language = remember { Locale.getDefault().language.ifEmpty { "en" } }

    fun search() {
        val text = query.trim()
        if (text.length < 2) return
        job?.cancel()
        state = SearchState.LOADING
        job = scope.launch {
            try { results = searchFoods(text, language); state = SearchState.DONE }
            catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { state = SearchState.FAILED }
        }
    }

    ScrollScreen(nav, back = true) {
        ScreenHeader(Icons.Filled.Search, tr("food.search.title"), tr("food.search.subtitle"))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text(tr("food.search.placeholder")) },
            singleLine = true, shape = CircleShape,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { search() }),
            trailingIcon = {
                IconButton({ search() }, enabled = query.trim().length >= 2) { Icon(Icons.AutoMirrored.Filled.ArrowForward, tr("food.search.title"), tint = Palette.accent) }
            })
        when (state) {
            SearchState.IDLE -> {}
            SearchState.LOADING -> CircularProgressIndicator(color = Palette.accent, modifier = Modifier.align(Alignment.CenterHorizontally))
            SearchState.FAILED -> GlassCard(padding = PaddingValues(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.WifiOff, null, tint = Palette.secondary); Spacer(Modifier.width(8.dp)); SecondaryText(tr("food.search.error"), 15)
                }
            }
            SearchState.DONE -> {
                if (results.isEmpty()) GlassCard(padding = PaddingValues(16.dp)) { SecondaryText(tr("food.search.none"), 15) }
                results.forEach { FoodRow(it) }
            }
        }
        Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            SecondaryText(tr("food.attribution"), 11)
            TextButton({ context.openUrl(FoodFacts.BASE_URL) }) {
                Text("openfoodfacts.org", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Palette.accentText)
            }
        }
    }
}

@Composable
private fun FoodRow(p: FoodProduct) {
    val nf = remember { NumberFormat.getNumberInstance().apply { maximumFractionDigits = 1 } }
    GlassCard(padding = PaddingValues(16.dp)) {
        Row {
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                p.brand?.let { SecondaryText(it, 12) }
            }
            p.kcal100g?.let { Text("${it.roundToInt()} kcal", fontWeight = FontWeight.Bold, fontSize = 15.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("nutrition.protein" to p.protein100g, "nutrition.carbs" to p.carbs100g, "nutrition.fat" to p.fat100g).forEach { (k, v) ->
                Row { SecondaryText(tr(k), 12); Spacer(Modifier.width(4.dp)); Text(v?.let { nf.format(it) + " g" } ?: "—", fontSize = 12.sp) }
            }
        }
        SecondaryText(tr("food.per100g"), 11)
    }
}
