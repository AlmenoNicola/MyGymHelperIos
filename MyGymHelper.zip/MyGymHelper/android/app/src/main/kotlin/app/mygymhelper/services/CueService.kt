package app.mygymhelper.services

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import app.mygymhelper.core.SessionCue
import app.mygymhelper.ui.trText
import java.util.Locale

data class CueOptions(val sound: Boolean = true, val voice: Boolean = true, val haptics: Boolean = true)

/** Trasforma gli avvisi della sessione in vibrazione, suono e voce (nella lingua del telefono). */
class CueService(private val context: Context, var options: CueOptions) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var ttsReady = false
    private val tone = runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80) }.getOrNull()
    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        else @Suppress("DEPRECATION") (context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale.getDefault()
    }

    fun play(cue: SessionCue) {
        if (options.haptics) haptic(cue)
        if (options.sound) tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        if (options.voice) phrase(cue)?.let { speak(it) }
    }

    fun shutdown() {
        tts?.stop(); tts?.shutdown(); tts = null
        tone?.release()
    }

    private fun phrase(cue: SessionCue): String? = when (cue) {
        is SessionCue.SetStarted -> trText(context, "cue.start")
        SessionCue.TargetReached -> trText(context, "cue.target")
        is SessionCue.RestStarted -> trText(context, "cue.rest", cue.seconds)
        is SessionCue.RestCountdown -> cue.n.toString()
        SessionCue.RestEnded -> trText(context, "cue.restEnd")
        SessionCue.SessionFinished -> trText(context, "cue.finished")
    }

    private fun haptic(cue: SessionCue) {
        val v = vibrator ?: return
        val effect = when (cue) {
            is SessionCue.SetStarted -> VibrationEffect.createOneShot(120, 255)
            SessionCue.TargetReached, SessionCue.RestEnded, SessionCue.SessionFinished ->
                VibrationEffect.createWaveform(longArrayOf(0, 60, 80, 60), -1)
            is SessionCue.RestStarted -> VibrationEffect.createWaveform(longArrayOf(0, 120, 100, 120), -1)
            is SessionCue.RestCountdown -> VibrationEffect.createOneShot(30, 120)
        }
        v.vibrate(effect)
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        // Le frasi si mettono in coda: "Serie completata" poi "Riposa 90 secondi".
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, text.hashCode().toString())
    }
}
