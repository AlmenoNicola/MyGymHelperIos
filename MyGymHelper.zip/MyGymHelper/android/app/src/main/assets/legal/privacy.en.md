# PRIVACY POLICY AND HEALTH DATA NOTICE
Data controller: [nome e cognome oppure ragione sociale]
Privacy contact: [indirizzo e-mail]
Application: [nome dell'app]
Last updated: [data]
## 1. What data is processed
The application may allow the user to enter and store on their own device:
- Physical data, such as weight, height and training goals.
- Information about physical activity and eating habits.
- Health information entered voluntarily, such as declared conditions, allergies, intolerances and physical limitations.
- Personal preferences needed to personalise the app's features.
Only the data actually required by the features in use will be processed.
## 2. Local storage
Personal and health data managed by the application's local features are designed to be stored on the user's device, without synchronisation with servers or cloud services run by the app.
The application does not send health data to a remote server for artificial intelligence processing, as long as the model and all relevant processing actually run locally.
This description is not a guarantee against every possible access to the data by third parties. The operating system, backup features, other installed applications or any external technical components may behave independently and must be verified.
## 3. Purposes of processing
The data entered may be used locally to:
- Store the user's progress.
- Personalise information and suggestions.
- Prepare training programmes and indications.
- Organise dietary information and personal goals.
- Allow the on-device artificial intelligence features to work.
The data must not be used for further purposes incompatible with those communicated to the user.
## 4. Local artificial intelligence
Artificial intelligence features described as local process information on the user's device.
The application does not send health data to external artificial intelligence providers for such processing.
Any additional features involving data transfers will be described separately and, where necessary, made available only after providing the information and obtaining the required permissions.
## 5. Access to data and disclosure to third parties
The controller does not automatically receive health data stored exclusively on the device through the local features alone.
Any data processed through separate services, such as purchases, statistics, technical diagnostics or support, will be handled according to their respective purposes and the applicable notice.
No absolute guarantees of no access by third parties will be stated without a technical check of the application and of the components used.
## 6. Retention and deletion
Local data remains on the device until it is deleted by the user or removed according to the actual operation of the application and of the operating system.
The user must be able to find the available ways to delete the data stored by the app. Uninstalling the app, resetting the device or other operating system operations may cause the loss of the information.
## 7. Security
The application must adopt security measures appropriate to the nature of the data processed, including, where appropriate, protection against unauthorised access, secure storage and data minimisation.
Actual security also depends on the device, the operating system, its configuration and the measures implemented.
## 8. Rights of the data subject
Where the processing falls within the scope of the GDPR, the data subject may exercise, under the conditions laid down by law, the rights of access, rectification, erasure, restriction, objection and portability, and may withdraw consent when the processing is based on it.
To exercise the rights relating to processing carried out by the controller, contact: [indirizzo e-mail].
Data stored only locally may not be technically accessible to the controller. The ways of exercising rights must therefore be defined according to the processing actually carried out.
You may also lodge a complaint with the competent supervisory authority (in Italy, the Garante per la protezione dei dati personali).
## 9. Changes to this policy
This policy may be updated in case of changes to the features, to the processing methods or to legal obligations.
Substantial changes will be communicated as required by the applicable law.
## 10. Account, purchases and exercise list [DRAFT TO BE CHECKED BY A LAWYER]
If the user creates an account (e-mail, Google or Apple), the application processes the data needed to sign in (e-mail address or identifier provided by the sign-in service, display name and language) through the authentication and database provider [indicate the provider and its role].
In the Android version purchases and subscriptions are handled by Google Play. The controller receives the subscription status (and, if the user has an account, the link between purchase and account), not payment data.
To show the exercise list, the application requests generic content from the server, indicating the device language. No health data is sent.
## 11. Health Connect, food search and account deletion [DRAFT TO BE CHECKED BY A LAWYER]
If the user connects Health Connect from the Info section, the application reads weight and height only when the user asks and writes completed strength workouts to Health Connect. The exchange happens on the device through Health Connect; the controller does not receive this data. Permissions are managed and revoked in the Health Connect settings; "Delete all data" also deletes the workouts the application wrote to Health Connect. Data obtained from Health Connect is used only for the features described and is not transferred to third parties or used for advertising.
Food search sends to the Open Food Facts service only the search words and the device language, without health data or account identifiers. Food data is distributed under the ODbL licence.
A user who has created an account can delete it at any time from the Info section: the account and the related server data (profile, lists, licence status) are deleted, while active subscriptions must be cancelled in the Play Store (Payments & subscriptions).
