# Regole per la versione di rilascio (R8).
# kotlinx.serialization (usato da Supabase)
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
# Ktor / OkHttp
-dontwarn org.slf4j.**
-dontwarn io.ktor.**
