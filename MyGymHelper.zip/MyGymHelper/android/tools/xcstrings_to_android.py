#!/usr/bin/env python3
"""Genera app/src/main/res/values/strings.xml (inglese) e values-it/strings.xml (italiano)
partendo dal catalogo iOS App/Localizable.xcstrings più le stringhe solo Android (tools/android_strings.json).
Uso (dalla cartella android): python3 tools/xcstrings_to_android.py
Nome Android = chiave iOS senza parametri, con i punti sostituiti da "_" (es. "session.set %lld %lld" -> session_set).
"""
import json, re, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ANDROID = os.path.dirname(HERE)
XC = os.path.join(ANDROID, "..", "App", "Localizable.xcstrings")
EXTRA = os.path.join(HERE, "android_strings.json")

def res_name(key):
    base = key.split(" ")[0]
    return re.sub(r"[^A-Za-z0-9_]", "_", base)

SPEC = re.compile(r"%(\d+\$)?(lld|ld|d|@|lf|f|s)")

def convert(value):
    # %lld -> %d, %@ -> %s, %lf -> %f; numera gli argomenti se sono più di uno.
    specs = [m for m in SPEC.finditer(value)]
    positional = any(m.group(1) for m in specs) or len(specs) > 1
    out, idx, n = [], 0, 0
    for m in specs:
        out.append(value[idx:m.start()])
        kind = {"lld": "d", "ld": "d", "d": "d", "@": "s", "lf": "f", "f": "f", "s": "s"}[m.group(2)]
        n += 1
        pos = m.group(1) or (f"{n}$" if positional else "")
        out.append(f"%{pos}{kind}")
        idx = m.end()
    out.append(value[idx:])
    return "".join(out), len(specs)

def escape(v):
    v = v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    v = v.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"').replace("\n", "\\n")
    if v.startswith("@") or v.startswith("?"):
        v = "\\" + v
    return v

def main():
    xc = json.load(open(XC, encoding="utf-8"))["strings"]
    extra = json.load(open(EXTRA, encoding="utf-8")) if os.path.exists(EXTRA) else {}
    entries = {}
    for key, v in xc.items():
        loc = v.get("localizations", {})
        try:
            it = loc["it"]["stringUnit"]["value"]; en = loc["en"]["stringUnit"]["value"]
        except KeyError:
            continue
        entries[key] = (en, it)
    for key, (it, en) in extra.items():
        entries[key] = (en, it)
    names = {}
    for key in entries:
        n = res_name(key)
        if n in names and names[n] != key:
            sys.exit(f"Nome duplicato: {n} ({names[n]} / {key})")
        names[n] = key
    for lang, folder in (("en", "values"), ("it", "values-it")):
        lines = ['<?xml version="1.0" encoding="utf-8"?>',
                 "<!-- Generato da tools/xcstrings_to_android.py: non modificare a mano. -->",
                 "<resources>"]
        for n in sorted(names):
            en, it = entries[names[n]]
            raw = en if lang == "en" else it
            value, nargs = convert(raw)
            attrs = ""
            if nargs == 0 and "%" in value:
                attrs = ' formatted="false"'
            lines.append(f'    <string name="{n}"{attrs}>{escape(value)}</string>')
        lines.append("</resources>")
        path = os.path.join(ANDROID, "app", "src", "main", "res", folder, "strings.xml")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print(f"{len(names)} stringhe scritte")

if __name__ == "__main__":
    main()
